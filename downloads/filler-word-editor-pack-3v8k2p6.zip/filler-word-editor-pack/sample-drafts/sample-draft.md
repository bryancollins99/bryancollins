# A Deliberately Padded Sample Draft

I really just think this is basically a very simple example that is honestly
quite useful for testing the tool. At the end of the day, the end result is that
you can see exactly how the checker works when you run it over a real file.

In order to get the most value, you should probably read the output carefully.
It seems that most drafts are somewhat loose on the first pass, and that is
totally normal. I believe that each and every writer leans on a few crutch words
without really noticing.

We are going to leverage this sample to move the needle on your editing. Sort of
a low hanging fruit, if you ask me. The added bonus is that you get a free gift:
a clear picture of your own filler density.
