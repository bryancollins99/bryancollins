# Filler-Word Killer Editor Pack

Cut the filler, weak verbs, hedges, and cliches out of your writing, in bulk.

The free browser tool cleans one draft at a time. This pack is for writers and
editors who work at volume: a command-line checker that scans a whole folder of
drafts and prints a report, a much bigger categorised dictionary you can read and
extend, a self-host copy of the tool you can put on your own site, and a
one-page style checklist.

Everything here is deterministic and runs on your own machine. No account, no
API key, no network calls, nothing sent anywhere. The same draft always gets the
same report.

---

## What's in the box

| Piece | What it is |
|---|---|
| **`cli/filler_word_killer.py`** | The batch checker. Runs over one file or a whole folder of drafts and prints a per-file and total report: word count, flagged instances, filler density, category breakdown, and most-frequent flags. |
| **`data/`** | The dictionary, as clean, readable JSON files you can edit: fillers, crutch words, hedges, weak verbs, corporate jargon, cliche phrases, redundancy pairs, and the -ly adverb whitelist. |
| **`self-host/filler-word-killer.html`** | An unbranded, self-contained copy of the web tool. Drop it on any site or open it locally. No tracking, no external calls beyond the styling CDN. |
| **`style-checklist.md`** | The one-page tighten-your-prose checklist. Print it, pin it, run it before you publish. |
| **`sample-drafts/`** | A deliberately padded draft so you can watch the checker work before pointing it at your own writing. |

## Quick start (the CLI)

You need Python 3.8 or newer. It is already on every Mac and most Linux boxes.
No packages to install: the checker uses only the standard library.

Run it over the included sample:

```
python3 cli/filler_word_killer.py sample-drafts/sample-draft.md
```

Run it over a single draft of your own:

```
python3 cli/filler_word_killer.py path/to/your-draft.md
```

Run it over a whole folder of drafts (scans .md, .txt, and .markdown by default):

```
python3 cli/filler_word_killer.py path/to/your-drafts-folder/
```

See the exact lines that contain flagged words:

```
python3 cli/filler_word_killer.py your-draft.md --show-lines
```

Scan a different set of file types:

```
python3 cli/filler_word_killer.py drafts/ --ext .md,.txt,.rst
```

## Reading the report

For each file you get:

- **Total words** and **flagged instances**.
- **Filler density**: flagged words as a percentage of total words, with a verdict.
  - Under 4 percent reads **Tight**.
  - 4 to 8 percent is **Solid**.
  - 8 to 14 percent is **Loose**.
  - Over 14 percent is **Padded**.
- **By category**: how many flags came from each bucket (filler, hedge, weak-verb,
  jargon, cliche, redundancy, crutch, adverb).
- **Most frequent flags**: the specific words you lean on most, so you know what
  to hunt for on your next draft.

Point it at a folder and you also get a combined total across every file.

## The self-host tool

Open `self-host/filler-word-killer.html` in any browser, or upload it to your own
site. It is the same paste-and-highlight tool, unbranded, with the dictionary
visible in the page source. It loads Tailwind and Font Awesome from a public CDN
for styling only. The analysis itself never touches the network: paste a
confidential draft and watch the network tab stay silent.

## Editing the dictionary

Every list lives in `data/` as a JSON file with a `words` array. Open any file,
add or remove terms, save. The CLI reads them on the next run. Single words match
whole words; multi-word entries match as phrases. The `adverb-whitelist.json`
file lists words ending in -ly that are NOT adverbs, so the checker never flags
them (for example "family", "reply", "only").

## What this is not

- Not a grammar checker or a spell checker. It targets filler and weak words only.
- Not an AI tool. There is no model and no API. It is a fixed dictionary plus a
  handful of deterministic rules, so it is fast, free to run, and completely
  private.
- Not a replacement for your judgement. It flags candidates. You decide what to
  cut. A weak verb is sometimes the right verb.

## License

See LICENSE. Personal-use license: use it on your own writing and your own
machines, keep everything you produce with it, but do not resell or redistribute
the pack itself.
