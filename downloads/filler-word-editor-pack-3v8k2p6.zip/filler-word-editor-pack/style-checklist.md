# The One-Page Tighten-Your-Prose Checklist

Run this pass on any draft before you publish. It takes five minutes and it is
the difference between prose that drags and prose that moves.

## 1. Kill the empty intensifiers
Delete "very", "really", "quite", "so", "just", "actually", "basically",
"simply", "totally", "literally". They almost never earn their place. "Very
tired" is weaker than "exhausted". Find the stronger word instead of propping up
a weak one.

## 2. Hunt the hedges
"I think", "maybe", "sort of", "kind of", "perhaps", "it seems". If you believe
the claim, state it. If you do not, cut the sentence. Hedging tells the reader
you do not trust your own point.

## 3. Trade weak verbs for strong ones
Circle every "is", "are", "was", "were". Many signal a passive or limp sentence.
"A decision was made by the team" becomes "The team decided". "There are three
reasons" becomes "Three reasons stand out". The verb should carry the sentence.

## 4. Delete the redundant halves
"End result" is a result. A "free gift" is a gift. "Each and every" is either.
"In order to" is "to". When two words say one thing, keep the stronger one.

## 5. Cut the -ly adverbs
Most adverbs patch a weak verb. "Ran quickly" is "sprinted". "Said loudly" is
"shouted". Keep an adverb only when it changes the meaning, not when it merely
turns up the volume.

## 6. Strip the corporate jargon
"Leverage", "synergy", "circle back", "move the needle", "low hanging fruit".
Every one has a plain-English equivalent that a human actually says out loud.
Use that.

## 7. Retire the cliches
"At the end of the day", "think outside the box", "the tip of the iceberg". The
reader has seen them a thousand times and skims straight past. A fresh, specific
line earns the attention a cliche throws away.

## 8. Read it out loud
The final test. Anywhere you stumble, trip, or run out of breath is a sentence
to rewrite. Your ear catches what your eye forgives.

## 9. Check the density
Run the tool or the CLI. Under 4 percent flagged words reads tight. 4 to 8 is
solid. 8 to 14 is loose. Over 14 is padded. Aim for tight, settle for solid, fix
anything worse.

## The one rule behind all nine
Cut every word that does not change the meaning of the sentence. If you can
delete it and lose nothing, delete it.
