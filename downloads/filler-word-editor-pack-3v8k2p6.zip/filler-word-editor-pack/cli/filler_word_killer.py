#!/usr/bin/env python3
"""
Filler-Word Killer -- batch CLI.

Runs the same deterministic filler/weak-word check as the web tool over a single
file or a whole folder of drafts, and prints a report. No network, no API, no
LLM. The same input always produces the same output.

Usage:
    python3 filler_word_killer.py path/to/draft.md
    python3 filler_word_killer.py path/to/drafts-folder/
    python3 filler_word_killer.py draft.md --show-lines
    python3 filler_word_killer.py drafts/ --ext .md,.txt

Exit code is 0 on success (a report is a success even if it finds a lot).
"""

import argparse
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.normpath(os.path.join(HERE, "..", "data"))

# Data files that contribute flagged terms, mapped to the category shown in the
# report. adverb-whitelist.json is loaded separately (it exempts words).
CATEGORY_FILES = {
    "fillers.json": "filler",
    "crutch-words.json": "crutch",
    "hedges.json": "hedge",
    "weak-verbs.json": "weak-verb",
    "corporate-jargon.json": "jargon",
    "cliche-phrases.json": "cliche",
    "redundancy-pairs.json": "redundancy",
}

WORD_RE = re.compile(r"[A-Za-z][A-Za-z'’]*")


def load_dictionary():
    """Load all category data files into single-word and phrase lookups."""
    singles = {}          # lowercase word -> category
    phrases = {}          # phrase-length -> {phrase: category}
    max_phrase = 0

    for filename, category in CATEGORY_FILES.items():
        path = os.path.join(DATA_DIR, filename)
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        for raw in payload.get("words", []):
            term = raw.lower().strip()
            if not term:
                continue
            parts = term.split()
            if len(parts) == 1:
                singles.setdefault(term, category)
            else:
                bank = phrases.setdefault(len(parts), {})
                bank.setdefault(term, category)
                max_phrase = max(max_phrase, len(parts))

    whitelist_path = os.path.join(DATA_DIR, "adverb-whitelist.json")
    with open(whitelist_path, "r", encoding="utf-8") as handle:
        whitelist = {w.lower() for w in json.load(handle).get("words", [])}

    return singles, phrases, max_phrase, whitelist


def is_ly_adverb(word_lower, singles, whitelist):
    if len(word_lower) < 5:
        return False
    if not word_lower.endswith("ly"):
        return False
    if word_lower in whitelist:
        return False
    if word_lower in singles:
        return False
    return True


def tokenise(text):
    """Return a list of (value, is_word, lower) tokens preserving separators."""
    tokens = []
    last = 0
    for match in WORD_RE.finditer(text):
        if match.start() > last:
            tokens.append((text[last:match.start()], False, None))
        tokens.append((match.group(0), True, match.group(0).lower()))
        last = match.end()
    if last < len(text):
        tokens.append((text[last:], False, None))
    return tokens


def analyse_text(text, dictionary):
    """Return (total_words, flags) where flags is a list of dicts."""
    singles, phrases, max_phrase, whitelist = dictionary
    tokens = tokenise(text)

    word_positions = [i for i, tok in enumerate(tokens) if tok[1]]
    total_words = len(word_positions)

    flags = []
    consumed_until = -1  # index into word_positions already covered by a phrase
    wi = 0
    while wi < len(word_positions):
        if wi <= consumed_until:
            wi += 1
            continue

        matched = False
        # Try phrases, longest first.
        for plen in range(max_phrase, 1, -1):
            if wi + plen - 1 >= len(word_positions):
                continue
            bank = phrases.get(plen)
            if not bank:
                continue
            words = []
            clean = True
            for p in range(plen):
                ti = word_positions[wi + p]
                words.append(tokens[ti][2])
                if p > 0:
                    prev_ti = word_positions[wi + p - 1]
                    for mid in range(prev_ti + 1, ti):
                        mid_tok = tokens[mid]
                        if mid_tok[1] or not mid_tok[0].isspace():
                            clean = False
                            break
                    if not clean:
                        break
            if not clean:
                continue
            phrase = " ".join(words)
            if phrase in bank:
                flags.append({"text": phrase, "category": bank[phrase], "words": plen})
                consumed_until = wi + plen - 1
                wi += plen
                matched = True
                break
        if matched:
            continue

        ti = word_positions[wi]
        lower = tokens[ti][2]
        category = None
        if lower in singles:
            category = singles[lower]
        elif is_ly_adverb(lower, singles, whitelist):
            category = "adverb"
        if category:
            flags.append({"text": lower, "category": category, "words": 1})
        wi += 1

    return total_words, flags


def density_verdict(density):
    if density < 4:
        return "Tight"
    if density < 8:
        return "Solid"
    if density < 14:
        return "Loose"
    return "Padded"


def collect_files(target, extensions):
    if os.path.isfile(target):
        return [target]
    if os.path.isdir(target):
        found = []
        for root, _dirs, names in os.walk(target):
            for name in sorted(names):
                if os.path.splitext(name)[1].lower() in extensions:
                    found.append(os.path.join(root, name))
        return sorted(found)
    return []


def report_for_file(path, dictionary, show_lines):
    with open(path, "r", encoding="utf-8", errors="replace") as handle:
        text = handle.read()

    total_words, flags = analyse_text(text, dictionary)
    flagged_word_count = sum(flag["words"] for flag in flags)
    density = (flagged_word_count / total_words * 100) if total_words else 0.0

    by_category = {}
    by_term = {}
    for flag in flags:
        by_category[flag["category"]] = by_category.get(flag["category"], 0) + 1
        by_term[flag["text"]] = by_term.get(flag["text"], 0) + 1

    print("=" * 68)
    print("FILE: " + path)
    print("-" * 68)
    print("  Total words       : {:,}".format(total_words))
    print("  Flagged instances : {:,}".format(len(flags)))
    print("  Filler density    : {:.1f}%  ({})".format(density, density_verdict(density)))

    if by_category:
        print("  By category:")
        for category in sorted(by_category, key=lambda c: (-by_category[c], c)):
            print("    {:<12} {}".format(category, by_category[category]))

    if by_term:
        top = sorted(by_term.items(), key=lambda kv: (-kv[1], kv[0]))[:15]
        print("  Most frequent flags:")
        for term, count in top:
            print("    {:>3}x  {}".format(count, term))

    if show_lines:
        print("  Lines with flags:")
        for line_no, line in enumerate(text.splitlines(), start=1):
            _, line_flags = analyse_text(line, dictionary)
            if line_flags:
                terms = ", ".join(f["text"] for f in line_flags)
                print("    {:>4}: {}".format(line_no, terms))

    return {"words": total_words, "flags": len(flags), "flagged_words": flagged_word_count}


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Highlight filler and weak words in one file or a folder of drafts."
    )
    parser.add_argument("target", help="A draft file or a folder of drafts.")
    parser.add_argument(
        "--ext",
        default=".md,.txt,.markdown",
        help="Comma-separated file extensions to scan in a folder (default: .md,.txt,.markdown).",
    )
    parser.add_argument(
        "--show-lines",
        action="store_true",
        help="List the line numbers that contain flagged words.",
    )
    args = parser.parse_args(argv)

    extensions = {e if e.startswith(".") else "." + e
                  for e in (x.strip().lower() for x in args.ext.split(",")) if e}

    files = collect_files(args.target, extensions)
    if not files:
        print("No matching files found at: " + args.target, file=sys.stderr)
        return 1

    dictionary = load_dictionary()

    totals = {"words": 0, "flags": 0, "flagged_words": 0}
    for path in files:
        result = report_for_file(path, dictionary, args.show_lines)
        for key in totals:
            totals[key] += result[key]

    if len(files) > 1:
        overall_density = (totals["flagged_words"] / totals["words"] * 100) if totals["words"] else 0.0
        print("=" * 68)
        print("TOTAL ACROSS {} FILES".format(len(files)))
        print("-" * 68)
        print("  Total words       : {:,}".format(totals["words"]))
        print("  Flagged instances : {:,}".format(totals["flags"]))
        print("  Filler density    : {:.1f}%  ({})".format(overall_density, density_verdict(overall_density)))
        print("=" * 68)

    return 0


if __name__ == "__main__":
    sys.exit(main())
