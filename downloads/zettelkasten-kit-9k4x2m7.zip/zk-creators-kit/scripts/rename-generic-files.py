#!/usr/bin/env python3
# Usage: python3 rename-generic-files.py [NOTES_DIR] [--dry-run]   (renames timestamped note files to descriptive titles from their H1; NOTES_DIR defaults to current folder)
"""Rename generic timestamped note files to descriptive names based on their H1 title.

Turns files like  LinkedIn-Draft-2026-06-29-1.md  (which tell you nothing) into
LinkedIn-Draft-the-two-minute-brown-butter-trick.md  using the note's first
"# Heading" line. Run with --dry-run first to preview every change; nothing is
renamed until you confirm.
"""
import re
import sys
from pathlib import Path

# NOTES_DIR is the first non-flag argument, defaulting to the current folder.
args = [a for a in sys.argv[1:] if not a.startswith('-')]
NOTES_DIR = Path(args[0]) if args else Path('.')
dry_run = '--dry-run' in sys.argv

if not NOTES_DIR.is_dir():
    print(f"Error: '{NOTES_DIR}' is not a folder.")
    print("Usage: python3 rename-generic-files.py [NOTES_DIR] [--dry-run]")
    sys.exit(1)

# Which generic prefixes to look for. Edit this list to match your own naming.
PREFIXES = ['LinkedIn-Draft', 'Newsletter-Email', 'Note-Template', 'Business-Idea']

# Match generic numbered filenames like Prefix-2026-06-29-1.md or Prefix-2026-06-29-1430-2.md
GENERIC = re.compile(
    r'^(' + '|'.join(re.escape(p) for p in PREFIXES) + r')-\d{4}-\d{2}-\d{2}(-\d{4})?-\d+\.md$'
)


def slugify(title, max_len=60):
    slug = re.sub(r'[*_#`]', '', title)
    slug = re.sub(r'[^\w\s-]', '', slug)
    slug = slug.strip().replace(' ', '-')
    slug = re.sub(r'-+', '-', slug)
    if len(slug) > max_len:
        slug = slug[:max_len].rstrip('-')
    return slug


def get_h1(filepath):
    with open(filepath, 'r') as f:
        for line in f:
            if line.startswith('# '):
                return line[2:].strip()
    return None


renames = []
for f in sorted(NOTES_DIR.glob('*.md')):
    if not GENERIC.match(f.name):
        continue
    h1 = get_h1(f)
    if not h1:
        continue

    # Work out which prefix this file uses
    prefix = next((p for p in PREFIXES if f.name.startswith(p)), None)
    if prefix is None:
        continue

    # Strip a redundant prefix from the title (e.g. "LinkedIn Draft: AI Coding" -> "AI Coding")
    prefix_words = prefix.replace('-', ' ')
    clean_title = re.sub(r'^' + re.escape(prefix_words) + r'[:\s-]*', '', h1, flags=re.IGNORECASE)
    if not clean_title:
        clean_title = h1
    slug = slugify(clean_title)
    new_name = f'{prefix}-{slug}.md'

    # Avoid collision with an existing file
    new_path = NOTES_DIR / new_name
    if new_path.exists() and new_path != f:
        date_match = re.search(r'(\d{4}-\d{2}-\d{2})', f.name)
        date_str = date_match.group(1) if date_match else 'dup'
        new_name = f'{prefix}-{date_str}-{slug}.md'
        new_path = NOTES_DIR / new_name

    if new_name != f.name:
        renames.append((f, new_path))

for old, new in renames:
    print(f'{old.name}')
    print(f'  -> {new.name}')
    print()

print(f'Total: {len(renames)} files to rename')

if dry_run:
    print('\n(Dry run: no files changed)')
elif not renames:
    pass
else:
    confirm = input('\nProceed? (y/n): ').strip().lower()
    if confirm == 'y':
        for old, new in renames:
            old.rename(new)
        print(f'\nDone. {len(renames)} files renamed.')
    else:
        print('Cancelled.')
