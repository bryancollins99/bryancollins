#!/bin/bash
# Usage: ./find-duplicates.sh [NOTES_DIR]   (finds notes with repeated consecutive lines; NOTES_DIR defaults to current folder)
#
# Some note exports (notably Apple Notes) duplicate lines on export. This scans
# every .md file in your notes folder and reports the ones with consecutive
# duplicate lines so you can clean them up by hand.

NOTES_DIR="${1:-.}"

if [ ! -d "$NOTES_DIR" ]; then
    echo "Error: '$NOTES_DIR' is not a folder."
    echo "Usage: ./find-duplicates.sh [NOTES_DIR]"
    exit 1
fi

cd "$NOTES_DIR" || exit 1

REPORT_FILE="duplicate-lines-report.txt"
echo "Duplicate Lines Report - $(date +%Y-%m-%d)" > "$REPORT_FILE"
echo "========================================" >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"

echo "Scanning '$NOTES_DIR' for files with consecutive duplicate lines..."
echo ""

COUNT=0
TOTAL_DUPS=0

for file in *.md; do
    if [ -f "$file" ]; then
        # Count consecutive duplicate lines
        DUP_COUNT=$(awk 'prev == $0 {count++} {prev=$0} END {print count}' "$file" 2>/dev/null)

        if [ ! -z "$DUP_COUNT" ] && [ "$DUP_COUNT" -gt 0 ]; then
            COUNT=$((COUNT + 1))
            TOTAL_DUPS=$((TOTAL_DUPS + DUP_COUNT))

            echo "$file: $DUP_COUNT duplicate lines" >> "$REPORT_FILE"

            # Show a few sample duplicates
            awk 'NR > 1 && prev == $0 {print "  Line " NR ": " $0; if (++shown >= 3) exit} {prev=$0}' "$file" >> "$REPORT_FILE"
            echo "" >> "$REPORT_FILE"
        fi
    fi
done

echo "" >> "$REPORT_FILE"
echo "========================================" >> "$REPORT_FILE"
echo "Summary:" >> "$REPORT_FILE"
echo "  Files with duplicates: $COUNT" >> "$REPORT_FILE"
echo "  Total duplicate lines: $TOTAL_DUPS" >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"
echo "To fix a file, open it and delete the repeated lines shown above." >> "$REPORT_FILE"

echo "Scan complete."
echo "  Files with duplicates: $COUNT"
echo "  Total duplicate lines: $TOTAL_DUPS"
echo ""
echo "Report saved to: $NOTES_DIR/$REPORT_FILE"
