#!/bin/bash
# Usage: ./auto-tag.sh [NOTES_DIR]   (adds #tags to untagged notes based on their words; NOTES_DIR defaults to current folder)
#
# Scans every untagged .md file in your notes folder, guesses topic tags from the
# words inside, and appends them to the end of the file. Only touches files that
# have no tags yet, so it is safe to re-run. Edit the keyword rules below to match
# the topics YOU write about.

NOTES_DIR="${1:-.}"

if [ ! -d "$NOTES_DIR" ]; then
    echo "Error: '$NOTES_DIR' is not a folder."
    echo "Usage: ./auto-tag.sh [NOTES_DIR]"
    exit 1
fi

cd "$NOTES_DIR" || exit 1

echo "Auto-tagging untagged notes in '$NOTES_DIR'..."
echo ""

TAGGED=0
TOTAL=0

for file in *.md; do
    if [ -f "$file" ]; then
        # Only tag files that have no tags yet (no line starting with #<lowercase>)
        if ! grep -q "^#[a-z]" "$file" 2>/dev/null; then
            TOTAL=$((TOTAL + 1))

            # Read content, lowercased, for matching
            CONTENT=$(cat "$file" | tr '[:upper:]' '[:lower:]')

            TAGS=()

            # --- Channel / format tags -----------------------------------------
            if echo "$CONTENT" | grep -qE "email|newsletter|subscriber|subject line|open rate"; then
                TAGS+=("#newsletter")
            fi

            if echo "$CONTENT" | grep -qE "youtube|video|thumbnail|shorts|transcript"; then
                TAGS+=("#video")
            fi

            if echo "$CONTENT" | grep -qE "linkedin|twitter|instagram|threads|social post"; then
                TAGS+=("#social")
            fi

            # --- Work-type tags ------------------------------------------------
            if echo "$CONTENT" | grep -qE "draft|essay|article|blog|writing|headline|hook"; then
                TAGS+=("#writing")
            fi

            if echo "$CONTENT" | grep -qE "book|read|chapter|author|podcast|documentary|highlight"; then
                TAGS+=("#reading")
            fi

            if echo "$CONTENT" | grep -qE "idea|maybe|someday|concept|angle"; then
                TAGS+=("#idea")
            fi

            if echo "$CONTENT" | grep -qE "research|source|study|data|statistic"; then
                TAGS+=("#research")
            fi

            if echo "$CONTENT" | grep -qE "project|launch|ship|deadline|milestone"; then
                TAGS+=("#project")
            fi

            if echo "$CONTENT" | grep -qE "revenue|customer|pricing|sales|audience|subscriber"; then
                TAGS+=("#business")
            fi

            if echo "$CONTENT" | grep -qE "habit|routine|system|workflow|process|productivity"; then
                TAGS+=("#system")
            fi

            # Add tags if any were found
            if [ ${#TAGS[@]} -gt 0 ]; then
                echo "" >> "$file"
                for tag in "${TAGS[@]}"; do
                    echo "$tag" >> "$file"
                done

                TAGGED=$((TAGGED + 1))
                echo "Tagged: $file (${TAGS[@]})"
            fi
        fi
    fi
done

echo ""
echo "========================================"
echo "Summary:"
echo "  Untagged notes found: $TOTAL"
echo "  Notes tagged: $TAGGED"
echo "  Notes still untagged: $((TOTAL - TAGGED))"
echo ""
echo "Auto-tagging complete."
