# Map of Content - {Topic}

#moc #{topic-tag}

**Created:** {YYYY-MM-DD}
**Type:** MOC (hub note)
**Purpose:** {One line: what this map collects and why it exists.}

## Overview

{2 to 4 sentences. What is this topic, and what should a reader do when they land
here? A MOC is a table of contents you write by hand as a topic grows. You do not
create it up front. You create it the day you notice you have five or six notes
that keep pointing at each other.}

## Core notes

The load-bearing ideas. Read these first.

- [[Permanent-Note-the-idea.md]]: {one line on what this note claims}
- [[Permanent-Note-another-idea.md]]: {one line}
- [[Permanent-Note-a-third-idea.md]]: {one line}

## Supporting notes

Detail, examples, and evidence that back up the core notes.

- [[Permanent-Note-a-detail.md]]: {one line}
- [[Literature-Note-source-title.md]]: {the source this thread came from}

## Open threads

Questions this map has not answered yet. Where the topic wants to grow next.

- {A question you cannot answer from the notes above.}
- {A note you keep meaning to write.}

## See also

- [[MOC-Adjacent-Topic.md]]: {how the two maps relate}

<!--
HOW TO USE THIS TEMPLATE
A Map of Content (MOC) is a hub note: a hand-curated index of the notes on one
topic, with a line of context on each. It is how you find your way back into a
cluster of notes months later. Start a MOC only when a topic has enough notes
that you feel lost without one (usually five or more). Group the links by role
(core / supporting / open) rather than dumping a flat list, and write one line
per link so the map is readable on its own. Copy this file, rename it to
"MOC - Your Topic.md", and delete these comments.
-->
