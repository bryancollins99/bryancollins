# {Source title, e.g. "Salt, Fat, Acid, Heat" or "Podcast: How to Test a Recipe"}

{An informal, in-your-own-words summary of what you took from this source.
Imagine explaining it to a friend over coffee. Bullet points are fine. The test
is: could you rebuild the useful parts of this source from these notes alone,
without re-reading it? Do not copy the source's wording. Translating it into
your own language is the work that makes it stick.}

- {Main point one, in your words}
- {Main point two, in your words}
- {The one thing you want to remember in six months}

**Quote worth keeping:**
> {A direct quote only if the exact wording matters. Keep these rare.}

**Source:** {Author, title, page or timestamp or URL. Enough to find it again
and to cite it honestly later.}

**Turns into:** {Which idea here deserves its own permanent note? Name it.
[[Permanent-Note-the-idea-you-pulled-out.md]]}

#literature-note

<!--
HOW TO USE THIS TEMPLATE
A literature note is what you write about something you consumed: a book, an
article, a podcast, a documentary, a talk. It is a holding pen, not a
destination. Its job is to capture what you learned so you can later mine it for
permanent notes. Keep it in your own words. A literature note that quotes the
source at length is a highlight, not a note, and highlights are forgotten.
Copy this file, rename it to a descriptive kebab-case title, delete these
comments, and fill it in.
-->
