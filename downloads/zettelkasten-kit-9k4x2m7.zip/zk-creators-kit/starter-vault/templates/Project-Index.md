# Project Index

**Purpose:** Central directory of every project, site, and tool you own. One
place to answer "what am I actually running?" without opening ten folders.
**Last updated:** {YYYY-MM-DD}
**Review:** Monthly, or whenever you are tempted to start something new.

---

## Live / active

Things that are running right now and earn a look.

| Project | What it is | Status | Next action |
|---------|-----------|--------|-------------|
| {name} | {one line} | {active / maintenance} | {the single next thing, or "keep"} |
| {name} | {one line} | {active / maintenance} | {next action} |

---

## Building

The small number of things you are actively working on. If this list is long,
your attention is spread too thin. See Active-Projects.md for the hard cap.

### {Project name}
- **What it does:** {one or two lines}
- **Status:** {plan complete / in progress / testing}
- **Notes:** [[MOC-This-Project.md]] or [[Permanent-Note-a-key-idea.md]]
- **Next actions:**
  - {next thing}
  - {next thing}

---

## Someday / maybe

Ideas you have not committed to. Parked on purpose, not forgotten. Nothing here
gets your time until something above moves off the list.

- {idea}: {one line on why it is parked}
- {idea}: {one line}

---

## Done / retired

Finished or deliberately stopped. Kept for the record so you do not re-open them
by accident.

| Project | Why it is here |
|---------|----------------|
| {name} | {shipped / abandoned / superseded, and why} |

<!--
HOW TO USE THIS TEMPLATE
The Project Index is the single map of everything you run. It is deliberately
boring: a directory, not a plan. Update it monthly, and every time you finish or
kill something. Its value is honesty. Seeing the full list, including the dead
projects, is what stops you starting a tenth thing while three are half-built.
Copy this file to the root of your vault as "Project-Index.md" and delete these
comments. See notes/Project-Index.md in this kit for a filled-in example.
-->
