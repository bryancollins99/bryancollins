# {One idea, stated as a claim}

{2 to 5 sentences in your own words. State the single idea clearly enough that
future-you understands it a year from now with no other context. This is not a
summary of a source; it is your own thought, standing on its own. One idea per
note. The moment you write "and another thing", stop and start a second note.}

**Why it matters:** {the consequence, the decision it changes, or the thing it
explains. If you can't say why it matters, it may not be a permanent note yet.}

**Where it came from:** {[[Literature-Note-source-title.md]], a project, a
conversation, or a line in your worklog. Link the source note so you can trace
the idea back.}

**Connects to:**
- [[Another-Permanent-Note.md]]: {one line on how they relate: supports, contradicts, extends}
- [[MOC-topic-this-belongs-under.md]]: {the map of content this note lives inside}

#permanent-note

<!--
HOW TO USE THIS TEMPLATE
A permanent note holds one finished idea in your own words. It is the endpoint
of the system: literature notes feed it, and it feeds your maps of content.
Rules of thumb:
- Title is the claim itself, so the list of titles reads like an argument.
- Written for a stranger (future-you counts as a stranger).
- Always linked. A permanent note with no links is a note you will never find.
Copy this file, rename it to a descriptive kebab-case title (see the vault
README for the naming convention), and delete these comments.
-->
