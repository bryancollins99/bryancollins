# Active Projects (Max 3)

**The rule:** You may not start a new project until one of these three moves to
"Shipped" or "Abandoned". Three slots. No fourth slot. The constraint is the
whole point: it forces you to finish or kill before you begin.
**Review:** Once a week, same time every week.
**Last updated:** {YYYY-MM-DD}

---

## Currently building

### 1. {Project name} [{priority}]
**Status:** {one line}
**What it does:** {one or two lines}
**Next actions:**
- {the very next physical action}
- {the one after that}
**Why it earns a slot:** {one line. If you cannot justify the slot, free it.}

### 2. {Project name} [{priority}]
**Status:** {one line}
**Next actions:**
- {next action}
**Why it earns a slot:** {one line}

### 3. {Project name} [{priority}]
**Status:** {one line}
**Next actions:**
- {next action}
**Why it earns a slot:** {one line}

---

## Waiting list

The queue. Nothing here starts until a slot above opens. Naming what is waiting
is how you resist starting it early.

### {Project name}
- **Waiting for:** {which active project has to finish first, or what has to be true}
- **What it is:** {one line}

---

## Recently shipped

- **[{YYYY-MM-DD}]** {what shipped, one line}
- **[{YYYY-MM-DD}]** {what shipped}

## Killed / parked

- **{Project name}**: {why it was stopped}

<!--
HOW TO USE THIS TEMPLATE
This is the discipline layer, not the archive (that is Project-Index.md). The
hard cap of three is the feature. A weekly review is the only maintenance: for
each slot, decide ship, continue, or kill. When you kill or ship one, and only
then, you may promote something from the waiting list. Copy this file to your
vault root as "Active-Projects.md" and delete these comments.
-->
