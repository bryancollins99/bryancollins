# A recipe intro must earn the scroll, not delay it

Readers do not scroll past a recipe intro because intros are bad. They scroll
because most intros are a toll booth: a paragraph of childhood-in-Tuscany
throat-clearing standing between them and the ingredient list. The fix is not to
delete the intro. It is to make the intro pay its own way by answering one
question in the first two lines: why should I cook this tonight instead of the
version I already know? Everything after that is optional colour.

**Why it matters:** This is the difference between an intro that grows the
newsletter and one that trains readers to skim. If the first two lines deliver a
concrete reason (faster, cheaper, one pan, better crumb), the reader trusts the
rest and reads on. It also makes intros faster to write, because I stop reaching
for a story I do not have.

**Where it came from:** The 06-27 note where I drafted ten intros and kept two.
The two keepers both led with the payoff. The eight rejects all led with me.

**Connects to:**
- [[Permanent-Note-brown-butter-is-a-flavour-multiplier.md]]: a good "why cook this tonight" hook in one technique
- [[Literature-Note-salt-fat-acid-heat.md]]: the "teach the principle, not just the recipe" idea

#permanent-note #writing
