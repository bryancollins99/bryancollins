# Project Index

**Purpose:** Central directory of everything I run, so I can answer "what am I
actually working on?" in one glance. (This is a filled-in example. Yours will
look nothing like it, and that is fine.)
**Last updated:** 2026-06-29
**Review:** Monthly.

---

## Live / active

| Project | What it is | Status | Next action |
|---------|-----------|--------|-------------|
| The Weeknight Table | Friday recipe newsletter, ~1,400 subscribers | Active, growing | Keep. Ship one issue a week. |
| theweeknighttable.com | Recipe archive + signup page | Active | Keep. Fix mobile recipe cards. |
| Instagram (@weeknighttable) | Promo channel for the newsletter | Active, low effort | Post one reel per issue, no more |

---

## Building

### Recipe scaler tool
- **What it does:** Takes a recipe and rescales quantities for a different number
  of servings, handling fractions and units cleanly.
- **Status:** Working prototype, fraction bug fixed 06-24.
- **Notes:** [[MOC-Recipe-Newsletter.md]]
- **Next actions:**
  - Add metric / imperial toggle
  - Test against the ten most-cooked recipes

### Newsletter photo pipeline
- **What it does:** Batch-resizes and renames shoot photos for the newsletter.
- **Status:** Half built.
- **Next actions:**
  - Make it copy originals before editing (nearly lost a shoot to in-place edits)

---

## Someday / maybe

- A short e-book of the ten most-replied-to recipes: parked until there are 30 issues to pull from
- A paid tier with a monthly live cook-along: parked until the free list clears 5,000
- A second newsletter on baking specifically: parked, do not start (see the max-3 rule)

---

## Done / retired

| Project | Why it is here |
|---------|----------------|
| Weekly meal-plan PDF | Abandoned. Took a full day each week, almost nobody opened it. |
| Food TikTok | Stopped. Wrong audience for a recipe newsletter, ate all my evenings. |
| Restaurant review blog | Superseded. Folded the good parts into the newsletter, killed the rest. |
