# Brown butter is a flavour multiplier, not a substitution

Swapping melted butter for browned butter in a recipe does not just change the
butter. It changes the ceiling of the whole dish. The toasted milk solids add a
nutty, almost caramel note that reads as "someone who knows what they are doing
made this", even in an otherwise plain cookie or plain pan sauce. It is the
highest flavour-per-effort move I know: two extra minutes at the stove, no new
ingredients, a visibly better result.

**Why it matters:** For a weeknight newsletter, effort-per-flavour is the metric
that matters most to readers. Brown butter is the cleanest example of a
technique that upgrades a dish without adding a shopping trip. It is a repeatable
angle: "the two-minute version of X that tastes like the two-hour version."

**Where it came from:** Testing the rhubarb galette (worklog 2026-06-23) and
noticing the browned-butter batch got every reply. Also [[Literature-Note-salt-fat-acid-heat.md]].

**Connects to:**
- [[Permanent-Note-a-recipe-intro-must-earn-the-scroll.md]]: this is exactly the kind of concrete payoff an intro should promise
- [[MOC-Recipe-Newsletter.md]]: lives under the "high-leverage technique" thread

#permanent-note #technique
