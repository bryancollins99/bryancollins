# Map of Content - The Weeknight Table (recipe newsletter)

#moc #newsletter

**Created:** 2026-06-29
**Type:** MOC (hub note)
**Purpose:** Collect every note that feeds the weekly recipe newsletter, so I can
find an angle in two minutes instead of staring at a blank draft.

## Overview

The Weeknight Table is a Friday newsletter of one tested recipe plus the
technique behind it. This map is where I look when it is Thursday and I need an
angle. Notes are grouped by the role they play in a newsletter: the technique
that anchors the issue, the writing craft that shapes it, and the sources I am
still mining.

## Core notes (techniques that can anchor an issue)

- [[Permanent-Note-brown-butter-is-a-flavour-multiplier.md]]: two-minute upgrade that tastes like two hours
- {future: "salting from a height" as its own note}

## Craft notes (how the issue gets written)

- [[Permanent-Note-a-recipe-intro-must-earn-the-scroll.md]]: lead the intro with the payoff, not the memoir

## Sources still being mined

- [[Literature-Note-salt-fat-acid-heat.md]]: at least two more permanent notes in here (acid as the balancing lever; salt timing)

## Open threads

- I have techniques and craft, but no note yet on *sequencing* an issue (what
  comes first, the recipe or the principle). Write it after three more issues.
- Which issues got the most replies, and do they share a technique? No note yet.
  This is a retrieval question the tags should answer.

## See also

- [[Project-Index.md]]: where the newsletter sits among everything else I run
