# Salt, Fat, Acid, Heat (Samin Nosrat)

An informal summary of what I took from the book, in my own words, for the
newsletter.

- The core claim is that four elements decide how food tastes, and if you
  understand them you can cook well without following recipes. Recipes are just
  one frozen instance of these variables.
- Salt is about amount and timing, not just presence. Salting early and from a
  height changes the result more than the quantity does.
- Fat carries flavour and creates texture. Choosing the right fat is a flavour
  decision, not just a lubrication decision. (This is where brown butter clicked
  for me.)
- Acid is the balancing lever most home cooks under-use. A dish that tastes
  "flat" is usually short on acid, not salt.
- The teaching move I want to steal: explain the principle so the reader can
  improvise, then give the recipe as an example of the principle. That is the
  opposite of most food writing, which gives the recipe and hides the principle.

**Quote worth keeping:**
> "Salt has a greater impact on flavor than any other ingredient."

**Source:** Samin Nosrat, *Salt, Fat, Acid, Heat*, intro and the Fat chapter.

**Turns into:** The idea that food writing should teach the principle first
became [[Permanent-Note-a-recipe-intro-must-earn-the-scroll.md]]. The fat-as-a-choice
idea fed [[Permanent-Note-brown-butter-is-a-flavour-multiplier.md]].

#literature-note #reading
