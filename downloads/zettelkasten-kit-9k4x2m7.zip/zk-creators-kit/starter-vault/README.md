# Your starter vault

This folder is your knowledge system in miniature. Copy it somewhere permanent
(your home folder, Documents, a synced Dropbox folder, anywhere but Downloads),
rename it to whatever you like, and it becomes your vault. Everything is plain
`.md` text. There is no app to install and nothing to log into. If you can open
a text file, you can run this system.

## What is in here

```
starter-vault/
├── README.md            ← you are here
├── templates/           ← blank templates. Copy one whenever you make a new note.
│   ├── Permanent-Note.md
│   ├── Literature-Note.md
│   ├── MOC.md              (Map of Content: a hub/index note)
│   ├── Project-Index.md    (directory of everything you run)
│   └── Active-Projects.md  (the max-3 discipline tracker)
└── notes/               ← where your actual notes live. Filled examples included.
    ├── Permanent-Note-brown-butter-is-a-flavour-multiplier.md
    ├── Permanent-Note-a-recipe-intro-must-earn-the-scroll.md
    ├── Literature-Note-salt-fat-acid-heat.md
    ├── MOC-Recipe-Newsletter.md
    └── Project-Index.md    (a filled-in example)
```

The example notes are written by one fictional person: a freelance food writer
running a weekly recipe newsletter called The Weeknight Table. They exist so you
can see finished notes, and how they link to each other, before you write your
own. Read them, then delete them and start yours.

## The note types

- **Literature note**: what you took from something you read, watched, or heard,
  in your own words. A holding pen.
- **Permanent note**: one finished idea in your own words, written so future-you
  understands it with no other context. The destination. Literature notes feed
  these.
- **MOC (Map of Content)**: a hub note that indexes the notes on one topic. You
  make one only when a topic has grown enough that you feel lost without it.
- **Project-Index / Active-Projects**: the two organising notes that keep the
  whole vault (and your workload) honest.

`METHOD.md` in the kit root explains how these fit together. Read it next.

## The naming convention (this is the important part)

Your file **name is the note**. Because everything is flat text, a good filename
is what makes a note findable months later. Two rules:

1. **Descriptive, not timestamped.** Name the file after the idea, not the date.
   `Permanent-Note-brown-butter-is-a-flavour-multiplier.md` tells you what is
   inside. `Note-2026-06-29-1.md` tells you nothing.

2. **Type prefix, then kebab-case title.** Start with the note type, then the
   idea in lowercase words joined by hyphens:

   ```
   Permanent-Note-<the-idea-as-a-short-claim>.md
   Literature-Note-<source-title>.md
   MOC-<topic>.md
   ```

The payoff: when you list your notes alphabetically, everything of one type sits
together, and the titles read like a table of contents. When you search for
"butter", the filename alone tells you which note you want. The `scripts/` folder
in the kit includes a helper (`rename-generic-files.py`) that converts any
old-style timestamped filenames to this convention automatically.

## Linking notes

Inside a note, point to another note with double brackets around its filename:

```
See also [[Permanent-Note-a-recipe-intro-must-earn-the-scroll.md]].
```

This is a plain-text convention, not a feature you need an app for. It is the
thread you follow to move from one idea to a related one. `METHOD.md` explains
why the links, not the notes, are where the value compounds.
