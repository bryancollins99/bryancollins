# The Zettelkasten for Creators Kit

A complete, plain-text thinking system you own forever. Capture what you read and
what you make, turn it into ideas you can actually find, and never start from a
blank page again. No app, no account, no subscription, no lock-in. Just a folder
of text files and a method that has been refined over years.

**Philosophy: fill the well.** Good writing, good products, and good decisions
all come out of a body of connected ideas. This kit is how you build that body,
a little at a time, from your real reading and your real work.

---

## What's in the box

| Piece | What it is |
|---|---|
| **`starter-vault/`** | A ready-to-use notes folder. Copy it, rename it, and it is your system. Includes the folder structure, the naming convention, and worked examples. |
| **`starter-vault/templates/`** | Five fill-in-the-blank templates: **Permanent Note**, **Literature Note**, **MOC** (Map of Content), **Project-Index**, and **Active-Projects** (the max-three tracker). |
| **`starter-vault/notes/`** | Four finished example notes plus a filled-in Project-Index, so you see the format before you write a word. |
| **`scripts/`** | Three optional maintenance helpers: find duplicate lines, auto-tag untagged notes, rename timestamped files into findable ones. |
| **`METHOD.md`** | The heart of the kit. The five-move thinking workflow in plain English: capture, atomic notes, linking, maps of content, retrieval. |
| **`SETUP.md`** | The assume-nothing guide. Zero terminal experience required; explains the own-your-files pitch and optional git backups. |

## Who it's for

Writers, newsletter creators, course-makers, founders, and anyone who reads and
makes things and is tired of good ideas evaporating. If you have ever thought
"I know I read something about this" and could not find it, this is the fix.

You do not need to be technical. If you can open a text file, you can run this
system. The scripts and the git backup are optional power-ups, not requirements.

## Quick start

1. **Unzip** this kit somewhere permanent (not Downloads).
2. **Read `METHOD.md`.** It is short and it is the whole idea. Fifteen minutes.
3. **Open `starter-vault/`.** Read its README for the folder layout and the
   note-naming convention, then look at the example notes in `starter-vault/notes/`.
4. **Start capturing.** One worklog line when you finish something; one literature
   note when you read something worth keeping. That habit is the engine.
5. **Refine occasionally.** On a slow morning, turn your best captures into
   permanent notes (`templates/Permanent-Note.md`) and link them together.

Never opened a terminal? **`SETUP.md`** assumes nothing and walks you through it,
including free, offline backups with git.

## Where this sits

This kit is the **thinking layer**: it fills the well with connected, findable
ideas. It stops at retrieval, on purpose.

Turning those notes into a steady stream of published drafts, newsletters, and
posts is a separate job, the **output layer**, handled by my companion product
**The Builder's Pipeline**. You do not need it to get full value here. `METHOD.md`
explains exactly where one ends and the other begins.

## Support & license

Personal-use license: see LICENSE. Questions, or something not working? Email
bryan@becomeawritertoday.com. Every message gets read.

- Bryan
