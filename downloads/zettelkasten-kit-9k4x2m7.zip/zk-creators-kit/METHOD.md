# The Method

This is the thinking system. Not an app, not a productivity hack: a way of
turning the things you notice into ideas you can find and build on later. It has
five moves. You will not do all five every day. Most days you do the first one.
The rest happen when they happen.

The whole thing runs on plain text files and one habit: **write it down where
you can find it again.**

---

## The shape of it

```
   capture  ->  atomic notes  ->  linking  ->  maps of content  ->  retrieval
  (messy in)   (one idea each)   (connect)    (index by topic)    (find it later)
                                                                        |
                                                                        v
                                                        hand off to your output layer
```

Everything flows one way, from messy to structured, but you never do it all at
once. You capture constantly. You refine occasionally. You retrieve when you need
something. The structure builds up in the background, a little at a time.

---

## Move 1: Capture

Whenever you read something worth keeping, finish a piece of work, or have a
thought you do not want to lose, write it down. Immediately. Badly is fine.

Two kinds of capture matter most:

- **A worklog line.** One line, whenever you finish something: what you did, and
  one thing you learned. `2026-06-24: Fixed the recipe scaler's fraction bug.
  Recipes are structured data wearing prose.` That is the whole habit. It takes
  ten seconds and it is the richest raw material you have, because it is about
  your actual work, not someone else's.
- **A literature note.** When you read a book, listen to a podcast, or watch a
  talk and something lands, write down what you took from it *in your own words*.
  Not a highlight. Highlights are forgotten. A sentence you wrote yourself is
  remembered. Use `templates/Literature-Note.md`.

Capture is the only non-negotiable move. If you only ever do this one, the system
still pays off. Everything after this is refining raw material you already have.

The enemy here is folders. Do not stop to decide where a capture "should go".
Filing is not thinking, and a fresh capture filed into a folder is a capture you
will never see again. Capture flat, into one place. Structure comes later, and it
comes from links, not folders.

## Move 2: Atomic notes

Every so often (a slow morning, a quiet Friday) you take your captures and your
literature notes and you distil the good ones into **permanent notes**.

A permanent note holds exactly one idea, written in your own words, so that
future-you understands it with no other context. The title *is* the idea, stated
as a short claim: not "Butter" but "Brown butter is a flavour multiplier, not a
substitution". Use `templates/Permanent-Note.md`.

"Atomic" means one idea per note. The test: if you find yourself writing "and
another thing", stop. That second thing is a second note. This feels fussy at
first and turns out to be the entire secret. One idea per note is what makes the
next two moves possible, because a single idea can connect to many others, while
a note about six things connects cleanly to nothing.

You will not turn every capture into a permanent note, and you should not try.
Most captures are scaffolding. A few are load-bearing. Permanent notes are only
the load-bearing ones.

## Move 3: Linking

This is where the value is. Not in the notes: in the links between them.

When you write or revisit a permanent note, ask: what does this connect to? What
does it support, contradict, or extend? Then link it, with a line of context:

```
Connects to:
- [[Permanent-Note-a-recipe-intro-must-earn-the-scroll.md]]: a concrete payoff an intro can promise
```

A `[[double-bracketed filename]]` is just a plain-text pointer to another note.
No app required. The context line is not optional: "related to X" is useless in a
year; "contradicts X because Y" is a thought you can use.

Why links beat folders: a note can only live in one folder, but it can link to
twenty other notes. Your recipe-technique note connects to a writing-craft note
connects to a business note about what readers reply to. Those threads are where
new ideas actually come from, and folders sever every one of them. A note with no
links is a note you will never find and never use. Link as you go, or the system
quietly rots into a pile of orphans.

## Move 4: Maps of Content (MOCs)

At some point a topic grows enough notes that you feel a little lost in it. Five,
maybe six notes that all point at each other. That is the signal to make a **Map
of Content**: a hub note that indexes the notes on one topic, each with a line of
context, grouped by the role they play. Use `templates/MOC.md`.

Do not make MOCs up front. An empty MOC is a folder wearing a costume. You make
one the day you need one, and not before. When you do, it becomes the front door
to that topic: the note you open first, that points you to all the others. See
`starter-vault/notes/MOC-Recipe-Newsletter.md` for a worked example.

Two organising notes deserve to exist from day one, because they map your *work*
rather than your ideas:

- **Project-Index**: a directory of everything you run. The honest, boring list.
- **Active-Projects**: the same list with a hard cap of three things in flight.
  You cannot start a fourth until one ships or dies. The constraint is the point:
  it is what stops a knowledge system full of shiny ideas from turning into a
  graveyard of half-built projects.

## Move 5: Retrieval

The reason for all of it. A good system is one you can get things *out* of.

You retrieve three ways, in plain text, with no special software:

- **Search the filenames.** Because every note is named after its idea (see the
  naming convention in `starter-vault/README.md`), searching your notes folder
  for "butter" or "intro" lands you on the right note by its name alone.
- **Search the tags.** The `#permanent-note`, `#writing`, `#newsletter` style
  tags let you pull every note of a kind. `scripts/auto-tag.sh` can add these to
  old untagged notes in bulk.
- **Follow the links.** Open a MOC or any note, and walk the `[[links]]` to
  related ideas. This is the one that surprises you, because it surfaces
  connections you forgot you made.

The `scripts/` folder exists to keep retrieval healthy at scale: rename
timestamped junk files into findable ones, tag the untagged, and flag corrupted
duplicates. Run them occasionally. A findable note is a note that pays off.

---

## Where this ends, and what comes next

This system's job ends at retrieval. You now have a body of connected, findable
ideas drawn from your real reading and your real work. That is the thinking
layer, and it is complete on its own: better notes, clearer thinking, ideas you
can actually find.

The obvious next question is "so how do I turn this into published writing?" That
is a different job, and deliberately not this product's job. Turning your notes
and worklog into drafts, newsletters, and posts on a repeatable schedule is the
**output layer**: it is exactly what my companion product, **The Builder's
Pipeline**, automates. This kit fills the well. That one draws from it.

You do not need it to get full value here. But when your vault is full of good
notes and you are tired of staring at a blank draft, that is the door it opens.

Fill the well first. This is how.
