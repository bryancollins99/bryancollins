# SETUP.md: the assume-nothing guide

This gets you from "I bought a zip file" to "I have a working notes system I own
forever" in about fifteen minutes. It assumes you have never opened a terminal
and have never used git. That is fine. You will need the terminal for exactly two
optional things (the helper scripts and the backup step); the notes system itself
is just text files you can open in any editor.

If you get stuck at any step, email bryan@becomeawritertoday.com with the step
number and what your screen says.

---

## What you are actually setting up

Nothing, really. That is the pitch.

Your entire knowledge system is a folder of plain `.md` (Markdown) text files.
There is no app to buy, no account to create, no subscription, no company that
can raise its prices or shut down and take your notes with it. You can open,
edit, and read every file in this system with TextEdit, Notepad, or any editor,
on any computer, for the rest of your life. That is the point of doing it this
way, and it is worth understanding before you start.

**Why plain text and not Notion, Obsidian, Roam, or Evernote?**

Those tools are genuinely nice to use. The trade is lock-in. Your notes live in
their database, in their format, reachable through their app, under their pricing.
When (not if) you want to leave, or they change terms, or they fold, your years of
thinking are held hostage in an export button.

Plain text has no export button because it needs none. The files are already
yours, already open, already readable everywhere. A folder of Markdown will open
in the year 2050 exactly as it opens today. You are not buying convenience at the
cost of ownership. You own it outright. Add git (Step 4) and you also get a
complete, free, offline history of every change you ever make.

---

## Step 1: Unzip the kit

Double-click the downloaded `zk-creators-kit.zip`. Move the resulting
`zk-creators-kit` folder somewhere permanent: your home folder or Documents. Do
not leave it in Downloads, where you will lose it.

## Step 2: Make it your vault

Inside the kit is a folder called `starter-vault`. That folder is your notes
system. You have two easy options:

- **Simplest:** copy `starter-vault` somewhere you will remember (e.g. a folder
  called `notes` in your home folder) and rename it to whatever you like.
- **Or** just work inside `starter-vault` where it is.

Open `starter-vault/README.md` and `METHOD.md` in any text editor and read them.
That is genuinely most of the learning. Then open one of the example notes in
`starter-vault/notes/` to see what a finished note looks like.

You can start writing notes right now, in any editor, with zero further setup.
Everything below is optional power-ups.

## Step 3: Pick an editor (optional but nice)

Any text editor works. Two free upgrades worth knowing about:

- **VS Code** (https://code.visualstudio.com) opens your whole notes folder in a
  sidebar and previews Markdown side by side. Free, Mac and Windows.
- Any Markdown editor you already like is fine. The files are just text; no
  editor can lock you in, because there is nothing proprietary to lock.

You never *need* a special app. That is the whole idea. If TextEdit or Notepad is
what you have, that is what works.

## Step 4: Turn on backups with git (optional, strongly recommended)

Git gives you a free, offline, complete history of your notes: every version of
every file, forever, with the ability to undo any change. This is the safety net
that makes plain text better than any app's cloud sync, because it is yours and
it works with no account.

You only ever need four commands. In the terminal (Cmd+Space, type `Terminal`,
Enter on Mac; Windows key, type `PowerShell`, Enter on Windows):

1. Go into your notes folder. Type `cd ` (with a trailing space), then drag the
   folder from Finder/Explorer onto the terminal window, and press Enter.
2. Turn on history for this folder (one time only):

       git init

3. Save a snapshot (do this whenever you have done some writing):

       git add .
       git commit -m "notes update"

That is it. Every `commit` is a permanent, restorable snapshot. If you ever
delete or wreck a note, your whole history is sitting safely in the folder. No
account, no cloud, no monthly fee. (If `git` is not installed, the terminal will
tell you and offer to install it on Mac; on Windows, get it from
https://git-scm.com.)

Want the snapshots copied to another machine or the cloud too? A free GitHub
account plus `git push` does that, but it is genuinely optional. The local
history above already protects you.

## Step 5: The maintenance scripts (optional)

The `scripts/` folder has three small helpers for when your vault gets big:

- `find-duplicates.sh`: flags notes with repeated lines (a common export bug)
- `auto-tag.sh`: adds topic tags to notes that have none
- `rename-generic-files.py`: renames timestamped junk filenames to findable ones

Each one takes the path to your notes folder. From inside the `scripts` folder:

    bash find-duplicates.sh /path/to/your/notes
    bash auto-tag.sh /path/to/your/notes
    python3 rename-generic-files.py /path/to/your/notes --dry-run

(Drag your notes folder onto the terminal to fill in the path. The `--dry-run` on
the last one previews the renames without changing anything: always run that
first.) You do not need these on day one. They are here for the month you look up
and realise you have four hundred notes.

## Step 6: Build the habit

The setup is done. The system only works if you use Move 1 from `METHOD.md`:

- One worklog line whenever you finish something.
- One literature note whenever you read something worth keeping.

Do that for two weeks. Then spend one slow morning turning the best captures into
permanent notes, and linking them. That rhythm, capture constantly, refine
occasionally, is the entire practice.

Welcome to a notes system you actually own.
