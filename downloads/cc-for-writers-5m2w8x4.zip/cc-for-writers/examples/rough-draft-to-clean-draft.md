# Example session: rough draft to clean draft

> A worked example of an editing session. Fabricated, but the real shape of a
> real one. Same fictional writer as the other examples: Jo Merrow, a
> freelancer, here working on a chapter of a short nonfiction book. Jo set up a
> `CLAUDE.md` for the book from the `writing-project.CLAUDE.md` template, so
> Claude already knows the reader, the voice, and the file-safety rules before
> the session starts.

Italic notes explain the method. Everything else is the session.

---

*The key idea of an editing session is the opposite of a drafting session. When
you draft, you ask for thinking, then output. When you edit, you ask for
diagnosis, then targeted fixes. You do not say "make this better." You find out
what is weak first, then decide what to cut into. Diagnosis before surgery.*

**Jo:** Read @chapters/chapter-04-rough.md. Do not rewrite it. Tell me the three
weakest moments and why each one is weak, in order of worst first.

*Jo used an `@` file reference to pull the chapter straight into the
conversation. Typing `@` and the path (Claude Code offers to complete it as you
type) hands Claude the file's contents directly, so it does not have to go
looking. Jo also told Claude explicitly not to rewrite. That "do not rewrite
yet" is deliberate. It keeps Jo in control of what changes, instead of getting
back a wall of edits and having to reverse-engineer what happened.*

**Claude:** Read the chapter. The three weakest moments, worst first.

1. **The opening two paragraphs (weakest).** They are throat-clearing. You spend
   180 words explaining what the chapter will cover before the chapter starts.
   Your reader, a working freelancer who is tired, does not need the preview.
   The actual chapter begins at paragraph three, with the line "The first
   invoice I ever sent was for the wrong amount." That is your real opening. The
   180 words above it are a runway to an aeroplane that could already be flying.

2. **The middle example runs abstract.** Around the section on chasing late
   payments, you make the point ("be boring and relentless") but you never show
   it. There is no scene, no specific email, no number. It is the one place the
   chapter tells instead of shows, and it sits right where the reader most wants
   a concrete move they can copy.

3. **The ending softens.** The last paragraph adds three new small ideas
   (contracts, deposits, a line about accountants) instead of landing the one
   big one. It reads like you were reluctant to stop. The strong ending is
   hiding one sentence up: "Getting paid is not the reward for the work. It is
   part of the work." Everything after that is you clearing your throat on the
   way out.

I have not changed anything. Which of these do you want to work on?

*Three specific, located problems, each with the reason and the fix implied.
This is worth far more than a silent rewrite, because Jo now understands the
draft better and can decide what to protect. Note Claude obeyed the "do not
rewrite" instruction and touched no files.*

**Jo:** Agree on all three. Let us do them one at a time. Start with number one.
Cut the runway. Do not touch anything else in the file yet. Save your version to
a new file so I can compare, do not overwrite my rough draft.

**Claude:** Saved the change to `chapters/chapter-04.edited.md`, leaving your
`chapter-04-rough.md` untouched so you can compare. I made exactly one change:
deleted the first two paragraphs so the chapter now opens on "The first invoice
I ever sent was for the wrong amount." Nothing else moved.

Here is the new opening for a quick look:

> The first invoice I ever sent was for the wrong amount. Too low, of course.
> I had added a discount nobody asked for, out of a nervousness I would spend
> the next three years unlearning.

Compare the two files when you are ready. If you are happy, we move to number
two, the late-payment example.

*Two of the file-safety rules from the template just did their job without Jo
having to ask. Claude saved the edit to a new, clearly named file and left the
original alone, and it made one change at a time instead of "improving" the
whole chapter. Jo can open both files side by side and decide. Nothing was lost.
See SAFETY.md for why this is the default worth insisting on.*

**Jo:** Compared them, the cut is right. Keep going on the edited file now.
Number two: the late-payment section. Do not invent a story. Ask me for the real
details and then write the scene.

**Claude:** I will not invent it. To write the scene I need the real specifics.
Three quick questions:

1. What did your standard late-payment chase actually say? A rough version of
   the wording is fine.
2. How late was the worst one, and did it eventually pay?
3. Was there a particular line or move that finally worked?

Give me those and I will write the concrete scene into the edited file, in your
voice, showing "boring and relentless" instead of stating it.

*This is the sources-are-sacred instinct applied to a memoir detail. Even in a
personal book, the rule "never invent facts" means Claude asks for the real
story instead of manufacturing a plausible one. A made-up anecdote in your own
book is still a lie, and the briefing stops it at the door.*

**Jo:** Good questions. [Jo answers with the real details.] Write it.

**Claude:** Written into `chapters/chapter-04.edited.md`, replacing the abstract
paragraph with the scene you described. One change, same file, original rough
draft still untouched. The ending fix (number three) is still waiting whenever
you want it.

**Jo:** That is the one. Do number three the same way, then I will read the
whole edited file top to bottom myself.

*The rhythm of a good edit: diagnose the whole, then fix one located thing at a
time, comparing as you go, with the writer reading the final result personally.
Claude removes the drudgery of restructuring and the fear of the blank rewrite.
Jo keeps every real decision: what is weak, what to cut, what the true story is,
and whether the final draft earns its place. That division of labour is the
entire method.*
