# Example session: a question to a researched brief

> A worked example of a research session. Fabricated, but the true shape of a
> real one. Same fictional writer, Jo Merrow, here researching a feature article
> rather than writing a newsletter. Jo set up a `CLAUDE.md` from the
> `research-project.CLAUDE.md` template, so the one rule that matters most,
> sources are sacred, is loaded before the session starts. The research folder
> has a `sources/` subfolder holding a handful of documents Jo saved as plain
> text.

Italic notes explain the method. Everything else is the session.

---

*A research session lives or dies on one thing: does the writer trust the
output? The whole method here is built to make the answer yes, by keeping every
claim tied to a real source and getting an honest map of what the sources do and
do not cover before writing a word.*

**Jo:** I am writing a feature on whether the four-day week actually keeps
productivity steady. Before anything else, read everything in `sources/` and
tell me two things: what these sources genuinely establish, and what they do not
cover. Do not draft, and do not add anything from outside these files.

*This is the coverage pass, and it is the most important move in research. Jo is
not asking for an answer yet. Jo is asking for an honest inventory: what is here,
what is missing. That inventory is what stops a writer confidently publishing a
gap.*

**Claude:** Read all six files in `sources/`. Here is the honest map.

**What the sources establish:**

- Three of the six are write-ups of employer trials (`source-uk-trial-2022.txt`,
  `source-nz-firm.txt`, `source-consultancy-report.txt`). Across them, most
  participating firms reported roughly steady or slightly higher output on four
  days, measured mainly by revenue and self-reported performance.
- `source-academic-review.txt` is the strongest methodologically. It notes that
  most trials are voluntary, which means firms that opted in were already likely
  to succeed. It treats the results as promising but not conclusive for that
  reason.
- `source-worker-survey.txt` is consistent that workers report lower burnout and
  would not want to go back.

**What the sources do not cover:**

- No long-run data. The longest trial here runs twelve months
  (`source-uk-trial-2022.txt`). Nothing tells you whether the effect holds at
  three years.
- Almost no data on customer-facing or shift work. The firms are mostly office
  and knowledge work. `source-consultancy-report.txt` says this explicitly.
- The two employer sources disagree on one point, which you should not paper
  over: `source-nz-firm.txt` credits the gain to focus and fewer meetings, while
  `source-consultancy-report.txt` credits it partly to quiet attrition, staff
  who wanted the old pace leaving. That is a real tension worth the article.

Do you want a synthesis, or to fill a gap first?

*Three things just happened that the briefing made happen. Claude reported only
what the files support, it named the gaps plainly instead of smoothing them
over, and it flagged where two sources disagree rather than quietly choosing
one. That last one is the difference between a researcher and a search engine.*

**Jo:** That disagreement is the story. Draft a short brief, not the article
itself: the claim, the evidence for it, the honest caveats, and that tension
between the two sources. Cite which source backs each point so I can check
every line.

**Claude:** Brief below. Every point names its source in brackets.

> **Working claim:** The four-day week appears to hold productivity roughly
> steady in office and knowledge work over the short term, but the evidence is
> promising rather than settled, and at least one source suggests the gains are
> not entirely what they look like.
>
> **Evidence for:**
>
> - Most firms in the trials reported steady or slightly higher output on four
>   days [source-uk-trial-2022.txt; source-nz-firm.txt;
>   source-consultancy-report.txt].
> - Workers report lower burnout and strong reluctance to return to five days
>   [source-worker-survey.txt].
>
> **Honest caveats:**
>
> - Trials are voluntary, so the firms studied were pre-selected for likely
>   success [source-academic-review.txt].
> - No data beyond twelve months; long-run durability is unknown
>   [source-uk-trial-2022.txt].
> - Little to no evidence for shift work or customer-facing roles
>   [source-consultancy-report.txt].
>
> **The tension to build the piece around:**
>
> - One source attributes the productivity hold to genuine efficiency, fewer
>   meetings and sharper focus [source-nz-firm.txt]. Another attributes it
>   partly to quiet attrition, employees who preferred the older pace leaving
>   the firm [source-consultancy-report.txt]. If the second reading is right,
>   some of the "productivity gain" is a changed workforce, not a changed week.
>   The sources here do not resolve which effect dominates.

Every claim above traces to a file you can open. The one thing I want to flag: I
have written the tension as an open question, because the sources genuinely do
not settle it. If you want a stronger conclusion, you will need a source that
does, and it is not in this folder.

*This is the payoff of the sources-are-sacred rule. Jo can fact-check the brief
in minutes, because every line points at the file behind it. And Claude did not
manufacture a tidy conclusion the evidence cannot support. It said, in effect,
"here is exactly how far the sources take you, and no further." That honesty is
what makes the research usable.*

**Jo:** That is a brief I can build on. Save it to `notes/brief-four-day-week.md`
and leave my sources untouched.

**Claude:** Saved to `notes/brief-four-day-week.md`. Nothing in `sources/` was
touched; those files stay exactly as you saved them.

*The research method in four moves: load the sources into a briefed session, ask
for an honest coverage map before anything else, synthesise with a citation on
every claim, and keep the raw sources read-only. Claude does the reading and the
tracing at speed. Jo brings the judgment about which tension is the story and how
far the evidence really reaches. Neither could do the other's job, which is
exactly why the pairing works.*
