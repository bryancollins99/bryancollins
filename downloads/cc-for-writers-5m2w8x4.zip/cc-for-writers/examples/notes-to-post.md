# Example session: messy notes to a finished post

> This is a worked example so you can see the method in action before you try
> it. It is fabricated, but it is the real shape of a real session. The writer
> is a fictional freelancer, Jo Merrow, who runs a weekly newsletter called The
> Middle Draft for other freelance writers. Jo has already set up a
> `CLAUDE.md` for the newsletter (from the `newsletter.CLAUDE.md` template in
> this kit), so Claude starts the session already knowing the reader, the
> format, and Jo's voice.

Notes in italics like this explain what is happening and why. Everything else
is the session.

---

*Jo opens the terminal, changes into the newsletter folder, and runs `claude`.
Because a `CLAUDE.md` sits in that folder, Claude loads it automatically before
Jo types anything. Jo does not re-explain the newsletter. That work is already
done.*

**Jo:** Here are my messy notes from this week. I want to turn them into a
newsletter issue. Do not draft yet. First read them and tell me what the single
strongest idea is, and one structure that would earn the open.

```text
- lost a client monday. the big one. 40% of my income.
- panicked for about a day
- then realised i'd let them become 40%. that was the actual mistake, not losing them
- "client concentration" - borrowed the term from finance/investing
- rule i'm making: no client is more than 25% of income. if one creeps up, i go find work to balance it
- took me 4 years to learn this the expensive way
- the calm came from having a rule, not from the money coming back (it hasn't yet)
```

*This is the whole method in one move: ask for thinking before output. Jo did
not say "write my newsletter." Jo asked Claude to find the idea and propose a
shape first, and told it explicitly not to draft. One good structure beats three
rounds of fixing a draft that started in the wrong place.*

**Claude:** Read them. Here is the read.

The strongest idea is not "I lost a client." It is your reframe: the loss
exposed a mistake you had already made, letting one client become 40% of your
income. The borrowed term "client concentration" is your hook, because it gives
a familiar feeling a precise name. And the sharpest, least expected line is the
last one: the calm came from making a rule, not from the money returning. That
is the payoff most writers would not think to end on.

A structure that earns the open:

1. Open in the panic. Monday, the email, 40% gone. Short sentences.
2. Turn: the day-later realisation that the real mistake was mine, made years
   ago.
3. Name it: "client concentration," borrowed from investing, one plain line on
   what it means.
4. The rule: no client over 25%, and what I do when one creeps up.
5. End on the honest payoff: the money is not back yet, and I am calm anyway,
   because the calm came from the rule.

One idea, one takeaway, ends on the surprising note. Want me to draft this?

*Notice Claude is steering toward the reader and the format from the briefing:
one idea, one takeaway, a hook, an honest voice. That is the CLAUDE.md working.*

**Jo:** Yes, draft it in my voice. Around 600 words. Leave anything you are
unsure about marked so I can check it.

**Claude:** Draft below. I marked two spots.

> **Subject:** the client I let become 40 percent of my income
>
> On Monday I lost my biggest client. Forty percent of my income, gone in one
> polite email.
>
> I panicked for about a day. Refreshed my inbox like it owed me money. Did the
> maths on how many months I had. You know the day. Maybe you have had it.
>
> Then something turned. I realised the client leaving was not really the
> mistake. The mistake was older and it was mine: I had let one client grow to
> forty percent of everything I earned, and I had called that stability because
> the invoices were big and they always paid.
>
> There is a word for this, and I stole it from investing. Client
> concentration. It is the risk you carry when too much of your income sits in
> one place. It feels safe right up until the day it is not, and then it is the
> only thing that matters.
>
> So I am making a rule, and I am telling you so it sticks. No single client
> gets to be more than a quarter of my income. If one starts creeping past
> that, I do not celebrate. I take it as a signal to go and find work that
> balances it out, while the good client is still happy and still paying.
> [CHECK THIS: you said 25 percent in your notes. Confirming that is the number
> you want in print.]
>
> It took me four years to learn this, and I learned it the expensive way,
> which is the only way I ever seem to learn anything. [CHECK THIS: worth
> saying which four years, or leave it vague?]
>
> Here is the part I did not expect. The calm did not come back when the money
> did, because the money has not come back yet. The calm came from having the
> rule. From knowing that whatever happens next, I will not be standing in this
> exact spot again, because the structure that put me here is gone.
>
> That is the quiet trade nobody tells you about freelancing. You cannot
> control whether a client stays. You can absolutely control whether losing one
> is a wobble or a catastrophe. The rule is how you decide which.
>
> Talk soon,
> Jo

The two marked spots are the only decisions I could not make for you. The rest
follows your notes and your usual shape.

*Claude marked what it could not know instead of inventing it. The briefing told
it never to invent facts and to flag anything uncertain. That single rule is
what makes the draft trustworthy: you are checking two clearly labelled spots,
not hunting the whole thing for quiet fabrications.*

**Jo:** Good. Cut "Refreshed my inbox like it owed me money," it is too cute for
this one. And the sign-off is always exactly "Talk soon, Jo" on two lines,
remember that.

**Claude:** Cut the line. And noted, I will remember that for this newsletter:
the sign-off is always "Talk soon," then "Jo" on the next line. I will use it
from now on without being asked.

*This is Habit 3 from WORKFLOW.md: teach it as you go. Jo gave a correction that
will be true every week, so Jo said "remember that." Claude saved it to memory.
Next week's session will start already knowing the sign-off. The tool just got
one notch more like Jo, permanently. See MEMORY.md for how that saving works.*

**Jo:** Perfect. I will take it from here and paste it into my sending tool.

*The method drafts; the writer decides what ships. Jo did the thinking Claude
cannot do (which idea, which cut, what is too cute) and let Claude do the
labour (the blank page, the shaping, the first 600 words). Fifteen minutes,
start to finished draft, and it sounds like Jo, because Jo never handed over the
voice, only the typing.*
