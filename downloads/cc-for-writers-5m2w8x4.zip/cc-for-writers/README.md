# Claude Code for Writers

You installed Claude Code. Here is the writer's setup nobody shows you.

Most people open Claude Code and start typing. They get a decent answer, close
the window, and next time it has forgotten everything: their project, their
voice, their rules. They re-explain themselves every session, forever.

This kit is the fix. It takes you from "installed it, now what?" to a writing
setup where Claude knows your reader, writes in your voice, follows your house
style, and does not wreck your files. Not by learning to code. By writing Claude
a short briefing it reads automatically, every time, and by using a few plain
habits that turn a clever stranger into a partner who gets better the longer you
work together.

**The idea in one line: content and drafts are the output; a briefed, remembering
setup is the engine.** Set it up once, and you never start from a cold, forgetful
blank page again.

---

## What is in the box

| Piece | What it is |
| --- | --- |
| **`templates/`** | Three ready-made briefing files (`CLAUDE.md` templates), written for writers, not coders. One for a **book or long manuscript**, one for a **newsletter**, one for a **research project**. Each comes pre-loaded with voice rules, house-style rules, and file-safety rules. You fill in the blanks. |
| **`QUICKSTART.md`** | The first five things to set up, assuming you have never opened a terminal. About half an hour, start to finish. |
| **`WORKFLOW.md`** | The method: what to do instead of just typing. Four habits, none of them technical. |
| **`MEMORY.md`** | How to make Claude remember your voice and preferences across sessions. The feature almost no writer knows exists, in plain English. |
| **`SAFETY.md`** | How not to wreck your files, including a real undo button and worktrees in one plain paragraph. |
| **`examples/`** | Three worked example sessions, annotated line by line: messy notes to a finished post, a rough draft to a clean draft, and a question to a researched brief. |

## Who it is for

Writers who have heard of Claude Code, maybe installed it, and bounced off the
developer framing. Newsletter writers, authors, freelancers, journalists,
anyone who writes for a living and wants the tool without the jargon.

You do not need to be technical. If you can open a text file and drag a folder,
you can run this. The one terminal skill you need is taught in QUICKSTART in
about two minutes, and you reuse it every session.

## Quick start

1. **Unzip** this kit somewhere permanent (not Downloads).
2. **Read `QUICKSTART.md`.** It is the whole setup: one project in one folder, a
   briefing file, and a test that it stuck. Half an hour.
3. **Read `WORKFLOW.md`.** This is the method that makes the setup pay off. Work
   in passes, teach it as you go, keep your words safe.
4. **Skim `MEMORY.md` and `SAFETY.md`.** The first makes Claude learn your voice
   over time. The second makes sure a bad edit can never cost you real work.
5. **Read the `examples/`.** Seeing three real sessions is worth more than any
   amount of instruction. Read them before your first serious session.

## What you need first

This kit assumes Claude Code is already installed and you can open it. Installing
it is not covered here, on purpose: Anthropic keeps their own install guide
current at https://code.claude.com/docs and we cannot. Get it running from
their guide, then start with QUICKSTART here.

## A note on accuracy

Claude Code changes often. Where this kit names a specific command or feature, it
was checked against Anthropic's current documentation and is dated (you will see
"as of 2026-07" next to the specifics). The method itself, briefing files,
memory, working in passes, keeping files safe, is durable and will outlast any
particular version. If a detail here ever disagrees with what you see on screen,
trust the screen and the official docs.

## Where this sits

This kit is the **setup and method** layer: it configures Claude Code to know
your voice and work safely on your writing. If you also want a system for turning
your week of work into a steady stream of drafts and posts, that is a separate
job handled by the companion product, **The Builder's Pipeline**. You do not need
it to get full value here. This kit stands on its own.

## Support and license

Personal-use license: see LICENSE. Questions, or something not working? Email
bryan@becomeawritertoday.com. Every message gets read.

- Bryan
