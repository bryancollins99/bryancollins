# QUICKSTART: the first five things to set up

This gets you from "I installed Claude Code, now what?" to "Claude knows my
project, my voice, and my rules" in about half an hour. It assumes you have
never opened a terminal in your life. That is fine. You will type a few short
lines, press Enter, and read what comes back. That is the whole skill.

If you get stuck at any step, email bryan@becomeawritertoday.com with the step
number and what your screen says. Every message gets read.

> **Before you start:** this kit assumes Claude Code is already installed and
> you can open it. If not, follow Anthropic's own install guide first
> (https://code.claude.com/docs), then come back here. We do not cover
> installation, because Anthropic keeps their guide current and we cannot.

---

## What you are actually doing

Most people open Claude Code, type a request, get an answer, and close it. Next
time they open it, it has forgotten everything: their project, their voice,
their rules. They re-explain themselves every single session.

The five steps below fix that permanently. You are going to write Claude a
short briefing it reads automatically, every time, before you type a word. Do
this once and you stop repeating yourself forever. That is the entire idea of
this kit.

---

## Step 1: Put your writing in one folder

Claude Code works inside a folder. Everything in that folder (and its
subfolders) is what Claude can see and help with. Anthropic's own docs put it
plainly: Claude Code works in any directory, including a notes vault or a
folder of plain documents, not just code.

So pick one folder that holds a project you are working on: a book, a
newsletter, a research piece. If your writing is scattered, gather one
project's files into a single folder now. Plain text or Markdown (`.md`) files
work best, but Claude can read most documents.

Do not use your whole Documents folder or your entire hard drive. One project,
one folder. You can make more folders later, one per project.

## Step 2: Open Claude Code inside that folder

1. Open your terminal.
   - **Mac:** press Cmd+Space, type `Terminal`, press Enter.
   - **Windows:** press the Windows key, type `PowerShell`, press Enter.
   You will see a window with a blinking cursor. You type, press Enter, things
   happen.
2. Type `cd`, then a space (the letters c and d, then one space). Do not press
   Enter yet.
3. Drag your project folder from Finder (Mac) or Explorer (Windows) onto the
   terminal window and let go. The folder's location appears after the `cd`.
4. Now press Enter. You are now "inside" that folder.
5. Type `claude` and press Enter. Claude Code starts, pointed at your project.

That is the only terminal move you need to learn. `cd`, drag the folder, Enter,
`claude`. You will do it every time you sit down to work.

## Step 3: Create your briefing file (this is the important one)

This kit gives you three ready-made briefing templates in the `templates/`
folder:

- `writing-project.CLAUDE.md`: a book, report, or long manuscript.
- `newsletter.CLAUDE.md`: a recurring newsletter.
- `research-project.CLAUDE.md`: an article or investigation built from sources.

Pick the one that fits. Now copy it into your project folder, using Finder or
Explorer, no terminal needed:

1. In Finder (Mac) or Explorer (Windows), open this kit's `templates/` folder.
2. Copy the one template you picked into your project folder (the folder from
   Step 1, where your writing lives). Copy it in, do not move it, so the
   originals stay in the kit.
3. Rename the copy to exactly `CLAUDE.md`, in capitals, with nothing before or
   after. Not `my-CLAUDE.md`, not `CLAUDE.md.txt`. Exactly `CLAUDE.md`.

It must sit in the top of your project folder, next to your writing. That exact
name, in that spot, is what Claude Code looks for and loads automatically at the
start of every session.

(Why copy by hand instead of asking Claude? The kit and your project are two
different folders. When you open Claude Code in your project folder, it cannot
reach into the kit folder to fetch the template, so the simplest first move is a
plain Finder copy. Once `CLAUDE.md` is sitting in your project folder, Claude can
see it, and Step 4 hands the filling-in back to Claude.)

## Step 4: Fill in the briefing

Open the new `CLAUDE.md` and fill in every line marked FILL IN. You can do this
in any text editor (TextEdit, Notepad, VS Code), or ask Claude to interview
you:

    Ask me one question at a time to help me fill in the FILL IN lines in
    CLAUDE.md, then write my answers into the file.

The three things worth getting right:

1. **Who your reader is.** One specific sentence. Drafts bend around this.
2. **Your voice.** Describe how you actually write, honestly. Ban the words you
   hate. This is what stops Claude sounding like generic marketing copy.
3. **Your file-safety rules.** They are already written into the template. Read
   them so you know Claude has been told not to wreck your work.

Keep the whole file short, under about 200 lines. A tight briefing is followed
more reliably than a long, rambling one.

## Step 5: Test that it stuck

Close Claude Code (type `/exit` or just close the terminal). Open it again from
your project folder (Step 2). Then type:

    What is this project, who is the reader, and what are my house style rules?

If Claude answers correctly without you explaining anything, your briefing is
working. Claude read `CLAUDE.md` on its own, before your first word. From now
on, every session starts with your project already understood.

You are set up. Read `WORKFLOW.md` next: it shows you what to actually do with
this, instead of just typing requests one at a time.

---

## The one-minute version

1. One project, one folder.
2. Open the terminal, `cd` into the folder, run `claude`.
3. In Finder or Explorer, copy a template from the kit's `templates/` folder
   into your project folder, and rename the copy to exactly `CLAUDE.md`.
4. Fill in the reader, the voice, and read the safety rules.
5. Reopen Claude and confirm it remembers.

Then read `WORKFLOW.md`, `MEMORY.md`, and `SAFETY.md` in that order.
