# MEMORY: how to make Claude remember your voice

This is the feature almost no writer knows exists, and it is the one that turns
Claude Code from a clever stranger into a partner who knows how you write.

Here is the problem it solves. Every time you open Claude Code, it starts with a
blank memory of the conversation. If you spent yesterday teaching it that you
never use exclamation marks and your newsletter always ends with the same line,
none of that survives to today, unless you make it stick. This page is how you
make it stick, in plain English, with no jargon.

Everything here is checked against Anthropic's current documentation
(https://code.claude.com/docs/en/memory, as of 2026-07). Claude Code changes;
if a detail here ever disagrees with what you see on screen, trust the screen
and the official docs.

---

## There are two kinds of memory, and you use both

Anthropic's docs describe two memory systems, and they do different jobs. You
do not have to choose. You use them for different things.

### 1. The briefing you write: CLAUDE.md

This is the file from QUICKSTART. You write it. It holds your standing
instructions: who your reader is, your voice, your house style, your safety
rules. Claude Code loads it in full at the start of every session, before you
type. It is the stable core of what Claude knows about your project.

Use CLAUDE.md for the things that are true every session: "my reader is X," "I
write in British spelling," "never invent a statistic."

### 2. The notes Claude keeps: auto memory

This is the surprising one. As you work, Claude Code can save little notes to
itself about what it learns from your corrections and preferences, without you
writing them by hand. The docs call this "auto memory." It is Claude taking
notes on how you like to work, so it does not have to relearn them tomorrow.

Use this for the things you discover as you go: "she hates the word
supercharge," "the sign-off is always this exact line," "drafts should never
open with a question."

Put simply: **you write the briefing; Claude keeps the field notes.** Together
they mean each session starts smarter than the last.

---

## How to actually save something (the whole skill)

You do not need a command or any special syntax. You just tell Claude, in
ordinary words. Two phrasings, depending on where you want it to land:

**To save it as one of Claude's own notes (auto memory):**

> remember that I never use exclamation marks

The docs are explicit that when you ask Claude to remember something like this,
it saves it to auto memory, and future sessions start with it known.

**To add it to your written briefing (CLAUDE.md):**

> add that to CLAUDE.md: my sign-off is always "Talk soon."

Rule of thumb: if it is a firm, permanent rule you would want a stranger to see,
put it in CLAUDE.md. If it is a preference you just discovered mid-work, "remember
that" is faster and lands in auto memory. Either way, it survives to next time.

**The habit that matters:** the second time you give Claude the same correction,
save it. The first time is a note; the second time is a pattern. Patterns
belong in memory.

---

## Seeing and editing what Claude has remembered

You are never locked out of your own memory. Everything is plain text you can
read, change, or delete.

- **From inside a Claude Code session,** type `/memory`. Per the docs, this
  lists the briefing files loaded in your session (your `CLAUDE.md` and
  related files), lets you open any of them, and gives you a way into the
  folder where Claude keeps its auto-memory notes. It also lets you turn auto
  memory on or off.
- **The notes are just files.** Claude's auto-memory notes live in a folder on
  your own machine, in plain Markdown. The docs give the location as
  `~/.claude/projects/<project>/memory/`, with a file called `MEMORY.md` acting
  as the index. You can open it, read exactly what Claude has decided to
  remember about your work, and edit or delete anything you disagree with.

Nothing is hidden and nothing is in the cloud by default. If Claude ever
remembers something wrong ("she likes semicolons," when you loathe them), open
`/memory`, find it, fix it. It is your text.

> A small note to avoid confusion: this guide is named `MEMORY.md`, and Claude's
> auto-memory index file is also named `MEMORY.md`. They are not the same file.
> This one is a guide in your kit. That one lives in the `~/.claude/projects/`
> folder above and is written by Claude. Same name, different jobs.

---

## Keep the briefing short, let notes do the rest

One practical warning from the docs: your `CLAUDE.md` briefing is loaded in full
every session and a shorter file is followed more reliably. Aim to keep it under
about 200 lines. So do not cram every tiny preference into CLAUDE.md. Put the
core, permanent rules there, and let the lighter "remember that" notes carry the
smaller discoveries. The briefing is your constitution; the notes are the
day-to-day case law.

---

## What this gets you

Set this up and something quietly good happens. In week one, Claude sounds close
to your voice because you briefed it. By week four, it sounds closer, because
every correction you bothered to save is now known at the start of every
session. You stop repeating yourself. The tool stops resetting. It starts, for
the first time, to actually learn how you write.

That is the whole promise of this kit, and the memory system is the engine under
it. Brief it once. Teach it as you go. Read your own memory when you are curious.
And watch a generic assistant slowly turn into yours.
