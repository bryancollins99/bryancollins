# SAFETY: how not to wreck your files

You are about to let a very capable assistant work directly on files that took
you weeks or months to write. That is the right thing to do. It is also the one
place this can go wrong. This page is the short version of how to keep it from
ever going wrong. It takes five minutes to read and it is worth every second.

The good news: most of the protection is already done for you, built into the
templates in this kit. The rest is two small habits.

---

## The one thing that saves you: a real undo button

The single best protection is a full history of your writing, so any mistake,
yours or Claude's, is one command away from undone. The free tool that does this
is called git. You do not need to understand it. You need four lines, once.

In your project folder, in the terminal:

    git init

That turns on history for this folder (one time only). Then, whenever you have
done some writing worth keeping:

    git add .
    git commit -m "saved before big edit"

Each `commit` is a permanent snapshot you can return to. Do one before you let
Claude do anything large. If a rewrite goes sideways, your last snapshot is
sitting safely in the folder, and you can restore it. No cloud, no account, no
monthly fee. This alone removes almost all the risk. If git is not installed,
the terminal will tell you and offer to install it on Mac; on Windows, get it
from https://git-scm.com.

Tip: you can just ask Claude to do this for you. "Take a snapshot of my work
with git before we start" is a perfectly good instruction.

---

## Worktrees, in one plain paragraph

Sometimes you want to try a big, risky rewrite without touching your good draft
at all, so if you hate it, there is nothing to undo because your real files were
never in the room. That is what a "worktree" is: a separate, parallel copy of
your project on its own branch, where changes cannot collide with your main
copy. Claude Code has this built in. Per Anthropic's current docs
(https://code.claude.com/docs/en/common-workflows, as of 2026-07), you start one
by running `claude --worktree experiment` (use any name you like in place of
`experiment`); the docs describe each worktree as a separate checkout on its own
branch, run in an isolated session "so concurrent edits don't collide." Do your
scary rewrite there. If it is good, bring it back. If it is not, close it and
your original draft never knew a thing. You will not need this on day one. Keep
it in your pocket for the day you want to gut a chapter and are not sure you are
right.

---

## The rules already working for you

Open any template in `templates/` and you will find a "file-safety rules"
section. When you copy the template to `CLAUDE.md`, those rules load every
session and tell Claude, in writing, to:

- Never delete a file or a big block of your writing without asking first.
- Save its rewrites to a new, clearly named file (for example
  `chapter-03.edited.md`) instead of overwriting your original, and tell you
  what changed so you can compare before you replace anything.
- Treat your sources and past issues as read-only.
- Make one focused change at a time, and not "tidy up" files you did not ask it
  to touch.

You do not have to write these. They are in the templates. Read them once so you
know Claude has been told where the fences are.

---

## Two habits that cost nothing

1. **Snapshot before anything big.** Before a full rewrite, a restructure, or
   anything that touches several files, take a git snapshot (above) or ask
   Claude to. Thirty seconds of insurance against an afternoon of loss.

2. **Read before you replace.** When Claude produces an edited version of your
   work, it saves to a new file (the templates make it do this). Open both,
   compare, and only then decide to keep the new one. Never let a rewrite land
   directly on top of your only copy.

---

## If something does go wrong

Stay calm. Almost nothing here is truly unrecoverable if you have been taking
snapshots.

- **You took git snapshots:** ask Claude "restore my files to the last git
  snapshot," or look up "git restore" and "git checkout." Your history has you.
- **Claude saved its edit to a new file (the default):** your original is
  untouched. Just delete the edited file and carry on.
- **No snapshot, and a file was overwritten:** check your system's own backup
  first (Time Machine on Mac, File History on Windows, or your cloud sync's
  version history). Then start taking git snapshots so this is the last time it
  can happen.

The whole point of this page is that "something went wrong" should mean "I open
yesterday's snapshot," not "I lost my work." Set up git once, snapshot before
big jobs, and let the templates keep the fences up. That is safe.
