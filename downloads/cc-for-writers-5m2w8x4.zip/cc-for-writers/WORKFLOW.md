# WORKFLOW: what I do instead of just typing

Most people open Claude Code and start typing. They ask for a thing, get a
thing, and close the window. It works, a little, the way a very smart intern
with amnesia works: helpful once, useless as a system, because tomorrow it
remembers nothing about you.

This is the method that turns that same tool into a writing partner who knows
your project, your voice, and your rules, and gets better the longer you use
it. It is four habits. None of them are technical.

---

## The shape of it

```text
   set up once        work in passes        let it remember        keep it safe
  (write CLAUDE.md)   (draft -> sharpen)     (teach as you go)      (new files, not
                                                                     overwrites)
```

You do the first habit once per project. The other three you do every session,
almost without noticing, until they are just how you write.

---

## Habit 1: Brief before you ask

The single biggest change is the one from QUICKSTART: a `CLAUDE.md` file in your
project folder. Claude Code reads it automatically at the start of every
session, before you type. It is a standing briefing, so you stop re-explaining
your reader, your voice, and your rules every time.

If you have not set one up, stop and do QUICKSTART first. Everything below
assumes it exists. The difference between briefed and un-briefed is the
difference between a partner and a search box.

The test of a good briefing: open a fresh session and ask "what is this project
and how do I write?" If the answer is right without you saying anything, you are
briefed.

## Habit 2: Work in passes, not in one giant ask

The amateur move is to type "write my newsletter about X" and hope. The result
is generic, because you asked a machine to do all the thinking at once.

The method is to break the work into passes and stay in the loop between them.
Writing has natural passes already. Use them:

**A drafting job** goes: rough notes in, then a structure pass, then a draft
pass, then a sharpening pass. For example:

1. "Here are my messy notes for this piece. Before drafting, give me three
   possible structures and tell me which one earns the reader's attention
   fastest."
2. "Use structure two. Draft it in my voice. Leave anything you are unsure of
   marked so I can check it."
3. "This paragraph is flabby. Tighten it, keep my meaning, cut the fat."

You are steering at every turn. That is why the output sounds like you: you
never handed over the whole decision, only the labour.

**An editing job** goes the other way: draft in, then a diagnosis pass, then
targeted fixes. "Read this draft and tell me the three weakest moments and why"
before "now fix the second one." Diagnosis before surgery.

**A research job** goes: sources in, then a coverage pass, then a synthesis
pass. "What do these sources actually establish, and what do they not cover?"
before "draft the section, and cite which source backs each claim."

The pattern under all three: **ask for thinking before you ask for output.**
One good clarifying pass beats five rounds of fixing a draft that started wrong.

## Habit 3: Teach it as you go

Every time you correct Claude, you are holding a small piece of your style in
your hand. Do not drop it. If it is a one-off, let it pass. If it is a rule you
will want next week too, make it stick.

You do that by just saying so, in plain English:

- "Remember that for this project: my sign-off is always this line."
- "Add that to CLAUDE.md."

Claude Code has a memory system that saves these, so the next session starts
already knowing them. This is the habit almost nobody discovers, and it is what
makes the tool compound instead of reset. `MEMORY.md` in this kit explains
exactly how it works and where the notes live. Read it. It is the difference
between a tool that stays the same and one that learns your voice over months.

The rule of thumb: **the second time you type the same correction, save it.**

## Habit 4: Keep your words safe

You are letting an assistant work on files that took you months to write. The
whole method falls apart the first time it silently overwrites a chapter. So
the fourth habit is a boundary, and the templates in this kit already build it
in:

- New work goes to new, clearly named files, not on top of your originals.
- Nothing gets deleted without asking.
- Source material and past issues are read-only.

`SAFETY.md` covers this in one page, including the one habit (a "worktree")
that gives you a proper undo button for a big, risky rewrite. If you only read
one more page after this, read that one.

---

## A week in the method

Here is what it looks like once the habits are yours.

- **Monday.** You sit down to write the newsletter. You open the terminal, `cd`
  into your newsletter folder, run `claude`. It already knows the format, the
  reader, and your voice, because it read `CLAUDE.md`. You paste your rough
  notes and ask for three structures. You pick one.
- **Tuesday.** Draft pass. It writes into your format. You steer two
  paragraphs, tighten one, and catch a line that sounds like a brochure. You
  say "never use that phrase, remember that." It saves the rule.
- **Wednesday.** You reread, ask for five subject lines, pick one, rewrite it
  half. Done. You copy it into your sending tool yourself. (The method drafts;
  you decide what ships.)
- **Next Monday.** New session. It opens already knowing the phrase you banned
  last week, because you taught it. It is a slightly better partner than it was
  seven days ago. That is the point.

That compounding is the whole return on the method. The setup is an afternoon.
The payoff is every week after, for as long as you write.

---

## The honest limits

This is a method and a set of configs, not a magic button. It will not write a
good piece from a bad idea, it will not know a fact you have not given it, and
you still have to bring the judgment. What it removes is the blank page, the
re-explaining, and the mechanical drudgery, so your attention goes where it
should: to the thinking and the voice that only you have.

Set it up once. Work in passes. Teach it as you go. Keep your words safe. That
is the method.
