# CLAUDE.md: a newsletter

<!--
HOW TO USE THIS FILE
1. Copy this file into the folder where you keep your newsletter drafts.
2. Rename the copy to exactly CLAUDE.md (that exact name, in capitals).
3. Fill in every line marked FILL IN. Delete the bracketed guidance.
4. Delete or keep this comment block: text inside an HTML comment is
   ignored, so it costs you nothing to leave it.

Claude Code reads a file named CLAUDE.md at the start of every session,
automatically. This one teaches Claude your newsletter: who reads it, how
long it runs, how it sounds, and where the sign-off and links go. Set it
once and every future draft starts from your format instead of a blank page.

Keep it short, ideally under about 200 lines. Specific beats long.
-->

## What this newsletter is

[FILL IN. Example shape: "This is the working folder for my weekly
newsletter, [name]. Each issue lives in its own file named
`YYYY-MM-DD-topic.md`. Past issues are in `archive/`. My swipe file of
subject lines that worked is in `subject-lines.md`."]

## Who reads it

[FILL IN. One sentence. The more specific, the better the drafts. Example:
"Freelance writers, mostly two to five years in, who want fewer clients paying
more, not more clients paying less."]

## The shape of an issue

[FILL IN your real structure so Claude drafts into it every time. Example:]

- A one-line hook that earns the open.
- One story or idea, told simply, 500 to 800 words.
- One concrete takeaway the reader can use this week.
- A short sign-off in my voice.
- [Note any fixed sections: a link roundup, a question of the week, etc.]

## My voice

Match this in every draft and edit:

- [FILL IN, honestly. Example lines you might adapt:]
- Conversational, like an email to one smart friend, not a broadcast.
- Direct. I get to the point in the first two lines.
- No hype words: no "unlock," "supercharge," "game-changer," "revolutionary."
- Specific examples and real numbers over adjectives.
- I write in first person and I am comfortable being honest about what did
  not work.

If a draft drifts into generic marketing voice, stop and rewrite it plainer.

## House style (mechanical rules)

Apply these without being asked:

- No em dashes. Use commas, colons, parentheses, or a full stop.
- [British / American] spelling. Be consistent.
- Subject lines: [your rule, e.g. "under 50 characters, no title case, no
  clickbait I cannot pay off in the issue"].
- One call to action per issue, at most. [Name it, e.g. "reply and tell me X"
  or "the link to my course."]
- Never invent facts, statistics, quotes, or subscriber numbers. If you need
  a number I have not given you, ask or mark it "CHECK THIS."

## File-safety rules (do not wreck my work)

- Never delete a draft or archived issue without asking first.
- When you edit an issue, do not silently overwrite it. Save your edit to a
  clearly named new file and tell me what you changed, so I can compare.
- Treat `archive/` as read-only. Read past issues for voice and to avoid
  repeating myself, but never edit them.
- Make one change at a time. Do not reformat files I did not point you at.

## Things you can just do without asking

[FILL IN. Example:]

- Suggest five subject lines for a draft when I ask.
- Check a new draft against `archive/` and warn me if I am repeating a story.
- Tighten a paragraph I mark as flabby (keep my meaning, cut the fat).
- Draft the one-line hook, then let me pick or rewrite it.

## Things to always ask about first

[FILL IN. Example:]

- Changing the call to action.
- Cutting a whole section.
- Anything that would send, schedule, or publish. Drafting only unless I say
  otherwise.

<!--
TIP: When you catch yourself giving Claude the same correction twice ("the
sign-off is always this line"), say "remember that" or "add that to
CLAUDE.md." Future sessions will start already knowing it. The MEMORY.md
guide in this kit explains how.
-->
