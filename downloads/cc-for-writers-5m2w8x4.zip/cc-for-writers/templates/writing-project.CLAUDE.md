# CLAUDE.md: a long-writing project (book, report, or manuscript)

<!--
HOW TO USE THIS FILE
1. Copy this file into the top folder of your writing project.
2. Rename the copy to exactly CLAUDE.md (that exact name, in capitals).
3. Fill in every line marked FILL IN. Delete the guidance in brackets.
4. Delete this comment block when you are done, or leave it: text inside
   an HTML comment like this one is ignored and costs you nothing.

Claude Code reads a file named CLAUDE.md at the start of every session,
automatically, before you type anything. That is the whole trick. You are
writing a short briefing that Claude reads every single time, so you never
have to re-explain your project, your voice, or your rules again.

Keep this file short. Aim for under about 200 lines. A tight, specific
briefing is followed more reliably than a long, vague one.
-->

## What this project is

[FILL IN. One or two plain sentences. Example shape: "This is the working
folder for my book, a nonfiction guide to X for readers who are Y. Drafts
live in `chapters/`. Research and interview notes live in `research/`. The
finished manuscript is assembled in `manuscript.md`."]

## Who the reader is

[FILL IN. One sentence describing the person you are writing for. Claude
writes very differently for "a nervous first-time founder" than for "a
seasoned academic." Be specific. The whole draft bends around this line.]

## My voice (write like me, not like a robot)

Match this voice in anything you draft or edit:

- [FILL IN. Describe how you actually write, honestly, not aspirationally.
  Example lines you might adapt:]
- Plain and direct. Short sentences. One idea per sentence.
- Warm but not chatty. No hype, no "unlock," no "game-changer."
- I use concrete examples and real numbers instead of adjectives.
- Contractions are fine. First person is fine.
- [Add two or three of your own tics: a phrase you love, a phrase you ban.]

When you are unsure whether something sounds like me, choose the plainer
version and flag it so I can check.

## House style (the mechanical rules)

Apply these every time without being asked:

- [FILL IN your own, then keep the useful defaults below.]
- No em dashes. Use commas, colons, parentheses, or a full stop instead.
- [Set one: British spelling / American spelling.] Be consistent.
- Serial comma: [on / off]. Pick one and keep it.
- Numbers: spell out one to nine, use figures for 10 and up (adjust to taste).
- Headings in [sentence case / title case].
- Never invent facts, statistics, quotes, or sources. If you need a fact I
  have not given you, stop and ask, or clearly mark it "CHECK THIS."

## File-safety rules (do not wreck my work)

These matter more than anything else in this file. Read them as hard limits:

- Never delete a file or large block of my writing without asking first.
- When you rewrite a chapter, do not overwrite the original silently. Save
  your version to a new file (for example `chapter-03.edited.md`) and tell me
  what changed, so I can compare before I replace anything.
- Make one focused change at a time. Do not "tidy up" files I did not ask
  you to touch.
- If I ask for something that would throw away work, warn me before doing it.
- Treat `research/` and any `*.notes.md` file as read-only source material.
  Quote from it, do not edit it, unless I say so.

## How I like to work

- [FILL IN. Example: "I draft badly on purpose, then edit. When I paste a
  rough section, help me sharpen it, do not rewrite it from scratch."]
- [Example: "Ask me one clarifying question before a big task, not five."]
- When a task is big, show me your plan first and wait for a yes.

## Things you can just do without asking

[FILL IN. This is where you save yourself time. List the small, safe,
repeatable jobs Claude can do on sight. Example:]

- Fix typos, spelling, and obvious grammar in a file I point you at.
- Suggest three alternative titles or subject lines when I ask for one.
- Read `research/` before answering a question about my topic.

<!--
TIP: When you correct Claude on the same thing twice in a session ("no, I
always spell it this way"), tell Claude "remember that for this project" or
"add that to CLAUDE.md." It will save the rule so future sessions start with
it already known. See the MEMORY.md guide in this kit for how that works.
-->
