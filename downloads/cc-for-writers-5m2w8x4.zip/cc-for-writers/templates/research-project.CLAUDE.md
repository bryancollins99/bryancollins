# CLAUDE.md: a research project

<!--
HOW TO USE THIS FILE
1. Copy this file into the folder where you keep the sources and notes for
   one research project (an article, an investigation, a book chapter, a talk).
2. Rename the copy to exactly CLAUDE.md (that exact name, in capitals).
3. Fill in every line marked FILL IN. Delete the bracketed guidance.
4. Keep or delete this comment block: HTML comments are ignored, so leaving
   it costs nothing.

Claude Code reads a file named CLAUDE.md at the start of every session,
automatically. A research folder is where a good briefing matters most,
because the one thing you cannot afford is a made-up fact. This template is
built around a single rule: sources are sacred, and nothing gets stated
that a source does not support.

Keep it short, ideally under about 200 lines.
-->

## What this project is

[FILL IN. Example shape: "This is the research folder for [article/chapter/
talk] on [topic]. Raw sources (PDFs, transcripts, saved pages as text) live
in `sources/`. My own notes and summaries live in `notes/`. The output I am
building toward is [a 2,000-word feature / an outline / a brief]."]

## The question I am trying to answer

[FILL IN. One clear sentence. This keeps every session pointed at the same
target. Example: "Does the four-day week actually hold productivity steady,
and what do the strongest studies really measure?"]

## The one rule that matters most: sources are sacred

- Never state a fact, figure, quote, date, or name that is not supported by a
  file in `sources/` or something I have told you directly.
- Every claim you write for me must be traceable. When you summarise or draft,
  point to which source backs each point (file name is enough).
- If I ask a question the sources do not answer, say so plainly. Do not fill
  the gap with general knowledge dressed up as a finding. "The sources here do
  not cover that" is the correct, valuable answer.
- If two sources disagree, tell me they disagree. Do not quietly pick one.
- When you are estimating or reasoning rather than reporting a source, label
  it clearly as your own inference, not a finding.

## How to handle sources

- Treat everything in `sources/` as read-only. Read it, quote it, cite it,
  but never edit or delete it.
- When I add a new source, you can read it and add a short summary to
  `notes/`, but keep the original untouched.
- Preserve exact quotes exactly. If you shorten a quote, show the cut clearly
  and never change the words inside it.

## My voice (for anything you draft)

[FILL IN. Even research output has a voice. Example:]

- Plain and precise. I would rather be clear than clever.
- I explain jargon the first time I use it.
- Confident about what the evidence shows, honest about what it does not.
- No hype. No em dashes (use commas, colons, or a full stop).

## House style

- [British / American] spelling, consistently.
- Citations formatted as [your preference: inline, footnotes, or just the
  source file name in brackets].
- Numbers and units exactly as the source gives them.

## File-safety rules

- Never delete anything in `sources/` or `notes/` without asking first.
- When you produce a draft or summary, save it to a new, clearly named file.
  Do not overwrite my notes.
- Make one focused change at a time.

## Things you can just do without asking

[FILL IN. Example:]

- Read all of `sources/` before answering a question about the topic.
- Summarise a single source into `notes/summary-<sourcename>.md`.
- Build a list of what the sources do and do not cover, so I can see my gaps.
- Pull every quote in the sources on a theme I name, each with its file.

## Things to always ask about first

[FILL IN. Example:]

- Writing the full draft (I want to approve the outline first).
- Anything that presents an inference as if it were a sourced fact.

<!--
TIP: The moment you correct Claude on a sourcing rule, make it stick. Say
"remember that" or "add that to CLAUDE.md" and it will start every future
session already knowing the rule. See MEMORY.md in this kit.
-->
