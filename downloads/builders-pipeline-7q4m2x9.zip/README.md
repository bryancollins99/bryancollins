# The Builder's Pipeline

Turn a week of scrappy notes into ready-to-publish content — in one command.

You keep a simple worklog ("Built the CSV import. Took 2 hours. Skipped the API
route."). Every Friday you run one command. Thirty seconds later you have
LinkedIn post drafts with hooks already written, newsletter email drafts,
a strategic review of where your week actually went, and content ideas mapped
to what you really did.

**Philosophy: content is the exhaust, not the engine.** If you do the work and
write it down, you never stare at a blank content calendar again.

---

## What's in the box

| Script | What it does | Command |
|---|---|---|
| **Content Pipeline** | Scans your worklog + recent notes → 5 content ideas with hooks | `python3 scripts/content-pipeline.py` |
| **Deep Pattern Analyzer** | Finds the themes in your week; spots gaps between what you say matters and where the time went | `python3 scripts/deep-pattern-analyzer.py` |
| **Draft Generator** | Writes the actual drafts: 2–3 newsletter emails (500–800 words), 3 LinkedIn posts, note templates | `python3 scripts/draft-generator.py` |
| **Email Analyzer** | Paste in any draft → 10-section editorial feedback: subject lines, hooks, structure, CTAs | `python3 scripts/email-analyzer.py my-draft.md` |
| **Newsletter Scheduler** | Markdown file → clean HTML → into Kit (ConvertKit), auto-detecting your next open send slot | `python3 scripts/schedule-newsletter.py my-draft.md` |
| **YouTube Email Generator** | Paste a YouTube URL → it fetches the transcript and writes the promo email | `python3 scripts/youtube-email.py <url>` |

Plus:

- **`prompts/`** — every script's brain as a copy-paste prompt. **No Python
  required**: if you never run a single script, you can still paste these into
  Claude (or any capable AI chat) with your notes and get the same output.
- **`templates/`** — the worklog template and note templates the system reads.
- **`sample-output/`** — real example output for every script, so you can see
  what you get before you run anything.

## Quick start

1. **Install** (one time):
   ```
   pip install -r requirements.txt
   ```
2. **Configure** (one time):
   ```
   cp config.example.yaml config.yaml
   ```
   Open `config.yaml` and set two paths: where your notes live, and your
   worklog file. Describe your writing voice in a sentence or two.
3. **Add your API key** (one time): create a file called `.env` in this folder:
   ```
   ANTHROPIC_API_KEY=sk-ant-your-key-here
   ```
   Get a key at https://console.anthropic.com/settings/keys. A full weekly run
   costs well under $0.25 in API usage.
4. **Check everything works**:
   ```
   python3 scripts/setup_check.py
   ```
5. **Run your first pipeline**:
   ```
   python3 scripts/content-pipeline.py
   ```

Never used Python or a terminal? Read **SETUP.md** — it assumes nothing and
takes about 15 minutes. Or skip installation entirely and use the prompts in
`prompts/` (see `prompts/README.md`).

## The weekly workflow

1. During the week: one line in your worklog whenever you finish something.
2. Friday: `python3 scripts/content-pipeline.py` → pick the ideas you like.
3. `python3 scripts/draft-generator.py` → real drafts appear in your notes folder.
4. Edit the best draft for ten minutes. It's yours, in your voice — the tool
   just did the blank-page part.
5. Optional: `python3 scripts/email-analyzer.py draft.md` for editorial feedback,
   then `python3 scripts/schedule-newsletter.py draft.md` to queue it in Kit.

## Requirements

- Python 3.9+ (already on every Mac; see SETUP.md for Windows)
- An Anthropic API key (pay-as-you-go, ~$0.15–0.25/week at this usage)
- Optional: a Kit (ConvertKit) account — only for the scheduler
- A folder of markdown notes and a worklog file (templates included)

## Support & license

Personal-use license — see LICENSE. Questions or something broken? Reply to
any of my emails: bryan@becomeawritertoday.com. Every reply gets read.

— Bryan Collins
