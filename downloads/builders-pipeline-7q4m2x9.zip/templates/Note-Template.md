# {One clear idea as a title}

{2-5 sentences: the idea in your own words. Write it so future-you understands
it without any other context. One idea per note — if you're writing "and also",
that's a second note.}

**Where it came from:** {project, book, conversation, or worklog entry}

**Where it might lead:** {a post? a product? a change to how you work?}

#permanent-note
