# Worklog

One line whenever you finish something. What you did, how long it took, one
thing you learned or decided. That's the entire habit — the pipeline does the
rest.

Format (copy the example lines, keep newest at the bottom):

2026-07-01: Set up The Builder's Pipeline. 20 mins. The .env step was the only fiddly part.
2026-07-02: Drafted the pricing page. 1 hr. Cut the middle tier — nobody was going to pick it.
2026-07-03: Fixed the newsletter signup bug. 30 mins. It was the cache, it's always the cache.
