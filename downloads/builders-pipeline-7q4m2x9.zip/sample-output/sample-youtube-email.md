> Example output — generated from a sample draft so you can see the format before you run it.

# I batch-photographed 12 recipes in one afternoon

**Video**: https://www.youtube.com/watch?v=aBcD3fGh1jK
**Generated**: 2026-06-14 10:15

---

Twelve recipes, one afternoon, one camera setup. That used to be three separate weekends of cooking, styling, and chasing the light around my kitchen.

This week's video breaks down the batch-photography system I've been refining since January. Three things it covers:

**The cook-once, shoot-twice schedule.** I group recipes by base ingredient, so one pot of caramelized onions shows up in three different dishes. The cooking order is planned backwards from which dishes hold their looks longest — salads shoot last, braises can sit.

**The one-corner studio.** No lighting kit. I use the same north-facing corner of my kitchen, a piece of white foam board, and a $12 reflector. In the video I show the exact same plate shot with and without the board — the difference made me a little annoyed I spent two years without it.

**The naming system that saves editing time.** Every photo gets named on import to match the recipe file it belongs to, so my recipe card script picks up the right images automatically. Ninety minutes of "which casserole is this?" gone from my week.

The insight that surprised me most: batching didn't make the photos more efficient and less good — it made them better. When you shoot twelve dishes back to back, you notice what's working while you can still fix it, instead of remembering it three weekends later.

If your content sits unpublished because the photos aren't done, [I walk through the whole afternoon here](https://www.youtube.com/watch?v=aBcD3fGh1jK) — the schedule, the corner setup, and the two dishes that flopped on camera anyway.

P.S. Next month I'm testing whether the same batching logic works for filming recipe videos. If it works, that's another two weekends back.

---
