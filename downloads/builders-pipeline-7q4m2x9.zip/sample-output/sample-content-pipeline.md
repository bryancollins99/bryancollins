> Example output — generated from a sample worklog so you can see the format before you run it.

# Content Pipeline - Week of 2026-06-29
Generated: 2026-06-29 16:42:11
Sources:
- Worklog.md (recent entries)
- 6 recently created/edited notes (last 7 days)
Platforms: linkedin, newsletter, youtube

**Philosophy**: Content is the exhaust, not the engine.

#content-pipeline #content-ideas

---

## 1. One-Sentence Result of the Week

I wrote a small Python script that scales recipe ingredients automatically, cutting my recipe card prep from 45 minutes to 5.

## 2. LinkedIn Post Ideas

### Post 1: The 45-minutes-to-5 story
- **Hook**: "I spent 45 minutes per recipe converting cup measurements by hand. Then I spent one Saturday fixing that forever."
- **Angle**: A food blogger with zero coding background automating the most boring part of her workflow. The point isn't the code, it's noticing which task deserved automating.
- **Evidence**: Worklog 06-24 ("scaler script working, first recipe card done in 5 min, was 45"), the before/after timing, the fraction-handling bug ("3/4 cup broke everything").
- **CTA**: "What's the 45-minute task in your week? Tell me in the comments and I'll tell you if a script could eat it."

### Post 2: What broke when I batch-processed 120 photos
- **Hook**: "I resized 120 recipe photos in 4 minutes. Then I noticed 30 of them were portrait shots cropped at the soup."
- **Angle**: Automation honesty post. The batch photo workflow saved an afternoon but the edge cases still needed a human eye. Automation gets you 90% and you still own the last 10%.
- **Evidence**: Worklog 06-26 (batch resize run, the portrait crop bug, the 30-photo redo).
- **CTA**: "Anyone else automated something and then quietly redone a third of it by hand? You're in good company."

### Post 3: I asked AI to write my recipe descriptions. I kept two out of ten.
- **Hook**: "I generated 10 recipe intros with AI this week. Eight of them read like a hotel brochure."
- **Angle**: Where AI fits in a personal food blog and where it doesn't. Structure and formatting: yes. The story about your grandmother's soda bread: no.
- **Evidence**: Note "AI Drafting Experiments" (modified 06-27), the 2-out-of-10 keep rate.
- **CTA**: "If you write with AI, what's your keep rate? Honest answers only."

### Post 4: My blog is a spreadsheet wearing a nice dress
- **Hook**: "Behind every recipe card on my site there's now a spreadsheet, a script, and a folder that names itself."
- **Angle**: The unglamorous system behind a pretty food blog. People see the plated photo; show them the pipeline.
- **Evidence**: Note "Recipe Site Pipeline v1" (modified 06-28) listing the four steps: draft, scale, photograph, publish.
- **CTA**: "Want the messy behind-the-scenes version as a newsletter? Reply and I'll write it up."

## 3. Newsletter Topic

**Topic**: "The Saturday I stopped doing recipe math by hand"

**Suggested structure**:
1. Open with the one-sentence result: 45 minutes to 5, per recipe
2. The moment of noticing: doubling a cookie recipe for the third time in a month and getting 1.5 eggs
3. What I actually did (plain-English version of the scaler script, no code)
4. What went wrong: fractions, "a pinch", metric vs cups
5. The numbers after one week: 6 recipe cards formatted, roughly 4 hours saved
6. The takeaway: automate the task you complain about most, not the fanciest one
7. Soft CTA: reply with the task you'd automate first

## 4. YouTube Video Ideas

### Video 1: "I automated my recipe blog's most boring job (no coding background)"
- **What to show on screen**: the old manual workflow in real time (painful on purpose), then the script running on one recipe, then the finished recipe card. End with the exact prompt/steps used to build it.
- **Why it works**: transformation is visible in one shot, and "no coding background" widens the audience beyond developers.

### Video 2: "Batch-editing 120 food photos: full workflow, including the failures"
- **What to show on screen**: the folder of raw photos, the batch run, the cropped-soup disaster, the fix. Screen-record the whole thing and narrate honestly.
- **Why it works**: tutorial plus honesty. The failure section is the part people remember and share.
