> Example output — generated from a sample worklog so you can see the format before you run it.

# The Saturday I stopped doing recipe math by hand

#newsletter #email #draft

---

Hi friends,

Quick confession: for three years, every recipe card on the blog has involved me, a calculator, and a small amount of swearing.

Here's the job. A reader asks for the cookie recipe doubled. Or I want to publish the galette in both metric and cups. So I sit down and convert every ingredient by hand: 3/4 cup becomes 1 1/2 cups, 180g becomes 360g, and somewhere around the fourth ingredient I lose my place and start over. Forty-five minutes per recipe, most weeks twice.

Two Saturdays ago I doubled a cookie recipe and the math came out to 1.5 eggs.

That was the moment. Not because 1.5 eggs is unusual (bakers know the workarounds), but because I realized I'd solved this exact problem dozens of times and kept none of the work. Every conversion started from zero.

So I did something I've been circling for months: I asked an AI assistant to help me write a small script that does the scaling for me. I am not a programmer. I run a food blog. But here's what the process actually looked like:

1. I described the job in plain English: "I have ingredient lists like '3/4 cup flour'. I want to multiply them by 2 or 1.5 and get sensible amounts back."
2. It wrote a small Python script. I ran it. It broke immediately on "3/4" because fractions are apparently where computers go to cry.
3. I pasted the error message back. It fixed it. We went around that loop maybe five times.
4. An hour in, I typed in the cookie recipe, asked for 1.5x, and got a clean, correctly rounded ingredient list. Including a note that 1.5 eggs means "2 eggs, remove 2 tablespoons" because I told it my workaround and it kept it.

First recipe card with the new script: 5 minutes, start to finish.

This week I formatted six recipe cards. That's roughly four hours I didn't spend on arithmetic, which is four hours that went into actually testing the flatbreads (they're close; the yogurt version is winning).

The lesson I keep coming back to: I didn't automate the fancy thing. I automated the thing I complained about most. Not the photography, not the writing, not the publishing. The boring, repetitive, rule-following task that happened every single week. I think that's the filter: if a job is frequent, boring, and follows rules, it's a candidate. If it needs taste (like writing the story that goes above the recipe), it stays mine.

Next up: I batch-processed 120 photos with a similar trick, and about 30 came out cropped mid-soup. So automation is not magic and I'll tell you about the failures next week.

If you've got a "45-minute task" in your week, the one you do on autopilot while resenting it, hit reply and tell me what it is. I'll share the best ones (anonymously) along with whether I think a script could eat them.

Happy cooking,
Maya

---

**Hook**: Doubling a cookie recipe and getting 1.5 eggs as the breaking point

**Framework**: Frequent + boring + rule-based = automate it; needs taste = keep it human

**Evidence**: Worklog 06-21 (1.5 eggs incident), 06-24 (scaler working, 45 min to 5), 06-26 (photo batch run), 06-29 (six recipe cards formatted); note "AI Drafting Experiments"
