> Example output — generated from a sample worklog so you can see the format before you run it.

*(The real tool saves each post as its own file, e.g. `LinkedIn-Draft-2026-06-29-1705-40-minutes-to-5.md`. They're shown together here so you can see all three formats at once.)*

# 45 minutes to 5

#linkedin #draft #social

---

I spent 45 minutes per recipe converting cup measurements by hand.

Then I spent one Saturday fixing that forever.

I run a food blog. I'm not a programmer. But every week I was doubling recipes, converting metric to cups, and losing my place around ingredient number four. Three years of that.

Two weeks ago the math on a doubled cookie recipe came out to 1.5 eggs, and something in me snapped.

So I asked an AI assistant to help me write a small script. It broke on fractions immediately (of course it did). I pasted the errors back, it fixed them, and an hour later I had a tool that scales any ingredient list correctly, including the "2 eggs minus 2 tablespoons" workaround I've used for years.

First recipe card with it: 5 minutes.
This week: six cards done, roughly four hours saved.

The filter I used: automate what's frequent, boring, and rule-based. Keep what needs taste.

What's the 45-minute task in your week? Tell me below and I'll tell you if a script could eat it.

---

**Evidence**: Worklog 06-21 (1.5 eggs), 06-24 (first 5-minute recipe card), 06-29 (six cards, ~4 hours saved)

---

# The soup got cropped

#linkedin #draft #social

---

I resized 120 recipe photos in 4 minutes on Thursday.

Felt like a genius for about an hour.

Then I opened the folder properly. Thirty of them were portrait shots, and my batch script had cropped every single one at the bowl. Beautiful spoons. No soup.

The redo cost me the exact afternoon the automation had saved.

Here's what I'm keeping from that:

1. Check automated output at photo 5, not photo 120.
2. Never let a script modify originals. Copy first, always.
3. The automation still wins. Next batch runs in 4 minutes AND keeps the soup.

I automated my food blog's photo workflow with zero coding background, and the honest version is: it works, after it embarrasses you once.

Anyone else automated something and then quietly redone a third of it by hand? You're in good company.

---

**Evidence**: Worklog 06-26 (batch run, portrait crop bug, 30-photo redo)

---

# I kept 2 out of 10

#linkedin #draft #social

---

I asked AI to write 10 recipe introductions for my blog this week.

I kept two.

The other eight read like a hotel brochure. "Nestled flavors." "Elevated comfort." Nobody's grandmother ever nestled a flavor.

But here's the thing: the same week, AI helped me build a script that scales ingredient lists automatically. That one I use every single day now.

The difference isn't the tool. It's the task.

Scaling "3/4 cup flour" by 1.5 is rules. AI is brilliant at rules.
The story about why this galette tastes like my aunt's kitchen in June is taste. That one stays mine.

My working rule after this week: hand AI the arithmetic, keep the memories.

If you create with AI, what's your honest keep rate? Not the demo-day number. The real one.

---

**Evidence**: Note "AI Drafting Experiments" (modified 06-27, 2 of 10 intros kept); worklog 06-24 (scaler in daily use)
