> Example output — generated from a sample draft so you can see the format before you run it.

# Email Analysis — Newsletter Recipe Card Automation

**Draft file**: newsletter-recipe-card-automation.md
**Analyzed**: 2026-06-14 09:32
**Original length**: 412 words
**Improved version length**: 468 words

---

## Improved Version

A revised draft that applies the strongest suggestions from the analysis below. Compare it against your original and cherry-pick what works.

Subject: My recipe cards now build themselves (3 hours saved)

Every Sunday for two years, I spent my afternoon copying recipes out of my notes app and reformatting them into recipe cards for the blog. Ingredient list, method steps, prep times, serving sizes — the same copy-paste ritual, forty times a month.

Last weekend I finally automated it. Total time to build: one afternoon. Time it saves me: about three hours a week.

Here's how it works:

1. I write the recipe once, in plain text, the way I'd scribble it on the back of an envelope.
2. A small script (which an AI assistant helped me write — I'm a cook, not a programmer) reads that file and formats it into my recipe card template: ingredients table, numbered steps, prep and cook times pulled from the text.
3. It flags anything it couldn't find — like a missing serving size — instead of guessing. I fix those two or three lines by hand and hit publish.

The part that surprised me: the hardest step wasn't the code. It was admitting my "system" was actually me doing robot work by hand every week and calling it a process.

The script isn't clever. It doesn't invent anything, and I wouldn't want it to — nobody wants an AI hallucinating how long to roast a chicken. It just moves text from the shape I like writing in to the shape my readers like reading in.

Who this is NOT for: if you post one recipe a month, don't bother — the setup costs more than it saves. This paid off for me because I publish three times a week.

Next Sunday I'm pointing the same trick at my grocery lists: one click from "this week's recipes" to a sorted shopping list.

If you've got a copy-paste ritual of your own — recipe cards, product listings, class notes, whatever — hit reply and tell me what it is. I'll share the prompt I used to get the script written, and next month I'll write up the most common ritual readers send in and automate it step by step.

Talk soon — and enjoy your Sunday. I know I will.

---

## Analysis

## 1. Subject Lines

1. My recipe cards now build themselves (3 hours saved)
2. I automated the worst part of food blogging
3. The Sunday ritual I finally killed
4. One afternoon of setup, three hours back every week
5. I taught my laptop to format recipe cards
6. The copy-paste job I did 4,000 times before automating it
7. A cook's guide to firing yourself from robot work
8. What happened when I stopped formatting recipes by hand
9. Three hours a week hiding in my recipe workflow
10. The automation that doesn't touch my actual recipes

## 2. Hooks

1. [Relief] - I just got my Sundays back.
2. [Surprise] - The code was the easy part.
3. [Pride] - I automated 3 hours of weekly busywork.
4. [Frustration] - I copy-pasted recipes 4,000 times.
5. [Curiosity] - My recipe cards build themselves now.
6. [Vindication] - I'm a cook. I still automated it.
7. [Amazement] - One afternoon replaced two years of ritual.
8. [Honesty] - My "system" was me doing robot work.
9. [Anticipation] - Grocery lists are next.
10. [Defiance] - No AI touches my actual recipes.

## 3. Content Framework

**What is this and how is it different?** The draft says "I wrote a script" but never distinguishes this from generic "use AI" advice. Add one line after paragraph two: this automation formats — it never generates. That guardrail is the differentiator.

**Where did it come from?** Strong. The two-years-of-Sundays origin is concrete and verifiable. Keep it as the opening.

**Who is this NOT for?** Missing entirely in the draft. Add the constraint: below roughly one post a week, the setup costs more than it saves. Constraints build more trust than promises.

**How does it work?** The draft describes the outcome ("now it's automatic") without mechanics. Add the three-step breakdown: plain-text input → template formatting → flagged gaps fixed by hand.

**Why should I listen?** Implicit but not stated. Quantify it: three posts a week, three hours saved, one afternoon of setup. Numbers are the proof here, not credentials.

**Logical urgency** Weak close in the draft ("hope this helps!"). Replace with what compounds: the same pattern applied to grocery lists next week, and an invitation to send in the reader's own ritual.

**Proof, testimonials, case studies** None yet — fine for a field report, but the reply-based CTA below will generate reader case studies for a follow-up email. Say so explicitly.

## 4. Big Ideas, Analogies and Metaphors

1. **The dishwasher test**
   Nobody hand-washes dishes to prove they love cooking. Formatting recipe cards by hand isn't devotion either — it's the one kitchen chore you haven't bought the machine for yet.

2. **Mise en place for publishing**
   Cooks prep ingredients before the heat goes on. The script is mise en place for the blog: everything chopped, measured, and in its bowl before publish time.

3. **The back-of-the-envelope contract**
   You write the recipe the way you naturally scribble it; the script signs a contract to translate it faithfully. You never change how you write — the machine adapts to you.

4. **Robot work vs. cook work**
   Splitting every weekly task into "only I can do this" and "a patient robot could do this" is the whole method. The recipes are cook work. The formatting never was.

5. **The smoke alarm, not the chef**
   The script flags what's missing instead of guessing. It's a smoke alarm — loud about problems, incapable of cooking anything itself. That's why it can be trusted.

## 5. Six Thinking Hats Analysis

**White Hat (facts and data)**: The draft says "it saves me loads of time" without a single number.
**Fix**: Replace with "about three hours a week" and "one afternoon to build" — both appear in your notes but not in the draft.

**Red Hat (emotion)**: The relief is real but buried in paragraph four.
**Fix**: Move "I finally got my Sunday back" up into the opening two lines, where the emotional payoff hooks the skim-readers.

**Black Hat (risks and weaknesses)**: A reader will worry the AI rewrites her recipes.
**Fix**: Add the guardrail sentence explicitly: "It doesn't invent anything — nobody wants an AI hallucinating how long to roast a chicken."

**Yellow Hat (benefits)**: The benefit is framed only as saved time.
**Fix**: Add the second-order benefit from your notes — consistency. Every card now has the same structure, which readers navigate faster.

**Green Hat (creative alternatives)**: The draft ends flat.
**Fix**: Close with the next experiment (grocery-list generation) to turn a one-off tip into an ongoing series readers follow.

**Blue Hat (structure and process)**: The draft mixes the origin story and the mechanics in one long middle paragraph.
**Fix**: Split into the numbered three-step list — story first, mechanics as steps, reflection after.

## 6. Writing and Clarity

"Me and my laptop finally came to an agreement" → "My laptop and I finally came to an agreement" → Grammar: subject pronoun order.

"It basically just kind of reformats everything automatically" → "It reformats everything automatically" → "Basically just kind of" is triple hedging; the sentence is stronger without all three.

"I'm not techy at all so if I can do it anyone can" → "I'm a cook, not a programmer — and it still took me one afternoon" → The original is a cliché that undersells you; the replacement keeps the humility and adds the evidence.

"the script does it's thing" → "the script does its thing" → its/it's.

## 7. Transition and CTA

Version 1 (reply-based):
"If you've got a copy-paste ritual of your own — recipe cards, product listings, class notes — hit reply and tell me what it is. I'll send you the prompt I used to get my script written."

Version 2 (future pacing):
"Imagine next Sunday: recipes written, cards built, afternoon free. That's one afternoon of setup away. Reply RITUAL and I'll send you the exact steps I followed."

Version 3 (series tease):
"Next month I'm picking the most common reader ritual and automating it step by step in this newsletter. Reply with yours if you want it considered."

## 8. Related Emails

1. **The grocery list generator** - Documenting next week's build: one click from "this week's recipes" to a sorted shopping list.

2. **What the script got wrong** - An honest follow-up after a month of use: the edge cases, the recipe it mangled, and the fixes.

3. **The prompt that wrote my script** - The exact conversation with the AI assistant, annotated, so a non-programmer can reproduce it.

4. **I audited a week of blog chores** - The robot-work-vs-cook-work split applied to every task in the publishing week, with times.

5. **Automating photo alt-text** - The next candidate: generating draft alt-text for recipe photos, and why this one needs heavier human review.

6. **Reader rituals, automated** - A round-up email built from the reply-based CTA: the three most common copy-paste rituals readers sent in, each with a starting point.

7. **The automation I deleted** - Documenting a failed one: the comment-reply drafter that sounded like a robot, and why it got cut.

## 9. Viral Headlines

1. I Automated the Worst Part of Food Blogging in One Afternoon
2. My Recipe Cards Build Themselves Now (a Cook's Field Report)
3. I Did the Same Copy-Paste Job 4,000 Times Before I Questioned It
4. The Three-Hour Chore Hiding in My Blog Workflow
5. I'm a Cook, Not a Programmer — I Automated My Blog Anyway
6. What Two Years of Sunday Busywork Taught Me About "Process"
7. The Automation Rule That Keeps AI Out of My Recipes

## 10. Social Media Posts

I copy-pasted recipes into my blog template every Sunday for two years. It took one afternoon to automate. The math still hurts.

The hardest part of automating my recipe cards wasn't the code. It was admitting my "system" was me doing robot work by hand.

My rule for AI on the blog: it formats, it never generates. Nobody wants a hallucinated roast time.

Split your weekly tasks into "only I can do this" and "a patient robot could do this." The second list is longer than you think.

Three posts a week times ninety minutes of formatting. That was the invoice I never looked at.

I'm a cook, not a programmer. The script still took one afternoon.

Constraints sell better than promises. My automation isn't worth it below one post a week, and I say so.

The script flags what it can't find instead of guessing. Trust comes from what a tool refuses to do.

Nobody hand-washes dishes to prove they love cooking. Stop hand-formatting recipe cards to prove you love blogging.

Next up: one click from "this week's recipes" to a sorted grocery list. Sundays are about to get even quieter.

---

## Next Steps

- [ ] Pick a subject line (or blend two)
- [ ] Apply 2-3 clarity fixes — not all of them
- [ ] Choose one CTA version and paste it in
- [ ] Save one Related Email idea for next week
- [ ] Queue 1-2 social posts from section 10
