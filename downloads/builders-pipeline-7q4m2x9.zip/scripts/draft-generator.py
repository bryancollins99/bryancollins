#!/usr/bin/env python3
"""
Draft Generator - ready-to-edit drafts, not just ideas.

(If you bought this from the launch email: this is the tool that was called
the "Business Intelligence Dashboard" there. Same tool, clearer name.)

What it does, in plain English:
Reads your worklog and recently edited notes, then asks Claude to write
ACTUAL drafts you can edit and publish, saved as separate files in your
output folder:

- 2-3 newsletter emails (500-800 words each, complete with subject lines)
- 3 LinkedIn posts (150-200 words each)
- 2-3 note templates (insights from your week, pre-structured so you can
  drop them straight into your notes folder)
- One summary file listing everything that was generated

Only platforms you have switched on in config.yaml get drafts. Note
templates are always generated.

These are first drafts in your voice (as described in config.yaml), built
from things you actually did. Expect to edit them, not to publish blind.

Tip: this script asks for a lot of text in one go. If drafts come back cut
off, raise max_tokens in config.yaml (8000 is a good ceiling for this tool).

Usage:
    python3 scripts/draft-generator.py [days]

    days (optional): how many days back to scan your notes. Default: 7.

Run it Friday afternoon, edit the drafts over the weekend.
"""

import json
import re
import sys
from datetime import datetime

from bp_config import (
    load_config,
    get_anthropic_client,
    voice_block,
    read_worklog,
    read_recent_notes,
)


def call_claude(client, cfg, system_prompt, user_prompt):
    """Send one request to Claude with beginner-friendly error handling."""
    try:
        return client.messages.create(
            model=cfg["model"],
            max_tokens=cfg["max_tokens"],
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )
    except Exception as e:  # noqa: BLE001 - we translate every failure for beginners
        err = str(e)
        print()
        print("The AI request failed.")
        if "authentication" in err.lower() or "401" in err:
            print("Your API key was rejected.")
            print("Fix: open the .env file next to config.yaml and check that")
            print("ANTHROPIC_API_KEY has no extra spaces or quotes, and that the")
            print("key is still active at https://console.anthropic.com/settings/keys")
        elif "credit" in err.lower() or "billing" in err.lower():
            print("Your Anthropic account is out of credit.")
            print("Fix: add credit at https://console.anthropic.com/settings/billing")
            print("(A full run of this tool costs a few cents.)")
        elif "not_found" in err.lower() or "model" in err.lower() and "404" in err:
            print(f"The model name in config.yaml ('{cfg['model']}') wasn't recognised.")
            print("Fix: check the 'model' line in config.yaml against the current")
            print("model names at https://docs.anthropic.com")
        elif "overloaded" in err.lower() or "529" in err:
            print("Anthropic's servers are busy right now.")
            print("Fix: wait a minute and run the script again.")
        else:
            print(f"Details: {err}")
            print("Common fixes: check your internet connection, then run it again.")
            print("If it keeps failing, check https://status.anthropic.com")
        sys.exit(1)


def build_system_prompt(cfg):
    """Assemble the drafting instructions from the buyer's config."""
    platforms = cfg["platforms"]
    artifact_specs = []
    if platforms.get("newsletter"):
        artifact_specs.append("""NEWSLETTER EMAIL DRAFTS (2-3 emails)
   - Complete emails, ready to edit and send
   - 500-800 words each
   - Subject line: direct, curiosity-driven, specific
   - Format: personal hook, then story or framework, then specific examples, then CTA
   - Mix paragraphs with short numbered lists
   - Include real anecdotes and numbers from the worklog
   - Build-focused: "What did I make? What did I learn?"
   - End with a soft, natural call to action that fits the topic (invite a
     reply, suggest sharing, or point to the writer's own site or project
     IF one is clearly named in the worklog or notes)
   - NEVER invent product names, courses, or links that don't appear in the
     source material""")
    if platforms.get("linkedin"):
        artifact_specs.append("""LINKEDIN POST DRAFTS (3 posts)
   - Complete posts, not outlines
   - 150-200 words each
   - Format: hook, then story, then insight, then CTA
   - Include specific evidence from the worklog (numbers, before/after)""")
    artifact_specs.append("""NOTE TEMPLATES (2-3 notes)
   - Pre-structured permanent notes capturing this week's best insights
   - Each has a title, the insight written out, tags, and related concepts
   - Extract ACTUAL insights from the worklog, not generic advice""")

    return f"""You are a draft generator for someone who builds things and documents them.

YOUR MISSION:
Generate READY-TO-EDIT drafts from this person's worklog and notes.
Not idea lists: actual, complete drafts they can polish and publish.

{voice_block(cfg)}

You'll receive:
1. WORKLOG: raw daily captures of what this person actually did
2. RECENT NOTES: their more refined notes, drafts, and frameworks

Combine insights from both sources.

WHAT YOU GENERATE:

{(chr(10) + chr(10)).join(f"{i}. {spec}" for i, spec in enumerate(artifact_specs, 1))}

OUTPUT FORMAT:
Return ONLY a JSON object (no commentary before or after it).
Make everything copy-paste ready.
"""


def build_user_prompt(cfg, worklog_content, notes_summary, days):
    """Build the user prompt, requesting only the JSON keys for enabled platforms."""
    platforms = cfg["platforms"]
    schema_parts = []
    if platforms.get("newsletter"):
        schema_parts.append("""  "newsletter_emails": [
    {
      "subject": "Email subject line (direct, curiosity-driven)",
      "content": "Full email text (500-800 words, ready to edit)",
      "evidence": "Worklog entries and notes referenced",
      "hook": "Opening personal story or anecdote",
      "framework": "Main structure or teaching point"
    }
  ]""")
    if platforms.get("linkedin"):
        schema_parts.append("""  "linkedin_posts": [
    {
      "title": "Post title",
      "content": "Full post text (150-200 words)",
      "evidence": "Worklog entries referenced"
    }
  ]""")
    schema_parts.append("""  "note_templates": [
    {
      "title": "Note title",
      "content": "Full note content",
      "tags": ["tag1", "tag2"],
      "connections": ["Related concept 1", "Related concept 2"],
      "why_extract": "Why this insight is worth keeping permanently"
    }
  ]""")

    return f"""Generate drafts from the last {days} days of worklog and recent notes.

WORKLOG ENTRIES:
{worklog_content}
{notes_summary}

---

Return a JSON object with this structure:
{{
{",".join(chr(10) + p for p in schema_parts)}
}}

Make all content ready to use immediately."""


def generate_drafts(client, cfg, worklog_content, recent_notes, days):
    """Ask Claude for drafts and parse the JSON response (with repair fallback)."""
    notes_summary = ""
    if recent_notes:
        notes_summary = "\n\nRECENT NOTES (last " + str(days) + " days):\n\n"
        for note in recent_notes:
            notes_summary += f"### {note['file']} (modified {note['modified']})\n"
            notes_summary += f"{note['content'][:500]}...\n\n"

    print("Generating drafts with Claude (this is the slowest step, ~30-60s)...")
    message = call_claude(
        client, cfg,
        build_system_prompt(cfg),
        build_user_prompt(cfg, worklog_content, notes_summary, days),
    )
    response_text = message.content[0].text

    if message.stop_reason == "max_tokens":
        print("Note: the response was cut off before Claude finished.")
        print("Fix for next time: raise max_tokens in config.yaml (try 8000).")
        print("Attempting to recover the complete drafts from what came back...")

    return _extract_json(response_text)


def _extract_json(response_text):
    """Pull the JSON object out of Claude's response, repairing it if truncated."""
    text = response_text
    try:
        if "```json" in text:
            start = text.find("```json") + 7
            end = text.find("```", start)
            text = text[start:end].strip() if end > start else text[start:].strip()
        elif "```" in text:
            start = text.find("```") + 3
            end = text.find("```", start)
            text = text[start:end].strip() if end > start else text[start:].strip()
        else:
            start = text.find("{")
            if start >= 0:
                depth = 0
                in_string = False
                escape_next = False
                for i in range(start, len(text)):
                    ch = text[i]
                    if escape_next:
                        escape_next = False
                        continue
                    if ch == "\\" and in_string:
                        escape_next = True
                        continue
                    if ch == '"':
                        in_string = not in_string
                    elif not in_string:
                        if ch == "{":
                            depth += 1
                        elif ch == "}":
                            depth -= 1
                            if depth == 0:
                                text = text[start:i + 1]
                                break
        return json.loads(text)
    except (json.JSONDecodeError, ValueError):
        repaired = _repair_truncated_json(text)
        if repaired:
            return repaired
        print("Couldn't parse the drafts into separate files, so the raw output")
        print("will be saved as one file instead. Nothing is lost; it's just")
        print("less tidy. Running the script again usually fixes this.")
        return {"raw_output": response_text}


def _repair_truncated_json(text):
    """Attempt to repair truncated JSON by closing open strings and brackets."""
    json_start = text.find("{")
    if json_start < 0:
        return None
    text = text[json_start:]

    last_good = len(text) - 1
    while last_good > 0 and text[last_good] in " \n\r\t":
        last_good -= 1

    in_string = False
    escape_next = False
    stack = []  # open delimiters, in nesting order
    for ch in text[:last_good + 1]:
        if escape_next:
            escape_next = False
            continue
        if ch == "\\" and in_string:
            escape_next = True
            continue
        if ch == '"':
            in_string = not in_string
        elif not in_string:
            if ch in "{[":
                stack.append(ch)
            elif ch in "}]" and stack:
                stack.pop()

    repair = text[:last_good + 1]
    if in_string:
        repair += '"'
    # If the text was cut off right after a key or a comma, drop the dangling bit.
    repair = re.sub(r',\s*$', "", repair)
    repair = re.sub(r'"\s*:\s*$', '": null', repair)
    # Close every still-open container, innermost first.
    for opener in reversed(stack):
        repair += "}" if opener == "{" else "]"

    try:
        return json.loads(repair)
    except (json.JSONDecodeError, ValueError):
        return None


def slugify(title, max_len=60):
    """Convert a title to a filesystem-safe slug for filenames."""
    slug = re.sub(r"[*_#`]", "", title)
    slug = re.sub(r"[^\w\s-]", "", slug)
    slug = slug.strip().replace(" ", "-")
    slug = re.sub(r"-+", "-", slug)
    if len(slug) > max_len:
        slug = slug[:max_len].rstrip("-")
    return slug


def save_artifacts(cfg, drafts, days, note_count):
    """Save every draft as its own file in the output folder."""
    output_dir = cfg["output_dir"]
    output_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y-%m-%d-%H%M")
    date_only = datetime.now().strftime("%Y-%m-%d")
    files_created = []

    # Fallback: JSON parsing failed, save everything as one file.
    if "raw_output" in drafts:
        fallback_path = output_dir / f"Draft-Generator-{timestamp}.md"
        fallback_path.write_text(
            f"# Draft Generator Output - {date_only}\n\n"
            "#drafts #content-ideas\n\n"
            "(The drafts below couldn't be split into separate files this run.\n"
            "They're all here; copy out the ones you want.)\n\n---\n\n"
            + drafts["raw_output"],
            encoding="utf-8",
        )
        files_created.append(fallback_path)
        print(f"  Saved raw output -> {fallback_path.name}")
        return files_created

    # 1. Newsletter email drafts
    for i, email in enumerate(drafts.get("newsletter_emails", []), 1):
        title_slug = slugify(email.get("subject", f"email-{i}"))
        filename = output_dir / f"Newsletter-Email-{timestamp}-{title_slug}.md"
        with open(filename, "w", encoding="utf-8") as f:
            f.write(f"# {email.get('subject', f'Newsletter Email {i}')}\n\n")
            f.write("#newsletter #email #draft\n\n")
            f.write("---\n\n")
            f.write(email.get("content", ""))
            f.write("\n\n---\n\n")
            f.write(f"**Hook**: {email.get('hook', 'N/A')}\n\n")
            f.write(f"**Framework**: {email.get('framework', 'N/A')}\n\n")
            f.write(f"**Evidence**: {email.get('evidence', 'N/A')}\n")
        files_created.append(filename)
        print(f"  Newsletter email {i} -> {filename.name}")

    # 2. LinkedIn drafts
    for i, post in enumerate(drafts.get("linkedin_posts", []), 1):
        title_slug = slugify(post.get("title", f"post-{i}"))
        filename = output_dir / f"LinkedIn-Draft-{timestamp}-{title_slug}.md"
        with open(filename, "w", encoding="utf-8") as f:
            f.write(f"# {post.get('title', f'LinkedIn Post {i}')}\n\n")
            f.write("#linkedin #draft #social\n\n")
            f.write("---\n\n")
            f.write(post.get("content", ""))
            f.write("\n\n---\n\n")
            f.write(f"**Evidence**: {post.get('evidence', 'N/A')}\n")
        files_created.append(filename)
        print(f"  LinkedIn draft {i} -> {filename.name}")

    # 3. Note templates
    for i, note in enumerate(drafts.get("note_templates", []), 1):
        title_slug = slugify(note.get("title", f"note-{i}"))
        filename = output_dir / f"Note-Template-{timestamp}-{title_slug}.md"
        with open(filename, "w", encoding="utf-8") as f:
            f.write(f"# {note.get('title', f'Note {i}')}\n\n")
            f.write("#note-template #permanent-note\n\n")
            f.write(note.get("content", ""))
            f.write("\n\n---\n\n")
            f.write(f"**Tags**: {', '.join(note.get('tags', []))}\n\n")
            f.write(f"**Connections**: {', '.join(note.get('connections', []))}\n\n")
            f.write(f"**Why keep this**: {note.get('why_extract', 'N/A')}\n")
        files_created.append(filename)
        print(f"  Note template {i} -> {filename.name}")

    # 4. Summary file listing everything generated this run
    summary_path = output_dir / f"Draft-Generator-Summary-{timestamp}.md"
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write(f"# Draft Generator Summary - {date_only}\n\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write("Sources:\n")
        f.write(f"- {cfg['worklog_file'].name} (recent entries)\n")
        f.write(f"- {note_count} recently created/edited notes (last {days} days)\n\n")
        f.write("#drafts #summary\n\n---\n\n")
        f.write("## Files generated this run\n\n")
        for path in files_created:
            f.write(f"- {path.name}\n")
        f.write("\n## Counts\n\n")
        f.write(f"- Newsletter emails: {len(drafts.get('newsletter_emails', []))} "
                "(tagged #newsletter)\n")
        f.write(f"- LinkedIn drafts: {len(drafts.get('linkedin_posts', []))} "
                "(tagged #linkedin)\n")
        f.write(f"- Note templates: {len(drafts.get('note_templates', []))} "
                "(tagged #note-template)\n\n")
        f.write("---\n\n")
        f.write("**Next steps**:\n")
        f.write("1. Edit each draft: these are first drafts in your voice, not final copy\n")
        f.write("2. Schedule the newsletter emails in your email tool\n")
        f.write("3. Queue the LinkedIn posts in your scheduler (or post them directly)\n")
        f.write("4. Move the note templates into your notes folder once reviewed\n")
    files_created.append(summary_path)
    print(f"  Summary -> {summary_path.name}")

    return files_created


def main():
    print("=" * 60)
    print("DRAFT GENERATOR")
    print("Ready-to-edit drafts from this week's work")
    print("=" * 60)
    print()

    days = 7
    if len(sys.argv) > 1:
        try:
            days = int(sys.argv[1])
        except ValueError:
            print("Usage: python3 scripts/draft-generator.py [days]")
            print("Example: python3 scripts/draft-generator.py 14")
            sys.exit(1)

    cfg = load_config()
    client = get_anthropic_client()

    print(f"Reading worklog: {cfg['worklog_file']}")
    print(f"Analyzing the last {days} days")
    print()

    worklog_content = read_worklog(cfg)
    print(f"Worklog size: {len(worklog_content.split())} words")

    print("Scanning recently created/edited notes...")
    recent_notes = read_recent_notes(cfg, days_back=days)
    print(f"Recent notes found: {len(recent_notes)}")
    print()

    drafts = generate_drafts(client, cfg, worklog_content, recent_notes, days)

    print()
    print("Saving drafts...")
    files_created = save_artifacts(cfg, drafts, days, len(recent_notes))

    print()
    print("=" * 60)
    print("DRAFTS READY")
    print("=" * 60)
    print()
    print(f"Output folder: {cfg['output_dir']}")
    print(f"Files created: {len(files_created)}")
    print()
    print("Next steps:")
    print("1. Open the Draft-Generator-Summary file for the full list")
    print("2. Edit the newsletter drafts, then schedule them in your email tool")
    print("3. Queue the LinkedIn drafts in your scheduler")
    print("4. Review the note templates and keep the ones worth keeping")
    print()


if __name__ == "__main__":
    main()
