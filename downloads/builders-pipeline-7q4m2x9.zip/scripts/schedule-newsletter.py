#!/usr/bin/env python3
"""
Newsletter Scheduler — push a markdown draft to Kit (ConvertKit).

Reads a markdown draft, converts it to clean email HTML, and creates it in
your Kit account using API v4. It checks your existing Kit schedule and
picks the next open day at your usual send hour, so you never double-book
a day.

SAFE BY DEFAULT: with draft_only: true in config.yaml (the shipped
default), the email is created as a DRAFT in Kit — nothing is scheduled
and nothing sends until you review it in the Kit dashboard. Set
draft_only: false in config.yaml when you're ready to let this script
schedule sends for real.

Usage:
    python3 scripts/schedule-newsletter.py                  # pick a draft interactively
    python3 scripts/schedule-newsletter.py my-email.md      # push a specific draft
    python3 scripts/schedule-newsletter.py --draft file.md  # force draft mode for this run
    python3 scripts/schedule-newsletter.py --list           # list drafts in your output folder
    python3 scripts/schedule-newsletter.py --next-slots     # show the next 3 open send slots
    python3 scripts/schedule-newsletter.py --scheduled      # show what's already queued on Kit
"""

import re
import sys
from datetime import datetime, timedelta
from pathlib import Path

from bp_config import load_config, get_kit_api_key

try:
    import requests
except ImportError:
    print("Missing dependency: requests")
    print("Fix: pip install -r requirements.txt")
    sys.exit(1)

KIT_BROADCASTS_URL = "https://api.kit.com/v4/broadcasts"

# Send every day of the week by default (0=Monday ... 6=Sunday).
SEND_DAYS = [0, 1, 2, 3, 4, 5, 6]


def kit_settings(cfg):
    """Read the kit: section of config.yaml with safe defaults."""
    kit_cfg = cfg.get("kit") or {}
    send_hour = int(kit_cfg.get("send_hour", 10))
    if not 0 <= send_hour <= 23:
        print(f"config.yaml problem: kit.send_hour is {send_hour}, but it must be 0-23.")
        sys.exit(1)
    draft_only = bool(kit_cfg.get("draft_only", True))
    signature_file = kit_cfg.get("signature_file")
    return send_hour, draft_only, signature_file


def read_signature(signature_file):
    """Optional markdown snippet appended to every email (from config.yaml)."""
    if not signature_file:
        return None
    path = Path(str(signature_file)).expanduser()
    if not path.exists():
        print(f"config.yaml points kit.signature_file at a file that doesn't exist:")
        print(f"  {path}")
        print("Fix: create that file, correct the path, or remove the")
        print("signature_file line from config.yaml to send without a signature.")
        sys.exit(1)
    return path.read_text(encoding="utf-8", errors="ignore").strip()


def list_drafts(cfg):
    """List markdown drafts in output_dir (newest first), skipping analysis files."""
    drafts_dir = cfg["output_dir"]
    if not drafts_dir.exists():
        return []
    drafts = [
        f for f in drafts_dir.glob("*.md")
        if not f.name.endswith("-analysis.md") and not f.name.startswith(".")
    ]
    drafts.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    return drafts


def parse_newsletter(file_path):
    """Extract (subject, body, suggested_date) from a markdown draft.

    Subject = the first "# " heading. Body = everything between the first
    "---" separator and the last one (so metadata above/below is skipped).
    An optional "**Suggested Date**: YYYY-MM-DD" line requests a send day.
    """
    content = file_path.read_text(encoding="utf-8", errors="ignore")
    lines = content.split("\n")

    subject = ""
    for line in lines:
        if line.startswith("# "):
            subject = line[2:].strip()
            break

    if not subject:
        print(f"No subject line found in {file_path.name}.")
        print("Fix: the first line of your draft should be a heading, like:")
        print("  # My subject line here")
        return None, None, None

    suggested_date = None
    for line in lines:
        if line.startswith("**Suggested Date**:"):
            date_str = line.split(":", 1)[1].strip()
            try:
                suggested_date = datetime.strptime(date_str, "%Y-%m-%d")
            except ValueError:
                pass

    start_idx = 0
    end_idx = len(lines)
    separator_positions = [i for i, line in enumerate(lines) if line.strip() == "---"]

    if len(separator_positions) >= 2:
        start_idx = separator_positions[0] + 1
        for i in range(len(lines) - 1, start_idx - 1, -1):
            if lines[i].strip() == "---":
                end_idx = i
                break
    elif len(separator_positions) == 1:
        start_idx = separator_positions[0] + 1

    body = "\n".join(lines[start_idx:end_idx]).strip()

    if not body:
        print(f"Warning: no body content found in {file_path.name}.")
        print("The email body is everything between the first and last '---' lines")
        print("(or the whole file if there are no '---' lines).")

    return subject, body, suggested_date


def markdown_to_html(markdown_text):
    """Convert simple markdown to clean email HTML that Kit accepts."""
    html = markdown_text

    # Safety net: replace YouTube iframe embeds with a plain link
    # (iframes are stripped by email clients — a preview may show them
    # but the delivered email won't).
    def iframe_to_link(match):
        src = re.search(r'src=["\']([^"\']+)["\']', match.group(0))
        if src:
            url = src.group(1).replace("/embed/", "/watch?v=")
            return f"[Watch the video]({url})"
        return ""
    html = re.sub(r"<iframe[^>]*youtube[^>]*>.*?</iframe>", iframe_to_link, html,
                  flags=re.IGNORECASE | re.DOTALL)

    # [text](url) links -> <a>
    html = re.sub(r"\[([^\]]+)\]\(([^\)]+)\)", r'<a href="\2">\1</a>', html)

    # Bare URLs (not already inside a link) -> clickable links
    html = re.sub(r'(?<!href=")(?<!">)(https?://[^\s<>"]+)', r'<a href="\1">\1</a>', html)

    # **bold** and *italic*
    html = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", html)
    html = re.sub(r"\*([^*]+)\*", r"<em>\1</em>", html)

    # Multi-line blockquotes -> single <blockquote> blocks
    lines = html.split("\n")
    processed_lines = []
    in_blockquote = False
    blockquote_lines = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("&gt; ") or stripped.startswith("> "):
            quote_text = re.sub(r"^(&gt;|>)\s*", "", stripped)
            if not in_blockquote:
                in_blockquote = True
                blockquote_lines = []
            blockquote_lines.append(quote_text)
        else:
            if in_blockquote:
                processed_lines.append(f'<blockquote>{" ".join(blockquote_lines)}</blockquote>')
                in_blockquote = False
                blockquote_lines = []
            processed_lines.append(line)
    if in_blockquote:
        processed_lines.append(f'<blockquote>{" ".join(blockquote_lines)}</blockquote>')
    lines = processed_lines

    # Lists and paragraphs
    in_ol = False
    in_ul = False
    result_lines = []
    for line in lines:
        stripped = line.strip()
        if re.match(r"^\d+\.\s", stripped):
            if in_ul:
                result_lines.append("</ul>")
                in_ul = False
            if not in_ol:
                result_lines.append("<ol>")
                in_ol = True
            item_text = re.sub(r"^\d+\.\s*", "", stripped)
            result_lines.append(f"<li>{item_text}</li>")
        elif re.match(r"^[-*]\s", stripped):
            if in_ol:
                result_lines.append("</ol>")
                in_ol = False
            if not in_ul:
                result_lines.append("<ul>")
                in_ul = True
            item_text = re.sub(r"^[-*]\s*", "", stripped)
            result_lines.append(f"<li>{item_text}</li>")
        elif not stripped and (in_ol or in_ul):
            # Blank line inside a list — keep the list open
            continue
        else:
            if in_ol:
                result_lines.append("</ol>")
                in_ol = False
            if in_ul:
                result_lines.append("</ul>")
                in_ul = False
            if stripped.startswith("<blockquote>") or stripped.startswith("<ol>") or stripped.startswith("<ul>"):
                result_lines.append(line)
            elif stripped:
                result_lines.append(f"<p>{line}</p>")
            else:
                result_lines.append("")
    if in_ol:
        result_lines.append("</ol>")
    if in_ul:
        result_lines.append("</ul>")

    return "\n".join(result_lines)


def get_next_send_slot(send_hour, from_date=None, occupied_dates=None):
    """Next open send slot at send_hour, skipping days already booked on Kit."""
    if from_date is None:
        from_date = datetime.now()
    if occupied_dates is None:
        occupied_dates = set()

    # Start from tomorrow — never schedule for today.
    next_date = (from_date + timedelta(days=1)).replace(
        hour=send_hour, minute=0, second=0, microsecond=0
    )
    while next_date.weekday() not in SEND_DAYS:
        next_date += timedelta(days=1)

    attempts = 0
    while next_date.strftime("%Y-%m-%d") in occupied_dates and attempts < 60:
        next_date += timedelta(days=1)
        while next_date.weekday() not in SEND_DAYS:
            next_date += timedelta(days=1)
        attempts += 1
    if attempts >= 60:
        print("Warning: could not find an open slot within 60 days.")
    return next_date


def get_next_n_slots(send_hour, n=3, occupied_dates=None):
    """The next N open send slots."""
    if occupied_dates is None:
        occupied_dates = set()
    slots = []
    current = datetime.now()
    for _ in range(n):
        slot = get_next_send_slot(send_hour, current, occupied_dates)
        slots.append(slot)
        occupied_dates = occupied_dates | {slot.strftime("%Y-%m-%d")}
        current = slot
    return slots


def kit_headers(api_key):
    return {"X-Kit-Api-Key": api_key, "Content-Type": "application/json"}


def fetch_scheduled_broadcasts(api_key):
    """Fetch upcoming scheduled broadcasts from Kit to avoid double-booking.

    Returns (occupied_dates, broadcasts): a set of 'YYYY-MM-DD' strings for
    days that already have a scheduled send, plus details for display.
    Checks the most recent page of broadcasts — Kit returns them newest
    first, so upcoming sends are all on page 1.
    """
    occupied_dates = set()
    broadcasts = []
    try:
        response = requests.get(KIT_BROADCASTS_URL, headers=kit_headers(api_key), timeout=15)
        response.raise_for_status()
        data = response.json()
        for broadcast in data.get("broadcasts", []):
            send_at_str = broadcast.get("send_at")
            if not send_at_str:
                continue  # drafts have no send_at
            try:
                send_at = datetime.fromisoformat(send_at_str.replace("Z", "+00:00"))
                if send_at.replace(tzinfo=None) < datetime.now():
                    continue  # already sent
                date_key = send_at.strftime("%Y-%m-%d")
                occupied_dates.add(date_key)
                broadcasts.append({
                    "id": broadcast.get("id"),
                    "subject": broadcast.get("subject", "(no subject)"),
                    "send_at": date_key,
                    "send_time": send_at.strftime("%H:%M"),
                })
            except (ValueError, AttributeError):
                continue
    except requests.exceptions.RequestException as e:
        print(f"Warning: could not fetch your existing Kit schedule: {e}")
        if getattr(e, "response", None) is not None:
            print(f"  Kit said: {e.response.text[:300]}")
        print("  Continuing without double-booking protection.\n")

    broadcasts.sort(key=lambda b: b["send_at"])
    return occupied_dates, broadcasts


def create_broadcast(api_key, subject, html_content, send_at=None, public=True):
    """Create a broadcast on Kit via API v4 (POST /v4/broadcasts).

    With send_at=None, Kit saves it as a draft (nothing sends).
    With a send_at timestamp, Kit schedules it.
    """
    plain_text = re.sub(r"<[^>]+>", "", html_content).strip()
    first_line = plain_text.split("\n")[0].strip()
    preview_text = first_line[:150] if first_line else subject

    payload = {
        "subject": subject,
        "content": html_content,
        "description": subject,
        "preview_text": preview_text,
        "public": public,
        "subscriber_filter": [{"all": None, "any": None, "none": None}],
    }
    if send_at:
        send_at_iso = send_at.strftime("%Y-%m-%dT%H:%M:%S.000Z")
        payload["send_at"] = send_at_iso
        payload["published_at"] = send_at_iso

    try:
        response = requests.post(KIT_BROADCASTS_URL, json=payload,
                                 headers=kit_headers(api_key), timeout=30)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Kit API error: {e}")
        if getattr(e, "response", None) is not None:
            print(f"Kit said: {e.response.text[:500]}")
            if e.response.status_code == 401:
                print("\nThat's an authentication error. Check that KIT_API_KEY in your")
                print(".env file is the v4 API key from Kit -> Settings -> Developer")
                print("(it starts with 'kit_').")
        return None


def print_schedule(broadcasts, title):
    print(f"\n{title} ({len(broadcasts)}):\n")
    for i, b in enumerate(broadcasts, 1):
        day_name = datetime.strptime(b["send_at"], "%Y-%m-%d").strftime("%A")
        print(f"{i}. {day_name}, {b['send_at']} at {b['send_time']}  —  {b['subject']}")


def pick_draft_interactively(cfg):
    """Show drafts in output_dir and let the user pick one."""
    drafts = list_drafts(cfg)
    if not drafts:
        print(f"No markdown drafts found in: {cfg['output_dir']}")
        print("Fix: save your draft .md file there, or pass a file path directly:")
        print("  python3 scripts/schedule-newsletter.py path/to/my-email.md")
        sys.exit(1)

    print(f"\nDrafts in {cfg['output_dir']} ({len(drafts)}):\n")
    for i, draft in enumerate(drafts, 1):
        mtime = datetime.fromtimestamp(draft.stat().st_mtime)
        print(f"{i}. {draft.name}   (modified {mtime.strftime('%Y-%m-%d %H:%M')})")

    choice = input("\nEnter a draft number (or 'q' to quit): ").strip()
    if choice.lower() == "q":
        print("Cancelled.")
        sys.exit(0)
    try:
        idx = int(choice) - 1
        if not 0 <= idx < len(drafts):
            raise ValueError
    except ValueError:
        print("That wasn't a valid number. Run the script again and pick from the list.")
        sys.exit(1)
    return drafts[idx]


def resolve_draft_path(cfg, arg):
    """Accept a direct path, or a filename inside output_dir."""
    path = Path(arg).expanduser()
    if path.exists():
        return path
    alt = cfg["output_dir"] / arg
    if alt.exists():
        return alt
    print(f"File not found: {arg}")
    print(f"Looked in the current folder and in {cfg['output_dir']}.")
    print("Tip: run with --list to see the drafts in your output folder.")
    sys.exit(1)


def main():
    cfg = load_config()
    send_hour, draft_only, signature_file = kit_settings(cfg)

    args = sys.argv[1:]

    force_draft = False
    if "--draft" in args:
        force_draft = True
        args.remove("--draft")
    skip_confirm = False
    if "--force" in args:
        skip_confirm = True
        args.remove("--force")

    # Info-only commands
    if args and args[0] == "--list":
        drafts = list_drafts(cfg)
        if not drafts:
            print(f"No markdown drafts found in: {cfg['output_dir']}")
            return
        print(f"\nDrafts in {cfg['output_dir']} ({len(drafts)}):\n")
        for i, draft in enumerate(drafts, 1):
            mtime = datetime.fromtimestamp(draft.stat().st_mtime)
            print(f"{i}. {draft.name}   (modified {mtime.strftime('%Y-%m-%d %H:%M')})")
        return

    if args and args[0] == "--scheduled":
        api_key = get_kit_api_key()
        _, broadcasts = fetch_scheduled_broadcasts(api_key)
        if not broadcasts:
            print("\nNo upcoming scheduled broadcasts on Kit.\n")
        else:
            print_schedule(broadcasts, "Upcoming scheduled broadcasts")
        return

    if args and args[0] == "--next-slots":
        api_key = get_kit_api_key()
        occupied_dates, broadcasts = fetch_scheduled_broadcasts(api_key)
        if broadcasts:
            print_schedule(broadcasts, "Already scheduled")
        slots = get_next_n_slots(send_hour, 3, occupied_dates)
        print(f"\nNext 3 open send slots (daily at {send_hour:02d}:00):\n")
        for i, slot in enumerate(slots, 1):
            print(f"{i}. {slot.strftime('%A, %Y-%m-%d %H:%M')}")
        return

    # Pick the draft file
    if args:
        if args[0].startswith("--"):
            print(f"Unknown option: {args[0]}")
            print(__doc__.split("Usage:")[1])
            sys.exit(1)
        selected_draft = resolve_draft_path(cfg, args[0])
    else:
        selected_draft = pick_draft_interactively(cfg)

    create_as_draft = draft_only or force_draft

    api_key = get_kit_api_key()

    print(f"\nParsing: {selected_draft.name}")
    subject, body, suggested_date = parse_newsletter(selected_draft)
    if subject is None:
        sys.exit(1)
    print(f"Subject: {subject}")

    signature = read_signature(signature_file)
    if signature:
        body = body.rstrip() + "\n\n" + signature
        print("Appended your signature file to the email.")

    html_content = markdown_to_html(body)

    send_at = None
    if create_as_draft:
        if draft_only and not force_draft:
            print("\nSafe mode: draft_only is true in config.yaml, so this will be")
            print("created as a DRAFT in Kit. Nothing sends until you schedule it")
            print("yourself. (Set draft_only: false when you trust the pipeline.)")
        else:
            print("\nCreating as a draft (not scheduled).")
    else:
        print("\nChecking your existing schedule on Kit...")
        occupied_dates, existing = fetch_scheduled_broadcasts(api_key)
        if existing:
            print_schedule(existing, "Already scheduled")

        if suggested_date:
            send_at = suggested_date.replace(hour=send_hour, minute=0)
            if send_at.strftime("%Y-%m-%d") in occupied_dates:
                send_at = get_next_send_slot(send_hour, suggested_date, occupied_dates)
                print(f"Suggested date {suggested_date.strftime('%Y-%m-%d')} already has an "
                      f"email — moved to the next open slot.")
        else:
            send_at = get_next_send_slot(send_hour, occupied_dates=occupied_dates)
        print(f"\nWill schedule for: {send_at.strftime('%A, %Y-%m-%d %H:%M')}")

    print("\nPreview (first 200 characters of the email HTML):")
    print(html_content[:200] + "...\n")

    if not skip_confirm:
        if create_as_draft:
            confirm = input("Create this draft in Kit? (y/n): ").strip().lower()
        else:
            confirm = input("Schedule this broadcast? (y/n): ").strip().lower()
        if confirm != "y":
            print("Cancelled — nothing was sent to Kit.")
            return

    if create_as_draft:
        print("\nCreating draft on Kit...")
    else:
        print("\nScheduling broadcast on Kit...")

    result = create_broadcast(api_key, subject, html_content, send_at)
    if not result:
        print("Failed to create the broadcast. See the error above.")
        sys.exit(1)

    broadcast_id = result.get("broadcast", {}).get("id")

    if create_as_draft:
        print("\nDraft created in Kit — nothing will send until you schedule it.")
        print(f"  Subject: {subject}")
        print(f"  Broadcast ID: {broadcast_id}")
        if broadcast_id:
            print(f"  Edit it here: https://app.kit.com/campaigns/{broadcast_id}/edit")
        print("  (or open Kit -> Send -> Broadcasts -> Drafts)")
    else:
        print("\nBroadcast scheduled.")
        print(f"  Subject: {subject}")
        print(f"  Broadcast ID: {broadcast_id}")
        print(f"  Sends: {send_at.strftime('%A, %Y-%m-%d %H:%M')}")

        print("\nVerifying the schedule...")
        _, updated = fetch_scheduled_broadcasts(api_key)
        if updated:
            date_counts = {}
            for b in updated:
                date_counts.setdefault(b["send_at"], []).append(b["subject"])
            conflicts = {d: s for d, s in date_counts.items() if len(s) > 1}
            if conflicts:
                print(f"\nWARNING: {len(conflicts)} day(s) have more than one email scheduled:")
                for d, subjects in sorted(conflicts.items()):
                    print(f"  {d}:")
                    for s in subjects:
                        print(f"    - {s}")
                print("  Fix this in Kit -> Send -> Broadcasts -> Scheduled.")
            else:
                print("No conflicts — one email per day.")
            print_schedule(updated, "Full upcoming schedule")
        else:
            print("Could not verify the schedule (no broadcasts returned).")
        print("\nDouble-check in your Kit dashboard -> Send -> Broadcasts.")


if __name__ == "__main__":
    main()
