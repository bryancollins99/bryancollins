#!/usr/bin/env python3
"""
Email Analyzer — editorial feedback for a newsletter draft.

Point it at a markdown draft and it returns a 10-section editorial analysis:
subject lines, hooks, content-framework gaps, big ideas and metaphors, a
Six Thinking Hats critique, writing and clarity fixes, CTA options,
follow-up email ideas, long-form headlines, and social posts. It also
writes an improved version of your draft that applies the best suggestions.

The analysis is saved next to your draft with an -analysis.md suffix.

Usage:
    python3 scripts/email-analyzer.py path/to/draft.md
    python3 scripts/email-analyzer.py draft.md --output=my-analysis.md
    python3 scripts/email-analyzer.py draft.md --section=1,2,9
"""

import sys
from datetime import datetime
from pathlib import Path

from bp_config import load_config, get_anthropic_client, voice_block

SECTION_NAMES = {
    1: "Subject Lines",
    2: "Hooks",
    3: "Content Framework",
    4: "Big Ideas, Analogies and Metaphors",
    5: "Six Thinking Hats Analysis",
    6: "Writing and Clarity",
    7: "Transition and CTA",
    8: "Related Emails",
    9: "Viral Headlines",
    10: "Social Media Posts",
}

# The 10-section editorial framework. This is the full system prompt for the
# analysis call — your voice settings from config.yaml are appended to it.
ANALYZER_FRAMEWORK = """You are an editorial strategist who analyzes draft newsletters for an independent creator. The drafts document real work — projects, experiments, systems, and lessons learned — not aspirational advice.

Your task: provide actionable improvements and repurposing suggestions for this draft, always referencing specific lines or sections from it.

CORE RULES

DO NOT:
- Give generic advice ("use visual elements", "add a poll", "engage your audience")
- Offer vague suggestions ("use transition words") without a concrete rewrite drawn from the draft
- Suggest content ideas unrelated to the work actually documented in the draft
- Use preamble, filler, or waffle — get straight into the analysis

DO:
- Quote or reference specific lines from the draft when suggesting improvements
- Prefer counter-intuitive insights over obvious advice
- Base every repurposing idea on the actual work described, not an idealized version of it
- Keep the author's voice and message intact — improve delivery, not identity

OUTPUT FORMAT

Provide exactly 10 sections using H2 headings, numbered and titled as below. Skip all preamble.

## 1. Subject Lines
Generate 10 subject lines in sentence case. Do NOT use "firstname" merge variables.
Focus on: field-report framing ("I built X", "I tested Y"), specific results or outcomes, counter-intuitive findings, and system/framework reveals.
Bad: "You need to try this", "The secret to success".
Good: "I spent a weekend automating this (one step surprised me)", "This checklist cut my editing time in half".

## 2. Hooks
Provide 10 opening hooks, maximum 49 characters each. First-person point of view, complete sentences.
Each hook should highlight a surprising or counter-intuitive insight, quantify a result where possible, or tease a unique system.
Label each with the emotion it targets, from the outer edge of the wheel of emotions.
Format: "[Emotion] - Hook text"

## 3. Content Framework
Check the draft against these talking points and suggest specific additions or edits for any gaps.
Format: **Talking point in bold** followed by your specific suggestion.
- What is this and how is it different?
- What do I get from you?
- Where did it come from? (Real origin story — the actual project context, never invented)
- Who is this NOT for? (Document constraints and limits honestly)
- Problem and solution
- How does it work? (System mechanics, not theory)
- Why should I listen? (Proof from the actual work)
- Logical urgency (What is the next step? What compounds?)
- Proof, testimonials, case studies (From the documented work)
Do NOT summarize themes. Only provide improvements with specific references to draft content.

## 4. Big Ideas, Analogies and Metaphors
Suggest 5 metaphors or analogies that could tie the narrative together.
Emphasize everyday concepts, strong visuals, and pop culture. Avoid cliches — no "journey", "marathon", or "climbing mountains".
Format: **Title in bold** followed by a 2-3 sentence explanation.

## 5. Six Thinking Hats Analysis
Critically analyze the email through each of De Bono's six thinking hats:
White (facts and data), Red (emotion), Black (risks and weaknesses), Yellow (benefits), Green (creative alternatives), Blue (structure and process).
Format for each hat:
**Hat name (what it examines)**: the issue you found
**Fix**: one specific suggestion with an example drawn from the draft.

## 6. Writing and Clarity
Value clarity, originality, and concision. Do NOT change the tone or message.
Review for grammar errors, factual slips, confusing sentences, logical inconsistencies, and readability.
Format: Quote the original line → suggest the fix → give the reason.

## 7. Transition and CTA
Refine the transition into the email's call to action (or propose one that fits the draft). Use frameworks such as:
- Current state vs future state
- Future pacing ("Imagine when you...")
- Teasing the offer
- A simple reply-based CTA ("Reply with WORD and I'll send you...")
- The 3 Whys: value, bonuses, deadline or scarcity
Output 2-3 versions of the transition plus CTA.

## 8. Related Emails
List 5-10 follow-up email ideas on connected topics.
Each must document real or plausible FUTURE work that builds on the systems and projects in this draft — not theoretical "how to" content.
Format: **Email title in bold** followed by a 1-2 sentence description of the work it would document.

## 9. Viral Headlines
Provide 5-7 headlines for long-form platforms (Medium, Substack, a blog). First-person point of view.
Focus on specific outcomes from the documented work, counter-intuitive findings, system reveals, and build logs.
Bad: "10 ways to be productive". Good: "I automated the most boring part of my business (here's the before and after)".

## 10. Social Media Posts
Create 10 short social posts based on the email, in the author's voice.
Pithy and contrarian. Complete standalone statements — no teasers like "Let me show you why", no hashtags, no "check out my latest post".
Format: just the posts, one per paragraph."""

IMPROVED_VERSION_PROMPT = """Based on the analysis, create an improved version of the email draft.

ORIGINAL DRAFT:
---
{draft}
---

ANALYSIS:
---
{analysis}
---

Create an improved version that implements the key suggestions:
- The best subject line from the analysis (as a "Subject:" first line)
- The writing and clarity improvements
- Content framework gaps filled
- A better hook/opening
- A stronger CTA

Keep the same general structure and voice — apply the improvements, don't rewrite the author's personality out of it.
Output ONLY the improved email, no preamble."""


def read_draft(path):
    """Read the draft file, with beginner-friendly errors."""
    if not path.exists():
        print(f"Draft file not found: {path}")
        print("Check the path and try again. Example:")
        print("  python3 scripts/email-analyzer.py ~/notes/my-draft.md")
        sys.exit(1)
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except OSError as e:
        print(f"Could not read {path}: {e}")
        sys.exit(1)


def build_system_prompt(cfg):
    """Framework + the buyer's voice settings from config.yaml."""
    return ANALYZER_FRAMEWORK + "\n\n" + voice_block(cfg)


def analyze_email(client, cfg, draft_content, sections=None):
    """Run the 10-section analysis (or just the requested sections)."""
    if sections:
        requested = [SECTION_NAMES[s] for s in sections if s in SECTION_NAMES]
        user_message = (
            "Analyze this newsletter draft. Only provide these sections: "
            + ", ".join(requested)
            + f"\n\nDRAFT EMAIL:\n---\n{draft_content}\n---\n\n"
            "Focus the analysis on the requested sections only."
        )
    else:
        user_message = (
            "Analyze this newsletter draft using the 10-section framework.\n\n"
            f"DRAFT EMAIL:\n---\n{draft_content}\n---\n\n"
            "Provide the complete analysis for all 10 sections."
        )

    try:
        message = client.messages.create(
            model=cfg["model"],
            max_tokens=cfg["max_tokens"],
            temperature=0.7,
            system=build_system_prompt(cfg),
            messages=[{"role": "user", "content": user_message}],
        )
    except Exception as e:
        print(f"The AI request failed: {e}")
        print("Common fixes: check your internet connection, and confirm the")
        print("ANTHROPIC_API_KEY in your .env file is valid and has credit.")
        sys.exit(1)

    return message.content[0].text


def generate_improved_version(client, cfg, draft_content, analysis):
    """Second pass: rewrite the draft applying the analysis."""
    try:
        message = client.messages.create(
            model=cfg["model"],
            max_tokens=cfg["max_tokens"],
            system=build_system_prompt(cfg),
            messages=[{
                "role": "user",
                "content": IMPROVED_VERSION_PROMPT.format(
                    draft=draft_content, analysis=analysis
                ),
            }],
        )
    except Exception as e:
        print(f"Could not generate the improved version: {e}")
        print("The analysis itself succeeded — it will still be saved.")
        return None
    return message.content[0].text


def save_analysis(analysis, improved_version, draft_path, draft_content, output_path=None):
    """Write the analysis file next to the draft (or to --output)."""
    if output_path:
        output_file = Path(output_path).expanduser()
    else:
        output_file = draft_path.parent / f"{draft_path.stem}-analysis.md"
    output_file.parent.mkdir(parents=True, exist_ok=True)

    draft_title = draft_path.stem.replace("-", " ").replace("_", " ").title()
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")

    parts = [f"# Email Analysis — {draft_title}\n"]
    parts.append(f"**Draft file**: {draft_path.name}")
    parts.append(f"**Analyzed**: {timestamp}")
    parts.append(f"**Original length**: {len(draft_content.split())} words")
    if improved_version:
        parts.append(f"**Improved version length**: {len(improved_version.split())} words")
    parts.append("\n---\n")

    if improved_version:
        parts.append("## Improved Version\n")
        parts.append("A revised draft that applies the strongest suggestions from the analysis below. Compare it against your original and cherry-pick what works.\n")
        parts.append(improved_version.strip())
        parts.append("\n---\n")

    parts.append("## Analysis\n")
    parts.append(analysis.strip())
    parts.append("\n---\n")
    parts.append("## Next Steps\n")
    parts.append("- [ ] Pick a subject line (or blend two)")
    parts.append("- [ ] Apply 2-3 clarity fixes — not all of them")
    parts.append("- [ ] Choose one CTA version and paste it in")
    parts.append("- [ ] Save one Related Email idea for next week")
    parts.append("- [ ] Queue 1-2 social posts from section 10")
    parts.append("")

    output_file.write_text("\n".join(parts), encoding="utf-8")
    return output_file


def parse_args(argv):
    """Return (draft_file, output_path, sections) from CLI args."""
    if len(argv) < 2:
        print("Usage: python3 scripts/email-analyzer.py <draft.md> [--output=<path>] [--section=<1-10,...>]")
        print()
        print("Examples:")
        print("  python3 scripts/email-analyzer.py ~/notes/newsletter-draft.md")
        print("  python3 scripts/email-analyzer.py draft.md --output=analysis.md")
        print("  python3 scripts/email-analyzer.py draft.md --section=1,2   (subject lines + hooks only)")
        sys.exit(1)

    draft_file = argv[1]
    output_path = None
    sections = None
    for arg in argv[2:]:
        if arg.startswith("--output="):
            output_path = arg.split("=", 1)[1]
        elif arg.startswith("--section="):
            section_str = arg.split("=", 1)[1]
            sections = [int(s) for s in section_str.split(",") if s.strip().isdigit()]
            if not sections:
                print("No valid section numbers in --section. Use numbers 1-10, e.g. --section=1,2,9")
                sys.exit(1)
        else:
            print(f"Unknown option: {arg}")
            print("Valid options: --output=<path>  --section=<1-10,...>")
            sys.exit(1)
    return draft_file, output_path, sections


def main():
    print("=" * 60)
    print("EMAIL ANALYZER — editorial feedback for newsletter drafts")
    print("=" * 60)
    print()

    draft_file, output_path, sections = parse_args(sys.argv)

    cfg = load_config()
    client = get_anthropic_client()

    draft_path = Path(draft_file).expanduser()
    draft_content = read_draft(draft_path)
    word_count = len(draft_content.split())

    print(f"Reading draft: {draft_path.name} ({word_count} words)")
    if word_count < 100:
        print(f"Note: this draft is very short ({word_count} words) — the analysis may be thin.")
    elif word_count > 2000:
        print(f"Note: this draft is long ({word_count} words); the run will use more API tokens.")
        answer = input("Continue? (y/n): ").strip().lower()
        if answer != "y":
            print("Cancelled.")
            sys.exit(0)
    print()

    if sections:
        names = ", ".join(SECTION_NAMES[s] for s in sections if s in SECTION_NAMES)
        print(f"Analyzing (sections: {names})...")
    else:
        print("Analyzing (all 10 sections — this usually takes 30-60 seconds)...")
    analysis = analyze_email(client, cfg, draft_content, sections)
    print("Analysis done.")

    improved_version = None
    if not sections:
        print("Writing an improved version of your draft...")
        improved_version = generate_improved_version(client, cfg, draft_content, analysis)
        if improved_version:
            print("Improved version done.")

    print()
    print("Saving...")
    output_file = save_analysis(analysis, improved_version, draft_path, draft_content, output_path)

    section_count = sum(1 for line in analysis.splitlines() if line.startswith("## "))
    print()
    print("=" * 60)
    print("ANALYSIS COMPLETE")
    print("=" * 60)
    print(f"Saved to: {output_file}")
    print(f"Sections generated: {section_count}")
    if improved_version:
        print("Improved version: included at the top of the file")
    print()
    print("Next: open the file, compare the improved version against your")
    print("original, and cherry-pick the changes you like.")
    print()


if __name__ == "__main__":
    main()
