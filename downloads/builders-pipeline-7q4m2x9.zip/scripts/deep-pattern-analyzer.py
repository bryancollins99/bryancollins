#!/usr/bin/env python3
"""
Deep Pattern Analyzer - a strategic self-audit of your week.

What it does, in plain English:
Reads your worklog and recently edited notes, then asks Claude to look for
the things you can't see from inside your own week:

- Where your time actually went, versus where you said it would go
- Themes that keep recurring across different projects
- Contradictions between your stated priorities and your behaviour
- Productivity patterns: when your best work happens, what blocked you
- What you learned, and which notes are worth keeping permanently
- 3-5 reflection questions based on your specific week

Optional: if a file named Operating-Manual.md exists in your notes folder,
the analyzer reads it and checks your week against the priorities and rules
you wrote down there. If you don't have one, that check is skipped and
everything else still runs. (An Operating Manual is just a note listing how
you intend to work: your priorities, your rules, what you've decided to
avoid. Even ten bullet points make the contradiction check useful.)

This one is for weekly review, not quick content generation. Run it on a
Friday, read the report over coffee.

Usage:
    python3 scripts/deep-pattern-analyzer.py [days]

    days (optional): how many days back to scan your notes. Default: 7.
"""

import sys
from datetime import datetime

from bp_config import (
    load_config,
    get_anthropic_client,
    voice_block,
    read_worklog,
    read_recent_notes,
)

OPERATING_MANUAL_NAME = "Operating-Manual.md"


def call_claude(client, cfg, system_prompt, user_prompt):
    """Send one request to Claude with beginner-friendly error handling."""
    try:
        message = client.messages.create(
            model=cfg["model"],
            max_tokens=cfg["max_tokens"],
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )
        return message.content[0].text
    except Exception as e:  # noqa: BLE001 - we translate every failure for beginners
        err = str(e)
        print()
        print("The AI request failed.")
        if "authentication" in err.lower() or "401" in err:
            print("Your API key was rejected.")
            print("Fix: open the .env file next to config.yaml and check that")
            print("ANTHROPIC_API_KEY has no extra spaces or quotes, and that the")
            print("key is still active at https://console.anthropic.com/settings/keys")
        elif "credit" in err.lower() or "billing" in err.lower():
            print("Your Anthropic account is out of credit.")
            print("Fix: add credit at https://console.anthropic.com/settings/billing")
            print("(A full run of this tool costs a few cents.)")
        elif "not_found" in err.lower() or "model" in err.lower() and "404" in err:
            print(f"The model name in config.yaml ('{cfg['model']}') wasn't recognised.")
            print("Fix: check the 'model' line in config.yaml against the current")
            print("model names at https://docs.anthropic.com")
        elif "overloaded" in err.lower() or "529" in err:
            print("Anthropic's servers are busy right now.")
            print("Fix: wait a minute and run the script again.")
        else:
            print(f"Details: {err}")
            print("Common fixes: check your internet connection, then run it again.")
            print("If it keeps failing, check https://status.anthropic.com")
        sys.exit(1)


def read_operating_manual(cfg):
    """Return the Operating Manual text if one exists in notes_dir, else None."""
    manual_path = cfg["notes_dir"] / OPERATING_MANUAL_NAME
    if not manual_path.exists():
        return None
    lines = manual_path.read_text(encoding="utf-8", errors="ignore").splitlines()
    # First ~3000 lines is more than enough to cover anyone's principles.
    return "\n".join(lines[:3000])


def build_system_prompt(cfg, has_manual):
    """Assemble the analysis framework from the buyer's config."""
    sections = [
        """1. TIME ALLOCATION AUDIT
   - Estimate the % of time spent on each project or area visible in the worklog
   - Name the areas from the evidence; don't assume a fixed list
   - Flag anything that got a lot of time but little visible progress""",
        """2. RECURRING THEME DETECTION
   - Themes, problems, or ideas that appear 3+ times across the week
   - Skills or approaches from one project that could transfer to another
   - Emergent methods: workflows this person is developing without naming them""",
    ]
    if has_manual:
        sections.append("""3. CONTRADICTION SCANNER
   - Compare the week's behaviour against the OPERATING MANUAL provided
   - Where did actual time spent contradict stated priorities?
   - Time spent on things they explicitly said they'd avoid
   - Quote the manual line AND the worklog evidence for each contradiction""")
    else:
        sections.append("""3. STATED-VS-ACTUAL CHECK (no Operating Manual provided)
   - No manual was supplied, so skip formal contradiction checking
   - Instead, note any place where the worklog itself states an intention
     ("I should stop...", "priority this week is...") that the rest of the
     week contradicts""")
    sections += [
        """4. PRODUCTIVITY ANALYSIS
   - When the best work happened (days/times, if the worklog shows them)
   - Context-switching: how often they jumped between projects
   - Blockers and time sinks: what took longer than expected
   - Completion rate: things started vs things finished""",
        """5. LEARNING TRAJECTORY
   - Key insights gained this week
   - Skills that visibly improved
   - Knowledge gaps the week revealed
   - "Aha moments" worth capturing before they're forgotten""",
        """6. PERMANENT NOTE CANDIDATES
   - Worklog entries worth extracting into standalone notes
   - Suggested note titles and a 2-3 bullet structure for each
   - Rationale: why this matters beyond this week""",
        """7. REFLECTION QUESTIONS
   - 3-5 questions based on the specific patterns you detected
   - Each must reference concrete worklog evidence
   - Aim at decisions and trade-offs, not vague journaling prompts""",
    ]

    return f"""You are a pattern analyzer helping someone audit their own working week.

YOUR MISSION:
Surface the insights a person can't see from inside their own week: where
time really went, what keeps recurring, and where behaviour drifted from
intention. Be honest and specific; this report is private and the reader
asked for candour.

{voice_block(cfg)}

You'll receive:
1. WORKLOG: raw daily captures of what this person actually did
2. RECENT NOTES: their more refined notes, drafts, and frameworks{"""
3. OPERATING MANUAL: their written priorities and rules, for cross-referencing""" if has_manual else ""}

ANALYSIS FRAMEWORK:

{(chr(10) + chr(10)).join(sections)}

OUTPUT FORMAT:
A markdown report with all 7 numbered sections above, in order.
Every claim needs specific evidence from the worklog or notes.
Make every recommendation actionable.
"""


def analyze_patterns(client, cfg, worklog_content, recent_notes, operating_manual, days):
    """Ask Claude for the deep pattern analysis."""
    notes_summary = ""
    if recent_notes:
        notes_summary = "\n\nRECENT NOTES (last " + str(days) + " days):\n\n"
        for note in recent_notes:
            notes_summary += f"### {note['file']} (modified {note['modified']})\n"
            notes_summary += f"{note['content'][:500]}...\n\n"

    manual_block = ""
    if operating_manual:
        manual_block = f"\n\n---\n\nOPERATING MANUAL:\n{operating_manual}\n"

    user_prompt = f"""Conduct a deep pattern analysis on the last {days} days of worklog and recent notes.

WORKLOG ENTRIES:
{worklog_content}
{notes_summary}{manual_block}
---

Generate the full deep pattern analysis report with all 7 sections."""

    print("Running deep pattern analysis with Claude...")
    return call_claude(client, cfg, build_system_prompt(cfg, operating_manual is not None), user_prompt)


def save_report(cfg, analysis, days, note_count, has_manual):
    """Save the deep analysis report to the output folder."""
    output_dir = cfg["output_dir"]
    output_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y-%m-%d-%H%M")
    filepath = output_dir / f"Deep-Analysis-{timestamp}.md"

    manual_line = (f"- {OPERATING_MANUAL_NAME} (contradiction check)" if has_manual
                   else f"- No {OPERATING_MANUAL_NAME} found (contradiction check skipped)")
    report_header = f"""# Deep Pattern Analysis - Week of {datetime.now().strftime("%Y-%m-%d")}
Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
Sources:
- {cfg['worklog_file'].name} (recent entries)
- {note_count} recently created/edited notes (last {days} days)
{manual_line}

**Purpose**: Strategic self-audit of the week

#deep-analysis #weekly-review #pattern-detection

---

"""

    filepath.write_text(report_header + analysis, encoding="utf-8")
    print(f"Report saved to: {filepath}")
    return filepath


def main():
    print("=" * 60)
    print("DEEP PATTERN ANALYZER")
    print("A strategic self-audit of your week")
    print("=" * 60)
    print()

    days = 7
    if len(sys.argv) > 1:
        try:
            days = int(sys.argv[1])
        except ValueError:
            print("Usage: python3 scripts/deep-pattern-analyzer.py [days]")
            print("Example: python3 scripts/deep-pattern-analyzer.py 14")
            sys.exit(1)

    cfg = load_config()
    client = get_anthropic_client()

    print(f"Reading worklog: {cfg['worklog_file']}")
    print(f"Analyzing the last {days} days")
    print()

    worklog_content = read_worklog(cfg, max_lines=700)
    print(f"Worklog size: {len(worklog_content.split())} words")

    print("Scanning recently created/edited notes...")
    recent_notes = read_recent_notes(cfg, days_back=days)
    print(f"Recent notes found: {len(recent_notes)}")

    operating_manual = read_operating_manual(cfg)
    if operating_manual:
        print(f"Found {OPERATING_MANUAL_NAME}: your week will be checked against it "
              f"({len(operating_manual.split())} words)")
    else:
        print(f"No {OPERATING_MANUAL_NAME} in your notes folder, so the contradiction")
        print("check will be skipped. Everything else still runs. (Optional: create")
        print(f"{cfg['notes_dir'] / OPERATING_MANUAL_NAME}")
        print("listing your priorities and rules, and future runs will audit against it.)")
    print()

    analysis = analyze_patterns(client, cfg, worklog_content, recent_notes, operating_manual, days)
    filepath = save_report(cfg, analysis, days, len(recent_notes), operating_manual is not None)

    print()
    print("=" * 60)
    print("DEEP ANALYSIS COMPLETE")
    print("=" * 60)
    print()
    print(f"Report: {filepath}")
    print()
    print("Next steps:")
    print("1. Read the time allocation audit: does it match where you meant to spend time?")
    print("2. Answer the reflection questions (in writing, in your notes)")
    print("3. Extract the permanent note candidates into standalone notes")
    if operating_manual:
        print("4. Address any contradictions against your Operating Manual")
    print()


if __name__ == "__main__":
    main()
