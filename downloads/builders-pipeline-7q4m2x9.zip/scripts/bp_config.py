#!/usr/bin/env python3
"""
Shared configuration loader for The Builder's Pipeline.

Every script imports from this module. It handles:
- loading config.yaml (with clear errors if missing or malformed)
- loading API keys from .env (next to config.yaml) or the environment
- expanding ~ in paths and validating they exist
- one shared Anthropic client factory

Buyers should never need to edit this file.
"""

import os
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    print("Missing dependency: pyyaml")
    print("Fix: pip install -r requirements.txt")
    sys.exit(1)

PRODUCT_ROOT = Path(__file__).resolve().parent.parent
CONFIG_FILE = PRODUCT_ROOT / "config.yaml"
ENV_FILE = PRODUCT_ROOT / ".env"


def _load_env_file():
    """Load KEY=value pairs from .env into os.environ (without overriding)."""
    if not ENV_FILE.exists():
        return
    for raw in ENV_FILE.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key, value = key.strip(), value.strip().strip("'\"")
        if key and key not in os.environ:
            os.environ[key] = value


def load_config():
    """Load and validate config.yaml. Exits with a friendly message on problems."""
    if not CONFIG_FILE.exists():
        print("No config.yaml found.")
        print(f"Fix: copy the example and edit it:")
        print(f"  cp {PRODUCT_ROOT / 'config.example.yaml'} {CONFIG_FILE}")
        print("Then open config.yaml and set notes_dir and worklog_file.")
        sys.exit(1)

    with open(CONFIG_FILE) as f:
        try:
            cfg = yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            print(f"config.yaml has a formatting problem:\n  {e}")
            print("Tip: YAML is picky about indentation. Compare against config.example.yaml.")
            sys.exit(1)

    for required in ("notes_dir", "worklog_file", "output_dir"):
        if required not in cfg:
            print(f"config.yaml is missing the '{required}' setting.")
            print("Compare your file against config.example.yaml.")
            sys.exit(1)

    cfg["notes_dir"] = Path(os.path.expanduser(str(cfg["notes_dir"])))
    cfg["worklog_file"] = Path(os.path.expanduser(str(cfg["worklog_file"])))
    cfg["output_dir"] = Path(os.path.expanduser(str(cfg["output_dir"])))

    cfg.setdefault("voice", "Direct, practical, first-person, specific.")
    cfg.setdefault("topics", [])
    cfg.setdefault("avoid", [])
    cfg.setdefault("platforms", {"linkedin": True, "newsletter": True, "youtube": True})
    cfg.setdefault("model", "claude-sonnet-5")
    cfg.setdefault("max_tokens", 4000)
    cfg.setdefault("kit", {})
    return cfg


def get_anthropic_client():
    """Return an Anthropic client, or exit with setup instructions."""
    _load_env_file()
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("No Anthropic API key found.")
        print(f"Fix: add this line to {ENV_FILE}:")
        print("  ANTHROPIC_API_KEY=sk-ant-your-key-here")
        print("Get a key at: https://console.anthropic.com/settings/keys")
        sys.exit(1)
    try:
        import anthropic
    except ImportError:
        print("Missing dependency: anthropic")
        print("Fix: pip install -r requirements.txt")
        sys.exit(1)
    return anthropic.Anthropic(api_key=api_key)


def get_kit_api_key(required=True):
    """Return the Kit (ConvertKit) v4 API key, or None/exit if absent."""
    _load_env_file()
    key = os.environ.get("KIT_API_KEY")
    if not key and required:
        print("No Kit API key found (needed only for newsletter scheduling).")
        print(f"Fix: add this line to {ENV_FILE}:")
        print("  KIT_API_KEY=kit_your-key-here")
        print("Get it in Kit under Settings -> Developer.")
        sys.exit(1)
    return key


def voice_block(cfg):
    """Standard voice/topics/avoid block injected into every system prompt."""
    lines = [f"WRITING VOICE:\n{cfg['voice'].strip()}"]
    if cfg["topics"]:
        lines.append("TOPICS THIS PERSON WRITES ABOUT:\n- " + "\n- ".join(cfg["topics"]))
    if cfg["avoid"]:
        lines.append("NEVER WRITE ABOUT:\n- " + "\n- ".join(cfg["avoid"]))
    return "\n\n".join(lines)


def read_worklog(cfg, max_lines=500):
    """Return the tail of the worklog file."""
    wl = cfg["worklog_file"]
    if not wl.exists():
        print(f"Worklog not found at: {wl}")
        print("Fix: create it, or point worklog_file in config.yaml at your worklog.")
        print("A worklog is just a text file of one-line notes about what you did.")
        sys.exit(1)
    lines = wl.read_text(encoding="utf-8", errors="ignore").splitlines()
    return "\n".join(lines[-max_lines:])


def read_recent_notes(cfg, days_back=7, limit=20, chars_per_note=2000):
    """Return up to `limit` recently-modified notes from notes_dir."""
    from datetime import datetime, timedelta

    notes_dir = cfg["notes_dir"]
    if not notes_dir.exists():
        print(f"Notes folder not found at: {notes_dir}")
        print("Fix: set notes_dir in config.yaml to a folder of .md files.")
        sys.exit(1)

    cutoff = datetime.now() - timedelta(days=days_back)
    worklog_name = cfg["worklog_file"].name
    notes = []
    for md in notes_dir.glob("*.md"):
        if md.name == worklog_name or md.name.startswith("."):
            continue
        try:
            mtime = datetime.fromtimestamp(md.stat().st_mtime)
            if mtime <= cutoff:
                continue
            content = md.read_text(encoding="utf-8", errors="ignore")
            if len(content) > 100:
                notes.append({
                    "file": md.name,
                    "modified": mtime.strftime("%Y-%m-%d"),
                    "content": content[:chars_per_note],
                })
        except OSError:
            continue
    notes.sort(key=lambda n: n["modified"], reverse=True)
    return notes[:limit]
