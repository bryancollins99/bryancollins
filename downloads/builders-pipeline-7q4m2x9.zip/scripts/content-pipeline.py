#!/usr/bin/env python3
"""
Content Pipeline - turn a week of real work into content ideas.

What it does, in plain English:
Reads your worklog and your recently edited notes, then asks Claude one
focused question: "What did you build or learn this week that could become
content?" It writes a single report to your output folder containing:

- A one-sentence result of the week (your newsletter anchor)
- 3-5 LinkedIn post ideas, each with a hook, angle, evidence and CTA
- 1 newsletter topic with a suggested structure
- 2 YouTube video ideas (tutorial-focused)

Only platforms you have switched on in config.yaml get ideas generated.

Philosophy: content is the exhaust, not the engine. If you don't know what
to write about, you haven't done the work yet - so this tool starts from
the work you actually did.

Usage:
    python3 scripts/content-pipeline.py [days]

    days (optional): how many days back to scan your notes. Default: 7.

Run it at the end of your week. Takes about 30 seconds.
"""

import sys
from datetime import datetime

from bp_config import (
    load_config,
    get_anthropic_client,
    voice_block,
    read_worklog,
    read_recent_notes,
)


def call_claude(client, cfg, system_prompt, user_prompt):
    """Send one request to Claude with beginner-friendly error handling."""
    try:
        message = client.messages.create(
            model=cfg["model"],
            max_tokens=cfg["max_tokens"],
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )
        return message.content[0].text
    except Exception as e:  # noqa: BLE001 - we translate every failure for beginners
        err = str(e)
        print()
        print("The AI request failed.")
        if "authentication" in err.lower() or "401" in err:
            print("Your API key was rejected.")
            print("Fix: open the .env file next to config.yaml and check that")
            print("ANTHROPIC_API_KEY has no extra spaces or quotes, and that the")
            print("key is still active at https://console.anthropic.com/settings/keys")
        elif "credit" in err.lower() or "billing" in err.lower():
            print("Your Anthropic account is out of credit.")
            print("Fix: add credit at https://console.anthropic.com/settings/billing")
            print("(A full run of this tool costs a few cents.)")
        elif "not_found" in err.lower() or "model" in err.lower() and "404" in err:
            print(f"The model name in config.yaml ('{cfg['model']}') wasn't recognised.")
            print("Fix: check the 'model' line in config.yaml against the current")
            print("model names at https://docs.anthropic.com")
        elif "overloaded" in err.lower() or "529" in err:
            print("Anthropic's servers are busy right now.")
            print("Fix: wait a minute and run the script again.")
        else:
            print(f"Details: {err}")
            print("Common fixes: check your internet connection, then run it again.")
            print("If it keeps failing, check https://status.anthropic.com")
        sys.exit(1)


def build_system_prompt(cfg):
    """Assemble the system prompt from the buyer's config, not a fixed persona."""
    platforms = cfg["platforms"]
    outputs = ["1. ONE-SENTENCE RESULT OF THE WEEK (the single clearest win, stated plainly)"]
    n = 2
    if platforms.get("linkedin"):
        outputs.append(f"{n}. LINKEDIN POST IDEAS (3-5 posts, each with a hook, angle, "
                       "specific evidence, and a CTA)")
        n += 1
    if platforms.get("newsletter"):
        outputs.append(f"{n}. NEWSLETTER TOPIC (1 topic with a suggested section-by-section "
                       "structure, anchored on the one-sentence result)")
        n += 1
    if platforms.get("youtube"):
        outputs.append(f"{n}. YOUTUBE VIDEO IDEAS (2 tutorial-focused ideas: what to show "
                       "on screen, not lifestyle filler)")
        n += 1

    return f"""You are a content idea generator for someone who builds things and documents them.

CONTENT PHILOSOPHY:
- "Content is the exhaust, not the engine."
- If you don't know what to document, you haven't done the work.
- Report on real builds, systems, and lessons - never generic advice.
- Wrap every build in a small personal story.

{voice_block(cfg)}

YOUR JOB:
Scan the worklog AND the recent notes for builds, learnings, and systems.
Turn them into ready-to-publish content ideas.

You'll receive:
1. WORKLOG: raw daily captures of what this person actually did
2. RECENT NOTES: their more refined notes, drafts, and frameworks

Combine insights from both sources.

Generate a report with:
{chr(10).join(outputs)}

Make every idea SPECIFIC, with:
- Hook (the opening line, written out)
- Angle (the unique perspective)
- Evidence (actual worklog entries or note titles, numbers, before/after results)
- CTA (a soft, natural call to action - never invent product names or links)

Focus on: What did they build? What did they learn? What can they show?
"""


def generate_content_ideas(client, cfg, worklog_content, recent_notes, days):
    """Ask Claude for the content pipeline report."""
    notes_summary = ""
    if recent_notes:
        notes_summary = "\n\nRECENT NOTES (last " + str(days) + " days):\n\n"
        for note in recent_notes:
            notes_summary += f"### {note['file']} (modified {note['modified']})\n"
            notes_summary += f"{note['content'][:500]}...\n\n"

    user_prompt = f"""Analyze the last {days} days of worklog and recent notes to generate content ideas.

WORKLOG ENTRIES:
{worklog_content}
{notes_summary}

Generate the full content pipeline report."""

    print("Generating content ideas with Claude...")
    return call_claude(client, cfg, build_system_prompt(cfg), user_prompt)


def save_report(cfg, analysis, days, note_count):
    """Save the content pipeline report to the output folder."""
    output_dir = cfg["output_dir"]
    output_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y-%m-%d-%H%M")
    filepath = output_dir / f"Content-Pipeline-{timestamp}.md"

    enabled = [p for p, on in cfg["platforms"].items() if on]
    report_header = f"""# Content Pipeline - Week of {datetime.now().strftime("%Y-%m-%d")}
Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
Sources:
- {cfg['worklog_file'].name} (recent entries)
- {note_count} recently created/edited notes (last {days} days)
Platforms: {', '.join(enabled)}

**Philosophy**: Content is the exhaust, not the engine.

#content-pipeline #content-ideas

---

"""

    filepath.write_text(report_header + analysis, encoding="utf-8")
    print(f"Report saved to: {filepath}")
    return filepath


def main():
    print("=" * 60)
    print("CONTENT PIPELINE")
    print("Turning this week's work into content ideas")
    print("=" * 60)
    print()

    days = 7
    if len(sys.argv) > 1:
        try:
            days = int(sys.argv[1])
        except ValueError:
            print("Usage: python3 scripts/content-pipeline.py [days]")
            print("Example: python3 scripts/content-pipeline.py 14")
            sys.exit(1)

    cfg = load_config()

    enabled = [p for p, on in cfg["platforms"].items() if on]
    if not enabled:
        print("All platforms are switched off in config.yaml.")
        print("Fix: open config.yaml and set at least one platform to true, e.g.")
        print("  platforms:")
        print("    linkedin: true")
        sys.exit(1)

    client = get_anthropic_client()

    print(f"Reading worklog: {cfg['worklog_file']}")
    print(f"Analyzing the last {days} days")
    print(f"Platforms switched on: {', '.join(enabled)}")
    print()

    worklog_content = read_worklog(cfg)
    print(f"Worklog size: {len(worklog_content.split())} words")

    print("Scanning recently created/edited notes...")
    recent_notes = read_recent_notes(cfg, days_back=days)
    print(f"Recent notes found: {len(recent_notes)}")
    print()

    analysis = generate_content_ideas(client, cfg, worklog_content, recent_notes, days)
    filepath = save_report(cfg, analysis, days, len(recent_notes))

    print()
    print("=" * 60)
    print("CONTENT IDEAS READY")
    print("=" * 60)
    print()
    print(f"Report: {filepath}")
    print()
    print("Next steps:")
    step = 1
    if cfg["platforms"].get("linkedin"):
        print(f"{step}. Review the LinkedIn post ideas and pick 2-3 to draft")
        step += 1
    if cfg["platforms"].get("newsletter"):
        print(f"{step}. Draft your newsletter from the one-sentence result")
        step += 1
    if cfg["platforms"].get("youtube"):
        print(f"{step}. Add the YouTube ideas to your recording list")
        step += 1
    print(f"{step}. Want full drafts instead of ideas? Run: python3 scripts/draft-generator.py")
    print()


if __name__ == "__main__":
    main()
