#!/usr/bin/env python3
"""
Setup checker for The Builder's Pipeline.

Run this after following SETUP.md. It verifies every prerequisite and tells
you exactly what to fix, in order. Also creates your worklog file for you:

    python3 scripts/setup_check.py                  # check everything
    python3 scripts/setup_check.py --create-worklog # create worklog from template
"""

import os
import sys
from pathlib import Path

PRODUCT_ROOT = Path(__file__).resolve().parent.parent

PASS = "  [ok]  "
FAIL = "  [fix] "

def check(label, ok, fix=""):
    print((PASS if ok else FAIL) + label)
    if not ok and fix:
        for line in fix.splitlines():
            print("         " + line)
    return ok


def main():
    print("The Builder's Pipeline — setup check\n" + "=" * 44)
    all_ok = True

    # 1. Python version
    v = sys.version_info
    all_ok &= check(
        f"Python {v.major}.{v.minor}",
        v >= (3, 9),
        "Python 3.9+ required. Install from https://python.org/downloads",
    )

    # 2. Dependencies
    for mod, pkg in [("anthropic", "anthropic"), ("yaml", "pyyaml")]:
        try:
            __import__(mod)
            ok = True
        except ImportError:
            ok = False
        all_ok &= check(
            f"library: {pkg}", ok, f"Run: pip install -r requirements.txt"
        )

    # Optional deps
    for mod, pkg, needed_by in [
        ("requests", "requests", "schedule-newsletter.py"),
        ("youtube_transcript_api", "youtube-transcript-api", "youtube-email.py"),
    ]:
        try:
            __import__(mod)
            print(PASS + f"library: {pkg} (optional, for {needed_by})")
        except ImportError:
            print(f"  [--]  library: {pkg} not installed (only needed for {needed_by})")

    # 3. .env / API key
    sys.path.insert(0, str(PRODUCT_ROOT / "scripts"))
    import bp_config
    bp_config._load_env_file()
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    all_ok &= check(
        "Anthropic API key",
        key.startswith("sk-ant"),
        f"Create {PRODUCT_ROOT / '.env'} containing:\n"
        "ANTHROPIC_API_KEY=sk-ant-your-key-here\n"
        "(SETUP.md, steps 5-6)",
    )
    kit = os.environ.get("KIT_API_KEY", "")
    if kit:
        print(PASS + "Kit API key (newsletter scheduling enabled)")
    else:
        print("  [--]  Kit API key not set (fine unless you use schedule-newsletter.py)")

    # 4. config.yaml
    cfg_file = PRODUCT_ROOT / "config.yaml"
    if not check(
        "config.yaml exists",
        cfg_file.exists(),
        "Run: cp config.example.yaml config.yaml  (SETUP.md, step 7)",
    ):
        print("\nFix the items above, then run this again.")
        sys.exit(1)

    cfg = bp_config.load_config()

    # 5. Paths
    all_ok &= check(
        f"notes folder: {cfg['notes_dir']}",
        cfg["notes_dir"].exists(),
        "Create the folder, or point notes_dir in config.yaml somewhere real.",
    )

    wl = cfg["worklog_file"]
    if "--create-worklog" in sys.argv:
        if wl.exists():
            print(PASS + f"worklog already exists: {wl}")
        else:
            wl.parent.mkdir(parents=True, exist_ok=True)
            template = PRODUCT_ROOT / "templates" / "Worklog-Template.md"
            wl.write_text(template.read_text() if template.exists() else "# Worklog\n\n")
            print(PASS + f"worklog created: {wl}")
    all_ok &= check(
        f"worklog: {wl}",
        wl.exists(),
        "Run: python3 scripts/setup_check.py --create-worklog",
    )

    print("=" * 44)
    if all_ok:
        print("All good. Try:  python3 scripts/content-pipeline.py")
    else:
        print("Fix the [fix] items above in order, then run this again.")
        sys.exit(1)


if __name__ == "__main__":
    main()
