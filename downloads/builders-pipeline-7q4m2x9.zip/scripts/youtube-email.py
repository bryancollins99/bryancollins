#!/usr/bin/env python3
"""
YouTube Email — turn a YouTube video into a promotional email.

Give it a YouTube URL and it fetches the video's transcript, then writes a
300-400 word email in YOUR voice (from the voice setting in config.yaml)
that promotes the video, with a natural link to it in the body. The draft
is saved to your output_dir, named after the subject line, ready to review
and schedule with schedule-newsletter.py.

Usage:
    python3 scripts/youtube-email.py <youtube-url>
    python3 scripts/youtube-email.py https://www.youtube.com/watch?v=dQw4w9WgXcQ

The video needs captions (auto-generated captions are fine). If a video
has no transcript, the script tells you and exits cleanly.
"""

import re
import sys
from datetime import datetime
from pathlib import Path

from bp_config import load_config, get_anthropic_client, voice_block

try:
    from youtube_transcript_api import YouTubeTranscriptApi
except ImportError:
    print("Missing dependency: youtube-transcript-api")
    print("Fix: pip install youtube-transcript-api")
    print("(or install everything at once: pip install -r requirements.txt)")
    sys.exit(1)


def extract_video_id(url):
    """Pull the video ID out of any common YouTube URL format."""
    patterns = [
        r"(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?]+)",
        r"youtube\.com\/embed\/([^&\n?]+)",
        r"youtube\.com\/v\/([^&\n?]+)",
        r"youtube\.com\/shorts\/([^&\n?]+)",
    ]
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    return None


def get_transcript(video_id):
    """Fetch the video's English transcript, or None with a friendly explanation."""
    try:
        try:
            # youtube-transcript-api 1.x
            api = YouTubeTranscriptApi()
            fetched = api.fetch(video_id, languages=["en"])
            return " ".join(snippet.text for snippet in fetched.snippets)
        except AttributeError:
            # older library versions (< 1.0)
            data = YouTubeTranscriptApi.get_transcript(video_id, languages=["en"])
            return " ".join(item["text"] for item in data)
    except Exception as e:
        error_name = type(e).__name__
        print(f"Could not fetch a transcript for this video ({error_name}).")
        if "TranscriptsDisabled" in error_name or "NoTranscript" in error_name:
            print("This video has no captions available. The script needs captions")
            print("(auto-generated ones are fine) to know what the video is about.")
            print("Try another video, or add captions in YouTube Studio first.")
        else:
            print(f"Details: {e}")
            print("Common causes: the video is private, region-locked, very new")
            print("(captions still processing), or YouTube is rate-limiting you —")
            print("wait a minute and try again.")
        return None


def generate_email(client, cfg, video_url, transcript):
    """Write the promotional email with Claude, in the buyer's voice."""
    system_prompt = (
        """You are an email copywriter creating promotional emails for YouTube videos.

Your task:
1. Analyze the video transcript
2. Extract the main topic and key takeaways
3. Write a short, engaging promotional email (300-400 words)

Email format:
- Subject line: curiosity-driven, under 60 characters
- Opening: jump straight into the content — NO greetings like "Hey there" or preambles
- Body:
  * What the video covers (2-3 key points)
  * Why it's valuable
  * One specific example or insight from the video
- Video link: hyperlink a natural word or phrase in the email body to the YouTube video URL, e.g. [watch the full breakdown](VIDEO_URL) or [I walk through the whole process here](VIDEO_URL). Do NOT use iframe embeds — email clients strip iframes.
- NO sign-off: don't include "Best," "Cheers," or a name at the end
- No hard sell: the email should feel like a personal recommendation

Writing style:
- Direct, conversational, anti-fluff
- Focus on practical value
- No hype or exaggeration"""
        + "\n\n"
        + voice_block(cfg)
    )

    user_prompt = f"""Generate a promotional email for this YouTube video.

VIDEO URL: {video_url}

TRANSCRIPT:
{transcript[:8000]}

---

Return the email in this exact format:

SUBJECT: [subject line here]

---

[Email body here — opening hook, 2-3 key points, value proposition. Hyperlink a natural phrase to the video URL. No iframe embeds, no greeting, no sign-off.]

Make it concise, valuable, and authentic."""

    print("Writing the email with Claude (this usually takes 15-30 seconds)...")
    try:
        message = client.messages.create(
            model=cfg["model"],
            max_tokens=cfg["max_tokens"],
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )
    except Exception as e:
        print(f"The AI request failed: {e}")
        print("Common fixes: check your internet connection, and confirm the")
        print("ANTHROPIC_API_KEY in your .env file is valid and has credit.")
        sys.exit(1)
    return message.content[0].text


def save_email(cfg, email_content, video_url):
    """Save the draft to output_dir, named after the subject line."""
    output_dir = cfg["output_dir"]
    output_dir.mkdir(parents=True, exist_ok=True)

    subject_match = re.search(r"SUBJECT:\s*(.+)", email_content)
    subject = subject_match.group(1).strip() if subject_match else "YouTube Video Email"

    # Sanitize the subject for use as a filename
    safe_subject = re.sub(r"[^\w\s-]", "", subject)
    safe_subject = re.sub(r"\s+", " ", safe_subject).strip()[:80]
    if not safe_subject:
        safe_subject = "YouTube Video Email"
    filepath = output_dir / f"{safe_subject}.md"

    # The subject becomes the H1 title, so remove the SUBJECT: line from the body
    email_body = re.sub(r"SUBJECT:.*?\n\n---\n\n", "", email_content, flags=re.DOTALL)
    email_body = email_body.rstrip()
    if email_body.endswith("---"):
        email_body = email_body[:-3].rstrip()

    file_content = f"""# {subject}

**Video**: {video_url}
**Generated**: {datetime.now().strftime("%Y-%m-%d %H:%M")}

---

{email_body}

---
"""
    filepath.write_text(file_content, encoding="utf-8")
    return filepath


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 scripts/youtube-email.py <youtube-url>")
        print()
        print("Example:")
        print("  python3 scripts/youtube-email.py https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        sys.exit(1)

    video_url = sys.argv[1]

    print("=" * 60)
    print("YOUTUBE EMAIL — video transcript to promotional email")
    print("=" * 60)
    print()

    cfg = load_config()

    print(f"Video URL: {video_url}")
    video_id = extract_video_id(video_url)
    if not video_id:
        print("That doesn't look like a YouTube URL I can read.")
        print("Expected something like: https://www.youtube.com/watch?v=VIDEO_ID")
        print("or: https://youtu.be/VIDEO_ID")
        sys.exit(1)
    print(f"Video ID: {video_id}")
    print()

    print("Fetching the transcript from YouTube...")
    transcript = get_transcript(video_id)
    if not transcript:
        sys.exit(1)
    print(f"Transcript fetched: {len(transcript.split())} words")
    print()

    client = get_anthropic_client()
    email_content = generate_email(client, cfg, video_url, transcript)

    print()
    filepath = save_email(cfg, email_content, video_url)

    print("=" * 60)
    print("EMAIL GENERATED")
    print("=" * 60)
    print(f"Saved to: {filepath}")
    print()
    print("Next steps:")
    print("1. Open the file and read it — edit anything that doesn't sound like you")
    print("2. Tweak the subject line if you have a better one")
    print("3. Push it to Kit with:")
    print(f"   python3 scripts/schedule-newsletter.py \"{filepath.name}\"")
    print()


if __name__ == "__main__":
    main()
