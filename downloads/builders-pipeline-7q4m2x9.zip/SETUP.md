# SETUP.md — the assume-nothing guide

This guide gets you from "I bought a zip file" to "I just generated my first
content pipeline" in about 15 minutes, assuming you have never opened a
terminal before.

If you get stuck at any step, email bryan@becomeawritertoday.com with the step
number and what your screen says.

> **Don't want to install anything?** You can use this whole system without
> Python. Open the `prompts/` folder and read `prompts/README.md` — every
> script exists as a copy-paste prompt for Claude. The scripts are faster and
> repeatable, but the prompts get you the same output today with zero setup.

---

## Step 1 — Unzip the product

Double-click the downloaded `builders-pipeline.zip`. Move the resulting
`builders-pipeline` folder somewhere permanent, e.g. your home folder or
Documents. Don't leave it in Downloads.

## Step 2 — Open a terminal

- **Mac:** press Cmd+Space, type `Terminal`, press Enter.
- **Windows:** press the Windows key, type `PowerShell`, press Enter.

You'll see a window with a blinking cursor. You type commands, press Enter,
things happen. That's the whole skill.

Now navigate into the product folder. Type `cd ` (with the trailing space),
then drag the `builders-pipeline` folder from Finder/Explorer onto the
terminal window, and press Enter.

## Step 3 — Check Python is installed

Type:

    python3 --version

- If you see `Python 3.9` or higher: you're done with this step.
- **Mac:** if it offers to install "command line developer tools", click
  Install, wait, then try again.
- **Windows:** if it's not found, install Python from https://python.org/downloads
  (tick "Add python.exe to PATH" during install), close and reopen PowerShell,
  and use `python` instead of `python3` in every command in this guide.

## Step 4 — Install the three libraries

    pip install -r requirements.txt

(If that fails, try `pip3 install -r requirements.txt`.)

This installs the Anthropic library (talks to the AI), a YAML reader (reads
your settings), and two small helpers. Nothing else touches your machine.

## Step 5 — Get an Anthropic API key

The scripts use Claude, the same AI behind claude.ai, via a pay-as-you-go key.
There is no subscription: you pay for what you use, and a full weekly run of
every script costs well under $0.25.

1. Go to https://console.anthropic.com and sign up (or log in).
2. Add a small amount of credit ($5 lasts months at this usage).
3. Go to Settings → API Keys → Create Key. Copy the key (starts `sk-ant-`).

## Step 6 — Create your .env file

In the terminal (still inside the builders-pipeline folder):

**Mac:**

    echo 'ANTHROPIC_API_KEY=sk-ant-PASTE-YOUR-KEY-HERE' > .env

**Windows PowerShell:**

    Set-Content .env 'ANTHROPIC_API_KEY=sk-ant-PASTE-YOUR-KEY-HERE'

Replace the placeholder with your real key. This file stays on your machine
and is read only by these scripts.

## Step 7 — Create your config

    cp config.example.yaml config.yaml

(Windows: `copy config.example.yaml config.yaml`)

Open `config.yaml` in any text editor (TextEdit, Notepad, VS Code) and set:

- `notes_dir:` — the folder where your markdown notes live. No notes system
  yet? Make an empty folder called `notes` in your home directory and point
  at that. The worklog is what matters; notes enrich it.
- `worklog_file:` — where your daily worklog lives (next step creates one).
- `voice:` — two sentences on how you write. Be honest, not aspirational —
  the drafts will sound like whatever you put here.

## Step 8 — Create your worklog

    python3 scripts/setup_check.py --create-worklog

This creates a worklog file (from `templates/Worklog-Template.md`) at the
location you set in config.yaml. From now on, the habit is one line per day:

    2026-07-01: Rewrote the recipe-card plugin. 2 hrs. The shortcode approach failed, used blocks instead.

What you did, how long it took, one thing you learned. That single habit
feeds the entire pipeline.

## Step 9 — Verify everything

    python3 scripts/setup_check.py

It checks Python version, libraries, API key, config paths, and worklog, and
tells you exactly what to fix if anything's wrong. All green?

## Step 10 — First run

    python3 scripts/content-pipeline.py

Thirty seconds later there's a `Content-Pipeline-<date>.md` file in your notes
folder with your first batch of ideas. (First run with a nearly-empty worklog
will be thin — that's expected. Log one line a day for a week, run it again,
and you'll see the difference.)

Welcome to the pipeline.
