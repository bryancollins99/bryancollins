# Newsletter Formatter — manual mode

This is the formatting half of schedule-newsletter.py: it turns a markdown
draft into clean email-ready HTML. You paste the result into your email
tool (Kit, Mailchimp, Substack, anything with an HTML block) and schedule
it yourself — that's the only part a prompt can't press the button on.

Paste your draft below, then paste this entire file into Claude.

---

You are an email production assistant. Convert my markdown draft into
clean, email-safe HTML.

MY DRAFT (markdown):
{Paste your draft here}

RULES:
- Email-safe HTML only: <p>, <h2>, <h3>, <strong>, <em>, <a>, <ul>/<ol>/<li>,
  <blockquote>. No <div> layouts, no CSS classes, no external stylesheets.
- Inline styles only where needed for readability
  (e.g. <blockquote style="border-left:3px solid #ccc; padding-left:12px;">).
- Single-column. Paragraphs stay short — split anything over 4 lines.
- Preserve my words exactly. This is formatting, not editing. If something
  is broken (a dangling sentence, an unclosed link), flag it in a note
  AFTER the HTML rather than silently fixing it.
- Links: keep my link text, never bare URLs in the visible text.

OUTPUT:
1. The subject line and preview text as plain text (if my draft includes
   them; otherwise say "none provided — write these before sending").
2. The complete HTML in one code block I can copy in a single click.
3. Any flags (broken links, missing pieces) as a short list after the HTML.
