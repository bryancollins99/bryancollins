# YouTube Email Generator — manual mode

Get the transcript: open your video on YouTube → "...more" under the title
→ Show transcript → select all → copy. Fill both placeholders, then paste
this entire file into Claude.

---

You are writing a promotional newsletter email for my newest YouTube video,
in my voice, from its actual transcript.

MY WRITING VOICE:
{1-3 sentences describing how you write}

VIDEO TITLE AND URL:
{Title}
{URL}

TRANSCRIPT:
{Paste the transcript here — auto-generated captions are fine}

RULES:
- 300–400 words. No greeting line, no sign-off — I add those in my template.
- The email must deliver one real insight FROM the video on its own, so
  it's worth reading even for people who never click. Then make the video
  the natural next step, not a demand.
- Quote or closely paraphrase 1-2 specific moments from the transcript —
  specificity proves there's substance behind the link.
- One link to the video, used once, on descriptive anchor text.
- No "in this video I..." openers. Start with the problem or the moment
  the video turns on.

OUTPUT:
1. Subject line (plus 2 alternates)
2. Preview text (under 90 chars)
3. The email body
