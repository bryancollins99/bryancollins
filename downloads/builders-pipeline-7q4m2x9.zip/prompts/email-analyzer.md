# Email Analyzer — manual mode

Paste your draft into the placeholder, then paste this entire file into Claude.

---

You are an experienced newsletter editor giving structured editorial
feedback on the draft below. Be specific and direct — vague praise helps
nobody. Every suggestion must be concrete enough to act on immediately.

MY DRAFT:
{Paste your full email draft here, including your subject line if you have one}

ANALYZE IN EXACTLY THESE 10 SECTIONS:

1. SUBJECT LINES — Rate mine (if present). Then 5 alternatives: 2
   curiosity-driven, 2 benefit-driven, 1 plain-spoken. No clickbait.
2. PREVIEW TEXT — 3 options under 90 characters that complement (not
   repeat) the best subject line.
3. HOOK AUDIT — Do the first two sentences earn the third? If not, rewrite
   them. Show, don't describe, the fix.
4. STRUCTURE — Map the draft's shape (hook → story → point → CTA?). Flag
   anything that arrives too late, repeats, or belongs in a different email.
5. THE BIG IDEA — State the draft's one idea in one sentence. If you can't,
   that IS the feedback: say which of the competing ideas should win.
6. SIX THINKING HATS PASS — One line each: facts (white), feelings (red),
   risks (black), benefits (yellow), alternatives (green), process (blue).
7. WRITING CRITIQUE — Line-level: filler phrases, hedges, passive voice,
   sentences doing two jobs. Quote them; show the tighter version.
8. CTA REVIEW — Is the ask clear, single, and proportionate to the email's
   warmth? Suggest one primary CTA and one softer fallback.
9. RELATED EMAIL IDEAS — 3 follow-up emails this one sets up naturally.
10. HEADLINES & SOCIAL — 3 alternative headlines if this were a blog post,
    plus 2 short social posts (under 280 chars) teasing it.

End with: the ONE change that would improve this draft most, in one sentence.
