# Manual mode — the pipeline without Python

Every script in this product is, at its core, a carefully-built prompt plus
some plumbing. This folder gives you the prompts. If you never install
Python, you can still run the whole system by hand in about ten minutes a
week using Claude (claude.ai) or any capable AI chat.

## How to use any prompt in this folder

1. Open the prompt file. Fill in the {PLACEHOLDERS} at the top — your voice
   description and, where asked, paste your worklog or draft.
2. Paste the whole thing into a new Claude conversation.
3. Copy the output into your notes.

That's it. The scripts automate steps 1–3 and save the output with tidy
filenames — worth setting up eventually — but the thinking is identical.

## The prompts

| File | Replaces | Weekly use |
|---|---|---|
| `content-pipeline.md` | content-pipeline.py | Friday: paste worklog → 5 ideas with hooks |
| `deep-pattern-analyzer.md` | deep-pattern-analyzer.py | Friday: paste worklog → themes + honest audit |
| `draft-generator.md` | draft-generator.py | Friday: paste worklog + a chosen idea → full drafts |
| `email-analyzer.md` | email-analyzer.py | Before sending: paste draft → 10-section feedback |
| `newsletter-formatter.md` | schedule-newsletter.py (the formatting half) | Paste draft → clean email HTML you can paste into Kit/Mailchimp/Substack |
| `youtube-email.md` | youtube-email.py | Paste video transcript → promo email |

The one thing manual mode can't do is *schedule* the email in Kit for you —
`newsletter-formatter.md` gets the email ready and you press the button in
Kit yourself. (The video transcript for `youtube-email.md`: on any YouTube
video, click "...more" → Show transcript, select-all, copy.)

## One honest tip

Manual mode works best when your worklog is honest and specific. "Worked on
site" gives the AI nothing. "Rebuilt the recipe index page, 3 hrs, learned
the plugin was the bottleneck all along" gives it a post.
